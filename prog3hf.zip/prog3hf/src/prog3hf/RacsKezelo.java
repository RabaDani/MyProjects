package prog3hf;

/**
 * @class RacsKezelo
 * @brief A Sejtautomata rácsának műveleteit implementáló osztály.
 */
public class RacsKezelo {

    /**
     * @brief Meghatározza az automata rácsának következő állapotát.
     * 
     * @param automata A kezelt Sejtautomata objektum.
     * @return Igaz, ha az állapot változott, különben hamis.
     */
    public static boolean kovetkezoAllapot(Sejtautomata automata) {
        int[][] ujRacs = new int[automata.getSorok()][automata.getOszlopok()];
        boolean valtozott = false;

        for (int sor = 0; sor < automata.getSorok(); sor++) {
            for (int oszlop = 0; oszlop < automata.getOszlopok(); oszlop++) {
                int szomszedokSzama = szomszedokSzama(automata, sor, oszlop);
                if (automata.getRacs()[sor][oszlop] == 1) {
                    ujRacs[sor][oszlop] = automata.tulel(szomszedokSzama) ? 1 : 0;
                } else {
                    ujRacs[sor][oszlop] = automata.szuletik(szomszedokSzama) ? 1 : 0;
                }
                if (ujRacs[sor][oszlop] != automata.getRacs()[sor][oszlop]) {
                    valtozott = true;
                }
            }
        }
        automata.racs = ujRacs;
        return valtozott;
    }

    /**
     * @brief Alaphelyzetbe állítja az automata rácsát, azaz minden cellát 0-ra állít.
     * 
     * @param automata A kezelt Sejtautomata objektum.
     */
    public static void reset(Sejtautomata automata) {
        for (int sor = 0; sor < automata.getSorok(); sor++) {
            for (int oszlop = 0; oszlop < automata.getOszlopok(); oszlop++) {
                automata.getRacs()[sor][oszlop] = 0;
            }
        }
    }

    /**
     * @brief Meghatározza egy adott cella szomszédainak számát az automata rácsában.
     * 
     * @param automata A kezelt Sejtautomata objektum.
     * @param sor Az adott cella sora.
     * @param oszlop Az adott cella oszlopa.
     * @return Az adott cellát körülvevő szomszédok száma.
     */
    public static int szomszedokSzama(Sejtautomata automata, int sor, int oszlop) {
        int szomszedokSzama = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (!(i == 0 && j == 0)) {
                    int ujSor = (sor + i + automata.getSorok()) % automata.getSorok();
                    int ujOszlop = (oszlop + j + automata.getOszlopok()) % automata.getOszlopok();
                    szomszedokSzama += automata.getRacs()[ujSor][ujOszlop];
                }
            }
        }
        return szomszedokSzama;
    }
}
