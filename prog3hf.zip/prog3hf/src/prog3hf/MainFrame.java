package prog3hf;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
 * @class MainFrame
 * @brief A Swing alapú grafikus felület a sejtautomata szimulációhoz.
 *
 * Az osztály kezeli a GUI elemeket, a sejtautomata vezérlését és az eseményeket.
 */
public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1L; //serializable miatt
	private Sejtautomata sejtautomata; // Sejtautomata objektum
    private JPanel automataPanel; //a rács panelja
    private Timer timer; // Timer az automatikus léptetéshez
    private int lepesszam; // Aktuális lépés száma
    private JLabel lepesszamLabel; // Lépés számát megjelenítő címke
    private JButton startStopButton; // Kezdés/Megállítás gomb
    private JButton resetButton; // Újraindítás gomb
    private JButton randomButton; // Véletlen kitöltés gomb
    private boolean running; // Szimuláció állapota
    private int delay = 800; //Szimuláció késleltetése, alapérték 800ms
    private String szabaly = "B3/S23"; //Szimuláció szabálya, alapérték B3/S23
    private int cellSize; //A cellák mérete a szimulációban
    private int sorok = 11; //sorok száma, ami a méret gombbal állítható, alapértéke 11
    private int oszlopok = 11; //oszlopok száma, ami a méret gombbal állítható, alapértéke 11

    /**
     * @brief Konstruktor az ablak inicializálására.
     *
     * Beállítja az alapvető GUI elemeket, mint a menubar, menük, gombok és
     * a sejtautomata megjelenítő panel.
     */
    public MainFrame() {
        setTitle("Életjáték"); //Ablak neve
        setSize(1000, 800);    //Ablak merete
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        sejtautomata = new Sejtautomata(11,11,"B3/S23"); // Létrehozzuk a Sejtautomata objektumot, alapértékei: 11,11, "B3/S23"
        lepesszam = 0; // Lépés szám inicializálása
        running = false; // Szimuláció állapota

        // Fő menüsor létrehozása
        JMenuBar menuBar = new JMenuBar();
        
        // Fájl menü létrehozása
        JMenu fileMenu = new JMenu("Fájl");
        
        // Fájl mentése menüpont
        JMenuItem saveItem = new JMenuItem("Mentés");
        saveItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sejtautomata.mentesFajlba("sejtautomata_allapot.json"); // JSON alapú mentés
            }
        });
        
        // Fájl betöltése menüpont
        JMenuItem loadItem = new JMenuItem("Betöltés");
        loadItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sejtautomata.betoltesFajlbol("sejtautomata_allapot.json"); // JSON alapú betöltés
                automataPanel.repaint(); // Frissítjük a panelt a betöltött állapot alapján
            }
        });
        
        fileMenu.add(saveItem);
        fileMenu.add(loadItem);
        menuBar.add(fileMenu);
        
        // Szimuláció menü létrehozása
        JMenu simMenu = new JMenu("Szimuláció");

        // Sebesség beállítása menüpont
        JMenuItem setSpeedItem = new JMenuItem("Sebesség");
        setSpeedItem.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(MainFrame.this, "Adja meg a késleltetést (ms):", delay);
            if (input != null) {
                try {
                    delay = Integer.parseInt(input);
                    if (timer != null) {
                        timer.setDelay(delay); // Késleltetés beállítása
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(MainFrame.this, "Kérjük, adjon meg egy számot!");
                }
            }
        });
        
        // Rács méretének beállítása menüpont
        JMenuItem setGridSizeItem = new JMenuItem("Rács méret");
        setGridSizeItem.addActionListener(e -> {
            JTextField sorInput = new JTextField();
            JTextField oszlopInput = new JTextField();
            sorInput.setText(Integer.toString(sorok));
            oszlopInput.setText(Integer.toString(oszlopok));
            Object[] message = {
                "Sorok száma:        (5-100)", sorInput,
                "Oszlopok száma:     (5-100)", oszlopInput
            };
            
            int option = JOptionPane.showConfirmDialog(MainFrame.this, message, "Rács méretének beállítása", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                try {
                    sorok = Integer.parseInt(sorInput.getText());
                    oszlopok = Integer.parseInt(oszlopInput.getText());
                    if (sorok < 5 || oszlopok < 5 || sorok > 100 || oszlopok > 100) {
                        JOptionPane.showMessageDialog(MainFrame.this, "Kérjük, adjon meg 5 és 100 közötti értékeket!");
                        return;
                    }

                    // Rács méretének beállítása az új sorok és oszlopok alapján
                    sejtautomata.setMeret(sorok, oszlopok); // Rácsok méretének beállítása
                    automataPanel.repaint(); // Frissítjük a megjelenítést
                    resetSimulation(); // Újraindítjuk a szimulációt
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(MainFrame.this, "Kérjük, adjon meg érvényes számokat!");
                }
            }
        });
        
        simMenu.add(setSpeedItem); //Hozzáadva a szimulacio menuhoz
        simMenu.add(setGridSizeItem);

        // Szimuláció menü hozzáadása a menüsávhoz
        menuBar.add(simMenu);
        
        String[] szabalyok = {
                "Game of Life (B3/S23)",
                "Saját Szabály...",
                "Day and Night (B3678/S34678)",
                "HighLife (B36/S23)",
                "Seeds (B2/S)",
                "Life without Death (B3/S012345678)",
                "Gnarl (B1/S1)",
                "Replicator (B1357/S1357)",
                "Anneal (B4678/S35678)",
                "Serviettes (B234/S)",
                "Maze (B3/S12345)"
            };

        JComboBox<String> szabalyValaszto = new JComboBox<>(szabalyok);
        szabalyValaszto.addActionListener(e -> {
            String selected = (String) szabalyValaszto.getSelectedItem();
            switch (selected) {
            	case "Saját Szabály...":
            		 szabaly = JOptionPane.showInputDialog(MainFrame.this, "Adja meg a szabályt B../S.. formában", szabaly);
            		 String[] szabalyReszek = szabaly.split("/"); // Szétválasztja a B és S részeket
            	     if(szabalyReszek.length >1) {
            	    	sejtautomata.setSzabaly(szabaly);
            	     } else {
            	    	 JOptionPane.showMessageDialog(this, "Érvénytelen szabály formátum: "+ szabaly, "Hiba", JOptionPane.ERROR_MESSAGE);
        	         }	 
                         
            		break;
                case "Game of Life (B3/S23)":
                    szabaly = "B3/S23";
                    break;
                case "Day and Night (B3678/S34678)":
                    szabaly = "B3678/S34678";
                    break;
                case "HighLife (B36/S23)":
                    szabaly = "B36/S23";
                    break;
                case "Seeds (B2/S)":
                    szabaly = "B2/S";
                    break;
                case "Life without Death (B3/S012345678)":
                    szabaly = "B3/S012345678";
                    break;
                case "Gnarl (B1/S1)":
                    szabaly = "B1/S1";
                    break;
                case "Replicator (B1357/S1357)":
                    szabaly = "B1357/S1357";
                    break;
                case "Anneal (B4678/S35678)":
                    szabaly = "B4678/S35678";
                    break;
                case "Serviettes (B234/S)":
                    szabaly = "B234/S";
                    break;
                case "Maze (B3/S12345)":
                    szabaly = "B3/S12345";
                    break;
            }
            sejtautomata.setSzabaly(szabaly);  // Szabály beállítása
            resetSimulation();  // Szimuláció újraindítása
        });

        // Hozzáadva a szimuláció menühöz
        menuBar.add(szabalyValaszto);
        
        // Menü sáv beállítása
        setJMenuBar(menuBar);


        // GUI komponensek hozzáadása
        Container container = getContentPane();
        container.setLayout(new BorderLayout());


        // Sejtautomata rácsát megjelenítő panel
        automataPanel = new AutomataPanel(sejtautomata);
        automataPanel.setPreferredSize(new Dimension(600,600)); // A sejtaautomata panel mérete
        automataPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int sor = e.getY() / cellSize;
                int oszlop = e.getX() / cellSize;
                sejtautomata.toggleCell(sor, oszlop); // Állapot váltása
                automataPanel.repaint();
            }
        });

        // Középre igazítjuk a sejtaautomata rács panelt
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.add(automataPanel);
        container.add(centerPanel, BorderLayout.CENTER);

        // Lépés számát megjelenítő címke
        lepesszamLabel = new JLabel("Aktuális lépés: " + lepesszam);
        lepesszamLabel.setHorizontalAlignment(SwingConstants.CENTER); // Középre igazítás
        container.add(lepesszamLabel, BorderLayout.NORTH); // Rács alatt helyezkedik el

        // Gombok panel létrehozása
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout()); // Vízszintes elrendezés

        // Start/Stop gomb
        startStopButton = new JButton("Start");
        startStopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!running) {
                    startSimulation();
                } else {
                    stopSimulation();
                }
            }
        });
        
        
        // Újraindítás gomb
        resetButton = new JButton("Újraindítás");
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetSimulation(); // Újraindítás funkció hívása
            }
        });
       
        
        // Véletlen kitöltés
        randomButton = new JButton("Véletlen kitöltés");
        randomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sejtautomata.veletlenInditas();
                automataPanel.repaint();
            }
        });
        
        buttonPanel.add(startStopButton);
        buttonPanel.add(resetButton);
        buttonPanel.add(randomButton);
       
        // Gombok panel hozzáadása
        container.add(buttonPanel, BorderLayout.SOUTH); // Lépés címke alá

        setVisible(true);
    }

    /**
     * @brief Szimuláció indítása.
     *
     * Beállítja az időzítőt és lépteti a sejtautomatát a következő állapotba.
     */
    public void startSimulation() {
        timer = new Timer(delay, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean valtozott = sejtautomata.kovetkezoAllapot(); // Következő állapot
                lepesszam++; // Lépés számának növelése
                lepesszamLabel.setText("Aktuális lépés: " + lepesszam); // Címke frissítése
                automataPanel.repaint(); // Panel újrarajzolása

                if (!valtozott) { // Ha nincs változás, leállítjuk a szimulációt
                    stopSimulation(); // Szimuláció megállítása
                    JOptionPane.showMessageDialog(MainFrame.this, "A szimuláció véget ért.");
                }
            }
        });
        timer.start(); // Timer indítása
        running = true;
        startStopButton.setText("Stop"); // Gomb szövegének váltása
    }

    /**
     * @brief Szimuláció leállítása.
     * Megállítja az időzítőt és frissíti az állapotot.
     */
    public void stopSimulation() {
        if (timer != null) {
            timer.stop(); // Timer leállítása
        }
        running = false;
        startStopButton.setText("Start"); // Gomb szövegének váltása
    }

    /**
     * @brief Szimuláció újraindítása az alapértelmezett állapotba.
     *
     * Visszaállítja a sejtautomata alapállapotát, a lépésszámot
     * és frissíti a GUI elemeket.
     */
    public void resetSimulation() {
        stopSimulation(); // Először megállítjuk a szimulációt, ha fut
        lepesszam = 0; // Lépésszám kinullázása
        lepesszamLabel.setText("Aktuális lépés: " + lepesszam); // Címke frissítése
        sejtautomata.reset(); // Sejtautomata állapotának kinullázása
        automataPanel.repaint(); // Panel újrarajzolása
    }

   
}
