package prog3hf;

import com.google.gson.Gson;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

/**
 * @class FajlKezelo
 * @brief A Sejtautomata állapotának mentésére és betöltésére szolgáló segédosztály.
 */
public class FajlKezelo {

    /**
     * @brief Az automata aktuális rácsállapotának mentése JSON formátumban a megadott fájlba.
     * 
     * @param automata A Sejtautomata objektum, amelynek állapotát menteni kell.
     * @param fajlNev A célfájl neve, ahová az állapotot mentjük.
     */
    public static void mentesFajlba(Sejtautomata automata, String fajlNev) {
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter(fajlNev)) {
            gson.toJson(automata.getRacs(), writer); // A rács JSON formátumban kerül mentésre.
            System.out.println("Állapot mentve a fájlba: " + fajlNev);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @brief Az automata állapotának betöltése JSON formátumból a megadott fájlból.
     * 
     * A betöltött állapot mérete automatikusan módosítja az automata méretét,
     * ha az eltér az aktuális mérettől.
     * 
     * @param automata A Sejtautomata objektum, amelybe az állapotot betöltjük.
     * @param fajlNev A forrásfájl neve, ahonnan az állapotot betöltjük.
     */
    public static void betoltesFajlbol(Sejtautomata automata, String fajlNev) {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader(fajlNev)) {
            int[][] betoltottRacs = gson.fromJson(reader, int[][].class); // JSON rács betöltése.
            int betoltottSorok = betoltottRacs.length;
            int betoltottOszlopok = betoltottRacs[0].length;

            // Méret ellenőrzése és szükség szerinti módosítása.
            if (betoltottSorok != automata.getSorok() || betoltottOszlopok != automata.getOszlopok()) {
                automata.setMeret(betoltottSorok, betoltottOszlopok);
            }
            automata.racs = betoltottRacs;
            System.out.println("Állapot betöltve a fájlból: " + fajlNev);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
