package prog3hf;

import java.io.Serializable;
import java.util.Random;

/**
 * @class Sejtautomata
 * @brief A sejtautomata megvalósítására szolgáló osztály.
 * 
 * Ez az osztály kezeli a rács adatait, a szabályok dinamikus beállítását, 
 * és a sejtautomata működésének alapvető logikáját.
 */
public class Sejtautomata implements Serializable {
    private static final long serialVersionUID = 1L; //mivel serializable
    
    protected int[][] racs;
    private int sorokSzama;
    private int oszlopokSzama;
    private int[] szuletesSzabaly;
    private int[] tulelesSzabaly;
    private Random veletlen = new Random();
    
    /**
     * @brief Konstruktor, amely inicializálja a rácsot és a szabályokat.
     * 
     * @param sorokSzama A rács sorainak száma.
     * @param oszlopokSzama A rács oszlopainak száma.
     * @param szabaly A sejtautomata szabályai B../S.. formátumban.
     */
    public Sejtautomata(int sorokSzama, int oszlopokSzama, String szabaly) {
        this.sorokSzama = sorokSzama;
        this.oszlopokSzama = oszlopokSzama;
        this.racs = new int[sorokSzama][oszlopokSzama];
        SzabalyKezelo.beallitSzabalyok(this, szabaly);
    }
    
    /// @brief Visszaadja a rács oszlopainak számát.
    public int getOszlopok() { return oszlopokSzama; }
    /// @brief Visszaadja a rács sorainak számát.
    public int getSorok() { return sorokSzama; }
    /// @brief Visszaadja a rácsot reprezentáló 2D tömböt.
    public int[][] getRacs() { return racs; }
    
    /**
     * @brief Átváltja egy cella állapotát.
     * 
     * @param sor A cella sora.
     * @param oszlop A cella oszlopa.
     */
    public void toggleCell(int sor, int oszlop) {
        if (sor >= 0 && sor < sorokSzama && oszlop >= 0 && oszlop < oszlopokSzama) {
            racs[sor][oszlop] = (racs[sor][oszlop] == 0) ? 1 : 0;
        }
    }
    
    /// @brief Beállítja az új szabályokat a B../S.. formátumban megadott szabályok alapján.
    public void setSzabaly(String szabaly) {
        SzabalyKezelo.beallitSzabalyok(this, szabaly);
    }
    /**
     * @brief Beállítja a rács méretét és alaphelyzetbe állítja azt.
     * 
     * @param sorok Az új rács sorainak száma.
     * @param oszlopok Az új rács oszlopainak száma.
     */
    public void setMeret(int sorok, int oszlopok) {
        this.sorokSzama = sorok;
        this.oszlopokSzama = oszlopok;
        this.racs = new int[sorok][oszlopok];
        RacsKezelo.reset(this);
    }
    /// @brief Elvégzi a szimuláció következő állapotát.
    public boolean kovetkezoAllapot() {
        return RacsKezelo.kovetkezoAllapot(this);
    }
    /// @brief Véletlenszerűen inicializálja a rács állapotát.
    public void veletlenInditas() {
        for (int sor = 0; sor < sorokSzama; sor++) {
            for (int oszlop = 0; oszlop < oszlopokSzama; oszlop++) {
                racs[sor][oszlop] = veletlen.nextInt(2);
            }
        }
    }
    /**
     * @brief Elmenti az aktuális állapotot egy fájlba.
     * 
     * @param fajlNev A fájl neve.
     */
    public void mentesFajlba(String fajlNev) {
        FajlKezelo.mentesFajlba(this, fajlNev);
    }
    /**
     * @brief Betölti az állapotot egy fájlból.
     * 
     * @param fajlNev A fájl neve.
     */
    public void betoltesFajlbol(String fajlNev) {
        FajlKezelo.betoltesFajlbol(this, fajlNev);
    }
    /// @brief Alaphelyzetbe állítja a rácsot.
    public void reset() {
        RacsKezelo.reset(this);
    }
    
    /// @brief Visszaadja a születés szabályát.
    public int[] getSzuletesSzabaly() { return szuletesSzabaly; }
    /**
     * @brief Beállítja a születés szabályát.
     * 
     * @param szuletesSzabaly A születés szabálya.
     */
    public void setSzuletesSzabaly(int[] szuletesSzabaly) { this.szuletesSzabaly = szuletesSzabaly; }
    /// @brief Visszaadja a tulélés szabályát.
    public int[] getTulelesSzabaly() { return tulelesSzabaly; }
    /**
     * @brief Beállítja a túlélés szabályát.
     * 
     * @param tulelesSzabaly A túlélés szabálya.
     */
    public void setTulelesSzabaly(int[] tulelesSzabaly) { this.tulelesSzabaly = tulelesSzabaly; }

    /**
     * @brief Ellenőrzi, hogy egy sejt túlél-e a szomszédainak száma alapján.
     * 
     * @param szomszedokSzama A sejt szomszédjainak száma.
     */
    public boolean tulel(int szomszedokSzama) {
        for (int szabaly : tulelesSzabaly) {
            if (szabaly == szomszedokSzama) {
                return true;
            }
        }
        return false;
    }
    /**
     * @brief Ellenőrzi, hogy egy sejt születik-e a szomszédainak száma alapján.
     * 
     * @param szomszedokSzama A sejt szomszédjainak száma.
     */
    public boolean szuletik(int szomszedokSzama) {
        for (int szabaly : szuletesSzabaly) {
            if (szabaly == szomszedokSzama) {
                return true;
            }
        }
        return false;
    }
}
