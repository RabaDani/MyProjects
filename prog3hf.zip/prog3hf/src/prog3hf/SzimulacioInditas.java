package prog3hf;

import javax.swing.SwingUtilities;

/**
 * @class SzimulacioInditas
 * @brief A sejtautomata szimulációjának indításáért felelős osztály.
 */
public class SzimulacioInditas {
	 /**
     * @brief A program belépési pontja.
     * @param args Parancssori argumentumok (nem használt).
     * 
     * A Swing GUI indítása egy külön szálban történik az EDT-n (Event Dispatch Thread).
     */
	 public static void main(String[] args) {
	        SwingUtilities.invokeLater(new Runnable() {
	            @Override
	            public void run() {
	                MainFrame frame = new MainFrame();
	                frame.setVisible(true);
	            }
	        });
	    }

}
