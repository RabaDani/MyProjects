package prog3hf;

/**
 * @class SzabalyKezelo
 * @brief A Sejtautomata szabályainak beállításáért felelős osztály.
 */
public class SzabalyKezelo {

    /**
     * @brief Beállítja az automata születési és túlélési szabályait a megadott szöveg alapján.
     * 
     * A szabály formátuma B../S.., például "B3/S23". Az első rész (B..) a születési szabályok,
     * míg a második rész (S..) a túlélési szabályok számjegyeit tartalmazza.
     * 
     * @param automata A kezelt Sejtautomata objektum.
     * @param szabaly A szabályokat tartalmazó szöveg formátumban (B../S..).
     */
    public static void beallitSzabalyok(Sejtautomata automata, String szabaly) {
        String[] szabalyReszek = szabaly.split("/"); // Születési és túlélési rész szétválasztása.
        if (szabalyReszek.length > 1) {
            // Születési szabályok feldolgozása.
            int[] szuletes = new int[szabalyReszek[0].length() - 1];
            for (int i = 1; i < szabalyReszek[0].length(); i++) {
                szuletes[i - 1] = Character.getNumericValue(szabalyReszek[0].charAt(i));
            }
            automata.setSzuletesSzabaly(szuletes);

            // Túlélési szabályok feldolgozása.
            int[] tuleles = new int[szabalyReszek[1].length() - 1];
            for (int i = 1; i < szabalyReszek[1].length(); i++) {
                tuleles[i - 1] = Character.getNumericValue(szabalyReszek[1].charAt(i));
            }
            automata.setTulelesSzabaly(tuleles);
        }
    }
}
