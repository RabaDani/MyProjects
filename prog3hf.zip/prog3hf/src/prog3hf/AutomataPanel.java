package prog3hf;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

/**
 * @class AutomataPanel
 * @brief Az osztály felelős a sejtautomata grafikus megjelenítéséért és a felhasználói interakciók kezeléséért.
 */
public class AutomataPanel extends JPanel {
 private static final long serialVersionUID = 1L; //serializable miatt
 
 private Sejtautomata sejtautomata;
 private int cellSize;
 
 /**
  * @brief Konstruktor, amely inicializálja a sejtautomata panelt.
  * @param sejtautomata A megjelenítendő sejtautomata modell.
  * 
  * Az egérkattintásokat kezeli: az adott pozícióban lévő sejt állapotát váltja.
  */
 public AutomataPanel(Sejtautomata sejtautomata) {
     this.sejtautomata = sejtautomata;
     addMouseListener(new MouseAdapter() {
    	 /**
          * @brief Az egérkattintás eseménykezelője.
          * @param e Az egér esemény objektuma.
          */
         @Override
         public void mouseClicked(MouseEvent e) {
             int sor = e.getY() / cellSize;
             int oszlop = e.getX() / cellSize;
             sejtautomata.toggleCell(sor, oszlop);
             repaint();
         }
     });
 }
 	
 /**
  * @brief Megjeleníti a sejtautomatát a panelen.
  * @param g A Graphics objektum, amely a rajzoláshoz szükséges.
  */
 public void megjelenit(Graphics g) {
	    cellSize = Math.min(getWidth() / sejtautomata.getOszlopok(), getHeight() / sejtautomata.getSorok()); 
	    for (int sor = 0; sor < sejtautomata.getSorok(); sor++) {
	        for (int oszlop = 0; oszlop < sejtautomata.getOszlopok(); oszlop++) {
	            if (sejtautomata.getRacs()[sor][oszlop] == 1) {
	                g.setColor(Color.BLACK); // Élő sejt színe
	            } else {
	                g.setColor(Color.WHITE); // Halott sejt színe
	            }
	            g.fillRect(oszlop * cellSize, sor * cellSize, cellSize, cellSize);
	            g.setColor(Color.DARK_GRAY); // Rácsvonalak
	            g.drawRect(oszlop * cellSize, sor * cellSize, cellSize, cellSize);
	        }
	    }
	}
 /**
  * @brief A JPanel újrarajzolásakor meghívott metódus.
  * @param g A Graphics objektum, amely a rajzoláshoz szükséges.
  */
 @Override
 protected void paintComponent(Graphics g) {
     super.paintComponent(g);
     megjelenit(g);
 }
}
