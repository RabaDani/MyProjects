package prog3hf;

import org.junit.jupiter.api.*;
import java.io.File;
import static org.junit.jupiter.api.Assertions.*;

public class FajlKezeloTest {

    private Sejtautomata automata;
    private static final String FILE_NAME = "test_state.json";

    @BeforeEach
    public void setUp() {
        // Tesztadatok előkészítése
        automata = new Sejtautomata(5, 5, "B3/S23"); // 5x5 méret, szabályok beállítva
        automata.veletlenInditas(); // Véletlenszerűen generált állapot
    }

    @AfterEach
    public void tearDown() {
        // Teszt után fájl törlése
        File file = new File(FILE_NAME);
        if (file.exists()) {
            file.delete();
        }
    }

    @Test
    public void testMentesFajlba() {
        // Fájlba mentés
        FajlKezelo.mentesFajlba(automata, FILE_NAME);

        // Ellenőrzés, hogy a fájl létezik
        File file = new File(FILE_NAME);
        assertTrue(file.exists(), "A fájl létrejött.");
    }

    @Test
    public void testBetoltesFajlbol() {
        // Fájlba mentés
        FajlKezelo.mentesFajlba(automata, FILE_NAME);

        // Új automata objektum létrehozása
        Sejtautomata ujAutomata = new Sejtautomata(5, 5, "B3/S23");

        // Fájl betöltése
        FajlKezelo.betoltesFajlbol(ujAutomata, FILE_NAME);

        // Ellenőrzés, hogy a betöltött állapot megegyezik az eredetivel
        int[][] eredetiRacs = automata.getRacs();
        int[][] betoltottRacs = ujAutomata.getRacs();

        assertEquals(eredetiRacs.length, betoltottRacs.length, "A sorok száma megegyezik.");
        assertEquals(eredetiRacs[0].length, betoltottRacs[0].length, "Az oszlopok száma megegyezik.");

        // További ellenőrzés az egyes sejtek értékeinek megfelelően
        for (int i = 0; i < eredetiRacs.length; i++) {
            for (int j = 0; j < eredetiRacs[i].length; j++) {
                assertEquals(eredetiRacs[i][j], betoltottRacs[i][j], "A sejtek értékei megegyeznek a sor: " + i + ", oszlop: " + j);
            }
        }
    }

    @Test
    public void testBetoltesFajlbolMeretValtozas() {
        // Fájlba mentés
        FajlKezelo.mentesFajlba(automata, FILE_NAME);

        // Létrehozunk egy új automata objektumot más mérettel
        Sejtautomata ujAutomata = new Sejtautomata(10, 10, "B3/S23");

        // Fájl betöltése
        FajlKezelo.betoltesFajlbol(ujAutomata, FILE_NAME);

        // Ellenőrzés, hogy az új méretet is megfelelően beállította
        assertEquals(5, ujAutomata.getSorok(), "A sorok száma megfelelő.");
        assertEquals(5, ujAutomata.getOszlopok(), "Az oszlopok száma megfelelő.");
    }
}
