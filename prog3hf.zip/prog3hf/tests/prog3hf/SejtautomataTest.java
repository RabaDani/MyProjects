package prog3hf;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SejtautomataTest {

    private Sejtautomata sejtautomata;

    @BeforeEach
    public void setUp() {
        // Előkészítjük a tesztelést
        sejtautomata = new Sejtautomata(5, 5, "B3/S23");
    }

    @Test
    public void testKonstruktor() {
        // Teszteljük, hogy a konstruktor megfelelően inicializálja az osztályt
        assertNotNull(sejtautomata.getRacs());
        assertEquals(5, sejtautomata.getSorok());
        assertEquals(5, sejtautomata.getOszlopok());
    }

    @Test
    public void testToggleCell() {
        // Teszteljük a cellák állapotának váltását
        sejtautomata.toggleCell(2, 2);
        assertEquals(1, sejtautomata.getRacs()[2][2]);
        sejtautomata.toggleCell(2, 2);
        assertEquals(0, sejtautomata.getRacs()[2][2]);
    }

    @Test
    public void testSetSzabaly() {
        // Teszteljük a szabályok beállítását
        sejtautomata.setSzabaly("B36/S23");
        assertArrayEquals(new int[]{3, 6}, sejtautomata.getSzuletesSzabaly());
        assertArrayEquals(new int[]{2, 3}, sejtautomata.getTulelesSzabaly());
    }

    @Test
    public void testVeletlenInditas() {
        // Teszteljük a véletlenszerű indítást
        sejtautomata.veletlenInditas();
        int[][] racs = sejtautomata.getRacs();
        // Mivel a véletlen értékek 0 vagy 1 lehetnek, biztosítjuk, hogy a cellák értéke 0 vagy 1
        for (int i = 0; i < sejtautomata.getSorok(); i++) {
            for (int j = 0; j < sejtautomata.getOszlopok(); j++) {
                assertTrue(racs[i][j] == 0 || racs[i][j] == 1);
            }
        }
    }

    @Test
    public void testTulelesiSzabaly() {
        // Teszteljük a túlélési szabályokat
        sejtautomata.setTulelesSzabaly(new int[]{2, 3, 4});
        assertTrue(sejtautomata.tulel(3));  // 3 szomszédos sejt túlélési szabály
        assertFalse(sejtautomata.tulel(1)); // 1 szomszédos sejt nem túlélési szabály
    }

    @Test
    public void testSzuletesiSzabaly() {
        // Teszteljük a születési szabályokat
        sejtautomata.setSzuletesSzabaly(new int[]{3});
        assertTrue(sejtautomata.szuletik(3));  // 3 szomszédos sejt születési szabály
        assertFalse(sejtautomata.szuletik(2)); // 2 szomszédos sejt nem születési szabály
    }

    @Test
    public void testReset() {
        // Teszteljük a grid resetelését
        sejtautomata.toggleCell(2, 2);
        sejtautomata.reset();
        assertEquals(0, sejtautomata.getRacs()[2][2]);
    }

    @Test
    public void testSetMeret() {
        // Teszteljük a grid méretének változtatását
        sejtautomata.setMeret(10, 10);
        assertEquals(10, sejtautomata.getSorok());
        assertEquals(10, sejtautomata.getOszlopok());
    }
}
