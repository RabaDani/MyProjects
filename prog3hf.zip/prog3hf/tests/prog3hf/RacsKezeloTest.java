package prog3hf;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class RacsKezeloTest {

    private Sejtautomata automata;

    @BeforeEach
    public void setUp() {
        // Tesztadatok előkészítése (5x5 rács, alapértelmezett szabályokkal)
        automata = new Sejtautomata(5, 5, "B3/S23");
        
        /* 00000
         * 00100
         * 01010
         * 00000
         * 00000
         */
        automata.toggleCell(1,2);  
        automata.toggleCell(2,1);  
        automata.toggleCell(2,3);  

    }

    @Test
    public void testKovetkezoAllapotValtozas() {
        int[][] elozoAllapot = new int[automata.getSorok()][automata.getOszlopok()];
        for (int sor = 0; sor < automata.getSorok(); sor++) {
            for (int oszlop = 0; oszlop < automata.getOszlopok(); oszlop++) {
                elozoAllapot[sor][oszlop] = automata.getRacs()[sor][oszlop];
            }
        }

        // Következő állapot frissítése
        boolean valtozott = RacsKezelo.kovetkezoAllapot(automata);

        // Ellenőrzés, hogy történt-e változás
        assertTrue(valtozott, "A rács állapota változott.");

        // Ellenőrizzük, hogy az új állapot nem egyezik az előzővel (ha valóban változott)
        for (int sor = 0; sor < automata.getSorok(); sor++) {
            for (int oszlop = 0; oszlop < automata.getOszlopok(); oszlop++) {
                if (elozoAllapot[sor][oszlop] != automata.getRacs()[sor][oszlop]) {
                    return; // Ha van eltérés, akkor sikeres a teszt
                }
            }
        }
        fail("A rács állapota nem változott.");
    }

    @Test
    public void testReset() {
        // Állapot beállítása
        automata.getRacs()[2][2] = 1;  // Véletlenszerűen beállítunk egy értéket

        // Reset hívása
        RacsKezelo.reset(automata);

        // Ellenőrzés, hogy minden cella 0-ra lett állítva
        for (int sor = 0; sor < automata.getSorok(); sor++) {
            for (int oszlop = 0; oszlop < automata.getOszlopok(); oszlop++) {
                assertEquals(0, automata.getRacs()[sor][oszlop], "A rács minden cellájának nullának kell lennie.");
            }
        }
    }

    @Test
    public void testSzomszedokSzama() {

        // Ellenőrizzük, hogy a középső cella szomszédainak száma 3
        int szomszedok = RacsKezelo.szomszedokSzama(automata, 2, 2);
        assertEquals(3, szomszedok, "A középső cella szomszédainak száma helytelen.");
    }
}
