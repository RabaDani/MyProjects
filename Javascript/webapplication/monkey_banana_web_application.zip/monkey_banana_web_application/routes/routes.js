const express = require('express');
const router = express.Router();

function setupRoutes(monkeyController, bananaController, searchController) {
    // Monkey routes
    router.get('/monkey', monkeyController.getAllMonkeys);
    router.get('/monkey/:id', monkeyController.getMonkeyById);
    router.post('/monkey', monkeyController.createMonkey);
    router.put('/monkey/:id', monkeyController.updateMonkey);
    router.delete('/monkey/:id', monkeyController.deleteMonkey);

    // Banana routes
    router.get('/banana', bananaController.getAllBananas);
    router.get('/banana/:id', bananaController.getBananaById);
    router.post('/banana', bananaController.createBanana);
    router.put('/banana/:id', bananaController.updateBanana);
    router.delete('/banana/:id', bananaController.deleteBanana);

    // Search route
    router.post('/search', searchController.search);

    return router;
}

function setupViewRoutes(viewController) {
    const router = express.Router();
    
    // Home page route
    router.get('/', viewController.getHomePage);
    
    // Form page routes
    router.get('/form', viewController.getFormPage);
    router.post('/form', viewController.handleFormSubmission);
    
    return router;
}

module.exports = { setupRoutes, setupViewRoutes };