class BananaController {
    constructor(bananaRepository) {
        this.bananaRepository = bananaRepository;
    }

    getAllBananas = (req, res) => {
        try {
            const bananas = this.bananaRepository.findAll();
            res.json(bananas);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    getBananaById = (req, res) => {
        try {
            const banana = this.bananaRepository.findById(req.params.id);
            if (!banana) {
                return res.status(404).json({ error: `Banana not found with id: ${req.params.id}` });
            }
            res.json(banana);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    createBanana = (req, res) => {
        try {
            const { color, sweet, monkeyId } = req.body;
            
            if (color === undefined || sweet === undefined || monkeyId === undefined) {
                return res.status(400).json({ error: 'Missing banana information: color, sweet, and monkeyId are required' });
            }

            const newBanana = this.bananaRepository.create({ color, sweet, monkeyId });
            res.status(201).json(newBanana);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    updateBanana = (req, res) => {
        try {
            const updatedBanana = this.bananaRepository.update(req.params.id, req.body);
            if (!updatedBanana) {
                return res.status(404).json({ error: `Banana not found with id: ${req.params.id}` });
            }
            res.json(updatedBanana);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    deleteBanana = (req, res) => {
        try {
            const deletedBanana = this.bananaRepository.delete(req.params.id);
            if (!deletedBanana) {
                return res.status(404).json({ error: `Banana not found with id: ${req.params.id}` });
            }
            res.json(deletedBanana);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }
}

module.exports = BananaController;