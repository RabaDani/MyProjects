class SearchController {
    constructor(databaseService) {
        this.databaseService = databaseService;
    }

    search = (req, res) => {
        try {
            const { search } = req.body;
            
            if (!search) {
                return res.status(400).json({ error: 'Missing search parameter' });
            }

            const results = this.databaseService.search(search);
            res.json(results);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }
}

module.exports = SearchController;