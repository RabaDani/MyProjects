class MonkeyController {
    constructor(monkeyRepository) {
        this.monkeyRepository = monkeyRepository;
    }

    getAllMonkeys = (req, res) => {
        try {
            const monkeys = this.monkeyRepository.findAll();
            res.json(monkeys);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    getMonkeyById = (req, res) => {
        try {
            const monkey = this.monkeyRepository.findById(req.params.id);
            if (!monkey) {
                return res.status(404).json({ error: `Monkey not found with id: ${req.params.id}` });
            }
            res.json(monkey);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    createMonkey = (req, res) => {
        try {
            const { name, gender, type } = req.body;
            
            if (!name || !gender || !type) {
                return res.status(400).json({ error: 'Missing information: name, gender, and type are required' });
            }

            const newMonkey = this.monkeyRepository.create({ name, gender, type });
            res.status(201).json(newMonkey);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    updateMonkey = (req, res) => {
        try {
            const updatedMonkey = this.monkeyRepository.update(req.params.id, req.body);
            if (!updatedMonkey) {
                return res.status(404).json({ error: `Monkey not found with id: ${req.params.id}` });
            }
            res.json(updatedMonkey);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    deleteMonkey = (req, res) => {
        try {
            const deletedMonkey = this.monkeyRepository.delete(req.params.id);
            if (!deletedMonkey) {
                return res.status(404).json({ error: `Monkey not found with id: ${req.params.id}` });
            }
            res.json(deletedMonkey);
        } catch (error) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }
}

module.exports = MonkeyController;