class ViewController {
    constructor(databaseService) {
        this.databaseService = databaseService;
    }

    getHomePage = async (req, res) => {
        try {
            const monkeys = this.databaseService.getMonkeyRepository().findAll();
            const bananas = this.databaseService.getBananaRepository().findAll();
            
            res.render('index', {
                title: 'Monkey & Banana Manager',
                monkeys: monkeys,
                bananas: bananas,
                searchTerm: ''
            });
        } catch (error) {
            console.error('Error loading data:', error);
            res.render('index', {
                title: 'Monkey & Banana Manager',
                monkeys: [],
                bananas: [],
                searchTerm: '',
                error: 'Error loading data'
            });
        }
    }

    getFormPage = async (req, res) => {
        const { type, id } = req.query;
        let item = null;
        let monkeys = [];

        try {
            // Get all monkeys for banana form dropdown
            monkeys = this.databaseService.getMonkeyRepository().findAll();

            // If editing, get the item data
            if (id) {
                if (type === 'monkey') {
                    item = this.databaseService.getMonkeyRepository().findById(id);
                } else if (type === 'banana') {
                    item = this.databaseService.getBananaRepository().findById(id);
                }
            }

            res.render('form', {
                title: type === 'monkey' ? 'Monkey Form' : 'Banana Form',
                type: type,
                item: item,
                monkeys: monkeys,
                isEdit: !!id
            });
        } catch (error) {
            console.error('Error loading form data:', error);
            res.render('form', {
                title: 'Form',
                type: type || 'monkey',
                item: null,
                monkeys: [],
                isEdit: false,
                error: 'Error loading form data'
            });
        }
    }

    handleFormSubmission = async (req, res) => {
        const { type, id } = req.query;
        
        try {
            if (type === 'monkey') {
                if (id) {
                    // Update existing monkey
                    this.databaseService.getMonkeyRepository().update(id, req.body);
                } else {
                    // Create new monkey
                    this.databaseService.getMonkeyRepository().create(req.body);
                }
            } else if (type === 'banana') {
                // Convert sweet to boolean
                if (req.body.sweet) {
                    req.body.sweet = req.body.sweet === 'true';
                }
                
                if (id) {
                    // Update existing banana
                    this.databaseService.getBananaRepository().update(id, req.body);
                } else {
                    // Create new banana
                    this.databaseService.getBananaRepository().create(req.body);
                }
            }
            
            res.redirect('/?success=1');
        } catch (error) {
            console.error('Error saving data:', error);
            const monkeys = this.databaseService.getMonkeyRepository().findAll();
            res.render('form', {
                title: type === 'monkey' ? 'Monkey Form' : 'Banana Form',
                type: type,
                item: req.body,
                monkeys: monkeys,
                isEdit: !!id,
                error: 'Error saving data. Please try again.'
            });
        }
    }
}

module.exports = ViewController;