const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

// Services
const DatabaseService = require('./services/DatabaseService');

// Controllers
const MonkeyController = require('./controllers/MonkeyController');
const BananaController = require('./controllers/BananaController');
const SearchController = require('./controllers/SearchController');
const ViewController = require('./controllers/ViewController');

// Routes
const { setupRoutes, setupViewRoutes } = require('./routes/routes');

class App {
    constructor() {
        this.app = express();
        this.port = 6060;
        
        this.initializeDatabase();
        this.initializeControllers();
        this.initializeViewEngine();
        this.initializeMiddleware();
        this.initializeRoutes();
        this.initializeStaticFiles();
    }

    initializeDatabase() {
        this.databaseService = new DatabaseService();
    }

    initializeControllers() {
        // Dependency injection
        this.monkeyController = new MonkeyController(
            this.databaseService.getMonkeyRepository()
        );
        this.bananaController = new BananaController(
            this.databaseService.getBananaRepository()
        );
        this.searchController = new SearchController(
            this.databaseService
        );
        this.viewController = new ViewController(
            this.databaseService
        );
    }

    initializeViewEngine() {
        // Set EJS as the view engine
        this.app.set('view engine', 'ejs');
        this.app.set('views', path.join(__dirname, 'views'));
    }

    initializeMiddleware() {
        this.app.use(bodyParser.json());
        this.app.use(bodyParser.urlencoded({ extended: true }));
    }

    initializeRoutes() {
        // API routes
        const apiRoutes = setupRoutes(
            this.monkeyController,
            this.bananaController,
            this.searchController
        );
        this.app.use('/api', apiRoutes);

        // View routes
        const viewRoutes = setupViewRoutes(this.viewController);
        this.app.use('/', viewRoutes);
    }

    initializeStaticFiles() {
        this.app.use(express.static(path.join(__dirname, 'public')));
    }

    listen() {
        this.app.listen(this.port, () => {
            console.log(`Server running on port ${this.port}`);
            console.log(`Visit http://localhost:${this.port} to view the application`);
        });
    }
}

const app = new App();
app.listen();