# Monkey & Banana Manager

A full-stack web application built with Express.js and EJS for managing monkeys and bananas.

## Features

- **CRUD Operations**: Create, Read, Update, Delete monkeys and bananas
- **Search Functionality**: Search across monkeys and bananas
- **Responsive Design**: Bootstrap-powered UI that works on all devices
- **Real-time Validation**: Form validation with visual feedback
- **Statistics Dashboard**: View counts and data at a glance
- **RESTful API**: Well-structured API endpoints

## Technology Stack

- **Backend**: Node.js, Express.js
- **Templating**: EJS (Embedded JavaScript)
- **Frontend**: Bootstrap 5, Font Awesome, JavaScript
- **Data Storage**: In-memory (can be extended to use databases)

## Project Structure

```
├── index.js                 # Main application file
├── controllers/
│   ├── MonkeyController.js   # Monkey CRUD operations
│   ├── BananaController.js   # Banana CRUD operations
│   └── SearchController.js   # Search functionality
├── services/
│   └── DatabaseService.js    # Database service (to be implemented)
├── routes/
│   └── routes.js            # API route definitions
├── views/
│   ├── layout.ejs           # Main layout template
│   ├── index.ejs            # Dashboard view
│   └── form.ejs             # Create/Edit form view
├── public/                  # Static files (CSS, JS, images)
└── package.json            # Dependencies and scripts
```

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd monkey-banana-manager
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Create the views directory**
   ```bash
   mkdir views
   ```

4. **Create the EJS template files**
   - Copy the `layout.ejs` content to `views/layout.ejs`
   - Copy the `index.ejs` content to `views/index.ejs`  
   - Copy the `form.ejs` content to `views/form.ejs`

5. **Create required directories**
   ```bash
   mkdir controllers services routes public
   ```

6. **Implement the missing service files** (DatabaseService, repositories, etc.)

## Running the Application

### Development Mode
```bash
npm run dev
```

### Production Mode
```bash
npm start
```

The application will be available at `http://localhost:6001`

## API Endpoints

### Monkeys
- `GET /api/monkey` - Get all monkeys
- `GET /api/monkey/:id` - Get monkey by ID
- `POST /api/monkey` - Create new monkey
- `PUT /api/monkey/:id` - Update monkey
- `DELETE /api/monkey/:id` - Delete monkey

### Bananas
- `GET /api/banana` - Get all bananas
- `GET /api/banana/:id` - Get banana by ID
- `POST /api/banana` - Create new banana
- `PUT /api/banana/:id` - Update banana
- `DELETE /api/banana/:id` - Delete banana

### Search
- `POST /api/search` - Search monkeys and bananas

## Data Models

### Monkey
```javascript
{
  id: String,
  name: String,
  gender: String, // 'male' or 'female'
  type: String    // e.g., 'Chimpanzee', 'Orangutan'
}
```

### Banana
```javascript
{
  id: String,
  color: String,
  sweet: Boolean,
  monkeyId: String // Reference to monkey
}
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Next Steps

To complete the implementation:

1. **Implement DatabaseService**: Create a proper database service with repositories
2. **Add Data Persistence**: Integrate with MongoDB, PostgreSQL, or another database
3. **Add Authentication**: Implement user login/registration
4. **Add File Upload**: Allow image uploads for monkeys
5. **Add Data Export**: Export data to CSV/PDF
6. **Add Unit Tests**: Implement testing with Jest or Mocha
7. **Add API Documentation**: Use Swagger/OpenAPI
8. **Deploy**: Deploy to Heroku, Vercel, or another platform

## Screenshots

The application features:
- A modern dashboard with statistics cards
- Tabbed interface for monkeys and bananas
- Responsive forms with real-time validation
- Search functionality across all data
- Confirmation modals for delete operations
- Professional styling with Bootstrap and Font Awesome icons