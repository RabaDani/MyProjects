const loki = require('lokijs');
const Repository = require('../repository/Repository');

class DatabaseService {
    constructor() {
        this.db = new loki('data.db');
        this.initializeCollections();
        this.seedData();
    }

    initializeCollections() {
        this.monkeyCollection = this.db.addCollection('monkeys');
        this.bananaCollection = this.db.addCollection('bananas');
        
        this.monkeyRepository = new Repository(this.monkeyCollection);
        this.bananaRepository = new Repository(this.bananaCollection);
    }

    seedData() {
        // Seed monkeys
        this.monkeyCollection.insert([
            { id: 1, name: "feri", gender: "male", type: "nagy" },
            { id: 2, name: "belus", gender: "male", type: "kicsi" }
        ]);

        // Seed bananas
        this.bananaCollection.insert([
            { id: 1, color: "yellow", sweet: true, monkeyId: 1 },
            { id: 2, color: "red", sweet: true, monkeyId: 1 }
        ]);
    }

    getMonkeyRepository() {
        return this.monkeyRepository;
    }

    getBananaRepository() {
        return this.bananaRepository;
    }

    search(searchTerm) {
        const monkeyResults = this.monkeyRepository.search(searchTerm, ['name', 'type']);
        const bananaResults = this.bananaRepository.search(searchTerm, ['color']);
        
        return {
            monkeys: monkeyResults,
            bananas: bananaResults
        };
    }
}

module.exports = DatabaseService;