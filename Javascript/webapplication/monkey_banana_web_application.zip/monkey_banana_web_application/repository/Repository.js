class Repository {
    constructor(collection) {
        this.collection = collection;
    }

    findAll() {
        return this.collection.find();
    }

    findById(id) {
        return this.collection.findOne({ id: parseInt(id) });
    }

    create(data) {
        const maxId = this.collection.max('id');
        const newId = maxId ? maxId + 1 : 1;
        const newItem = { ...data, id: newId };
        return this.collection.insert(newItem);
    }

    update(id, data) {
        const item = this.findById(id);
        if (!item) return null;
        
        Object.keys(data).forEach(key => {
            if (data[key] !== undefined) {
                item[key] = data[key];
            }
        });
        
        this.collection.update(item);
        return item;
    }

    delete(id) {
        const item = this.findById(id);
        if (!item) return null;
        
        this.collection.remove(item);
        return item;
    }

    search(searchTerm, fields) {
        const term = searchTerm.toLowerCase();
        return this.collection.find({
            '$or': fields.map(field => ({
                [field]: { '$regex': new RegExp(term, 'i') }
            }))
        });
    }
}

module.exports = Repository;