#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <filesystem>
#include <algorithm>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// cs�cspont reprezent�ci�ja: (x, y, z) koordin�t�k
struct Vertex {
    float x, y, z;

    Vertex(float x = 0, float y = 0, float z = 0)
        : x(x), y(y), z(z) {
    }
};

// h�romsz�g (face) reprezent�ci�ja: h�rom cs�cspont indexe (�ramutat� j�r�s�val ellent�tes)
struct Face {
    int v1, v2, v3; 

    Face(int a, int b, int c) : v1(a), v2(b), v3(c) {}
};

// magass�gt�rk�pb�l h�romsz�gmesh-t k�sz�t� oszt�ly
class HeightmapMesh {
private:
    std::vector<Vertex> vertices;  // cs�csok list�ja
	std::vector<Face> faces;	// h�romsz�gek list�ja
	std::vector<std::vector<int>> vertexIndexMap; // (x,y) poz�ci�hoz rendeli a vertex index�t a verices list�ban
    int width, height;

public:
    // k�p bet�lt�se magass�gt�rk�pk�nt
    bool loadHeightmap(const std::string& filename) {
        int channels;
        unsigned char* data = stbi_load(filename.c_str(), &width, &height, &channels, 1); //egy csatorn�val t�ltj�k be (grayscale) (0�255)

        if (data==NULL) {
            std::cerr << "Failed to load image: " << filename << std::endl;
            return false;
        }

        std::cout << "Loaded heightmap: " << width << "x" << height << " pixels" << std::endl;

        // vertexIndexMap inicializ�l�sa
        vertexIndexMap.resize(height);
        for (int i = 0; i < height; i++) {
			vertexIndexMap[i].resize(width, -1); // -1 alap�rt�k: irrelev�ns vertex (z==0)
        }

        generateVertices(data);
        generateFaces();

		// mem�ria felszabad�t�sa
        stbi_image_free(data);
        return true;
    }

private:
    // vertexek gener�l�sa a magass�g�rt�kek alapj�n
    void generateVertices(unsigned char* heightData) {
        vertices.clear();

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int pixelIndex = y * width + x;
                unsigned char heightValue = heightData[pixelIndex];

                // magass�g transzform�l�sa a [0, 200] intervallumra
                float z = (heightValue / 255.0f) * 200.0f;

				// B�NUSZ: Ha a magass�g 0, akkor kihagyjuk a cs�csot (irrelev�ns)
                if (z == 0.0f) {
                    continue;
                }

                // vertex l�trehoz�sa (x, y a k�p koordin�t�i, z a magass�g)
                Vertex vertex(static_cast<float>(x), static_cast<float>(y), z);
                vertices.push_back(vertex);

                // vertex index�nek elt�rol�sa
                vertexIndexMap[y][x] = vertices.size() - 1;
            }
        }

        std::cout << "Generated " << vertices.size() << " vertices (excluding height=0 vertices)" << std::endl;
    }

    // h�romsz�gek gener�l�sa a szomsz�dos vertexekb�l
    void generateFaces() {
        faces.clear();

        for (int y = 0; y < height - 1; y++) {
            for (int x = 0; x < width - 1; x++) {
                // n�gyzet sarkaiban l�v� vertex indexek lek�rdez�se
                int topLeft = vertexIndexMap[y][x];
                int topRight = vertexIndexMap[y][x + 1];
                int bottomLeft = vertexIndexMap[y + 1][x];
                int bottomRight = vertexIndexMap[y + 1][x + 1];

                // ha b�rmelyik vertex irrelev�ns (z==0), kihagyjuk
                if (topLeft == -1 || topRight == -1 || bottomLeft == -1 || bottomRight == -1) {
                    continue;
                }

                // 2db h�romsz�get hozunk l�tre az aktu�lis n�gyzetb�l
                // triangle 1: topLeft, bottomLeft, topRight (�ramutat� j�r�s�val ellent�tes)
                faces.push_back(Face(topLeft, bottomLeft, topRight));

                // triangle 2: topRight, bottomLeft, bottomRight (�ramutat� j�r�s�val ellent�tes)
                faces.push_back(Face(topRight, bottomLeft, bottomRight));
            }
        }

        std::cout << "Generated " << faces.size() << " faces" << std::endl;
    }

public:
    // h�romsz�gmesh export�l�sa OBJ f�jlba
    bool exportOBJ(const std::string& filename) {
        std::ofstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Failed to create OBJ file: " << filename << std::endl;
            return false;
        }

        file << "# Heightmap mesh generated from heightmap image\n";
        file << "# Vertices: " << vertices.size() << "\n";
        file << "# Faces: " << faces.size() << "\n\n";

        // vertexek ki�r�sa
        for (const auto& vertex : vertices) {
            file << "v " << vertex.x << " " << vertex.y << " " << vertex.z << "\n";
        }

        file << "\n";

        // h�romsz�gek ki�r�sa (OBJ: 1-alap� indexel�s)
        for (const auto& face : faces) {
            file << "f " << (face.v1 + 1) << " " << (face.v2 + 1) << " " << (face.v3 + 1) << "\n";
        }

        file.close();
        std::cout << "Successfully exported mesh to: " << filename << std::endl;
        return true;
    }

    // statisztik�k ki�r�sa konzolra
    void printStats() {
        std::cout << "\nMesh Statistics:" << std::endl;
        std::cout << "- Vertices: " << vertices.size() << std::endl;
        std::cout << "- Faces: " << faces.size() << std::endl;
        std::cout << "- Image dimensions: " << width << "x" << height << std::endl;
    }
};

int main() {
    std::string inputFolder = "heightmaps";
    std::string outputFolder = "result";

    // bemeneti mappa ellen�rz�se
    if (!std::filesystem::exists(inputFolder)) {
        std::cerr << "Error: "<< inputFolder <<" folder not found!" << std::endl;
        return 1;
    }

	// kimeneti mappa, l�trehozz�sa, ha m�g nem l�tezik
    if (!std::filesystem::exists(outputFolder)) {
        std::filesystem::create_directory(outputFolder);
        std::cout << "Created "<< outputFolder <<" folder" << std::endl;
    }

    // PNG f�jlok keres�se a bemeneti mapp�ban
    std::vector<std::string> pngFiles;
    for (const auto& entry : std::filesystem::directory_iterator(inputFolder)) {
        if (entry.is_regular_file()) {
            std::string filename = entry.path().filename().string();
            std::string extension = entry.path().extension().string();

            // kiterjeszt�s kisbet�s�t�se
            std::transform(extension.begin(), extension.end(), extension.begin(), ::tolower);

            if (extension == ".png") {
                pngFiles.push_back(entry.path().string());
                std::cout << "Found PNG file: " << filename << std::endl;
            }
        }
    }

    if (pngFiles.empty()) {
        std::cerr << "No PNG files found in "<< inputFolder <<" folder!" << std::endl;
        return 1;
    }

    std::cout << "\nProcessing " << pngFiles.size() << " PNG file(s)...\n" << std::endl;

    // Process each PNG file
    int successCount = 0;
    for (const auto& inputPath : pngFiles) {
        std::filesystem::path inputFile(inputPath);
        std::string baseName = inputFile.stem().string(); // f�jln�v kiterjeszt�s n�lk�l
        std::string outputPath = outputFolder + "/" + baseName + ".obj";

        std::cout << "Processing: " << inputFile.filename().string() << std::endl;

        HeightmapMesh mesh;

        // k�p bet�lt�se �s mesh gener�l�sa
        if (mesh.loadHeightmap(inputPath)) {
            // OBJ-ba export�l�s
            if (mesh.exportOBJ(outputPath)) {
                mesh.printStats();
                successCount++;
                std::cout << "Successfully processed: " << inputFile.filename().string() << "\n" << std::endl;
            }
            else {
                std::cerr << "Failed to export: " << inputFile.filename().string() << "\n" << std::endl;
            }
        }
        else {
            std::cerr << "Failed to load: " << inputFile.filename().string() << "\n" << std::endl;
        }
    }

    std::cout << "Processing complete!" << std::endl;
    std::cout << "Successfully processed: " << successCount << "/" << pngFiles.size() << " files" << std::endl;

    return 0;
}