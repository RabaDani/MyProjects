#include <iostream>
#include <fstream>

#include "telefonkonyv.h"
#include "memtrace.h"





using namespace std;



  //#define TESZTESETEK
#ifdef TESZTESETEK

#include "gtest_lite.h"



int main() {
    GTINIT(std::cin);
     Telefonkonyv telefonkonyv;
     Telefonkonyv ures;


     // Tesztelt személy létrehozása
     Magan* magan = new Magan("Kovacs", "Anna", "Budapest", "123456789", "Ani");
     Vallalkozo* vallalkozo = new Vallalkozo("Nagy", "Gyula", "Szombathely", "06203040", "06305060","Vallalatok utca 2");

     // Személy hozzáadása a telefonkönyvhöz
     telefonkonyv.szemelyFelvesz(magan);
     telefonkonyv.szemelyFelvesz(vallalkozo);

     TEST(Telefonkonyv, UjMaganFelvesz){


        // Teszteset várható kimenete
        std::string expected = "*---------------------*\nVezeteknev: Kovacs\nKeresztnev: Anna\nCim: Budapest\nTelefonszam: 123456789\nBecenev: Ani\n*---------------------*\n";

        // Kimenet ellenőrzése
        std::stringstream output;
        magan->szemelykiir(output); // Személy kiíratása a stringstreambe

        // Teszt
        EXPECT_EQ(expected, output.str());

    }END


    TEST(Telefonkonyv, UjVallalkozoFelvesz){


        // Teszteset várható kimenete
        std::string expected = "*---------------------*\nVezeteknev: Nagy\nKeresztnev: Gyula\nCim: Szombathely\nTelefonszam: 06203040\nVallalat telefonszama: 06305060\nVallalat cime: Vallalatok utca 2\n*---------------------*\n";

        // Kimenet ellenőrzése
        std::stringstream output;
        vallalkozo->szemelykiir(output); // Személy kiíratása a stringstreambe

        // Teszt
        EXPECT_EQ(expected, output.str());


    }END

    TEST(telefonkonyv,  TelefonkonyvKiir1)
    {

        std::string expected = "*---------------------*\nVezeteknev: Kovacs\nKeresztnev: Anna\nCim: Budapest\nTelefonszam: 123456789\nBecenev: Ani\n*---------------------*\n*---------------------*\nVezeteknev: Nagy\nKeresztnev: Gyula\nCim: Szombathely\nTelefonszam: 06203040\nVallalat telefonszama: 06305060\nVallalat cime: Vallalatok utca 2\n*---------------------*\n";

        std::stringstream output;
        telefonkonyv.telefonkonyKiir(output);

        EXPECT_EQ(expected, output.str());

    }END

    TEST(telefonkonyv,  TelefonkonyvKiir2)
    {

        std::string expected = "\nA telefonkonyv nem tarol adatokat.\n";

        std::stringstream output;
        ures.telefonkonyKiir(output);

        EXPECT_EQ(expected, output.str());

    }END

    TEST(Telefonkonyv, SzemelyTorol) {

        std::string expected = "Szemely sikeresen torolve.\n";

        // Kimenet ellenőrzése
        std::stringstream output;
        telefonkonyv.szemelyTorol("Kovacs", "Anna", output);

        // Ellenőrzés
        EXPECT_EQ(expected, output.str());

         // Ellenőrzés, hogy a személy tényleg eltávolításra került-e
        std::stringstream searchOutput;
        telefonkonyv.search(NevPredikatum<Szemely>("Kovacs", "Anna"), searchOutput);
        expected="\nEredmeny:\n\nNincs ilyen szemely a telefonkonyvben!\n\nNyomd meg az Enter-t a kilepeshez...";
        EXPECT_EQ(expected, searchOutput.str());


    }END


    TEST(SzemelyTorol, NemletezoSzemelyTorlese) {

        // Kimenet elvárt értéke
        std::string expected = "Nincs ilyen szemely a telefonkonyvben!\n";

        // Kimenet ellenőrzése
        std::stringstream output;
        telefonkonyv.szemelyTorol("Toth", "Peter", output);

        // Ellenőrzés
        EXPECT_EQ(expected, output.str());


    }END

    TEST(Telefonkonyv, SzemelyModosit) {
        std::stringstream output0;
        ures.szemelyModosit(output0);
        std::string expected = "\nA telefonkonyv nem tarol adatokat.\n";
        EXPECT_EQ(expected,output0.str());


        // Felhasználói bemenet szimulálása
        std::stringstream input;
        input << "Kis\nKata\n1\nUjVezeteknev\n";
        // Előre definiált adatokkal feltöltjük a telefonkönyvet
        ures.szemelyFelvesz(new Magan("Kis", "Kata", "Kisunyom", "123456789", "Katus"));


        // Az elvárt kimenet előállítása
        expected = "*---------------------*\nVezeteknev: UjVezeteknev\nKeresztnev: Kata\nCim: Kisunyom\nTelefonszam: 123456789\nBecenev: Katus\n*---------------------*\n";
        // Futtatjuk a metódust
        ures.szemelyModosit(cout,input);

        std::stringstream output;
        ures.telefonkonyKiir(output);
        // Kimeneten ellenőrizzük az elvárt eredményt
        EXPECT_EQ(expected, output.str());


        input << "UjVezeteknev\nKata\n5\nUjBecenev\n";
        // Az elvárt kimenet előállítása
        expected = "*---------------------*\nVezeteknev: UjVezeteknev\nKeresztnev: Kata\nCim: Kisunyom\nTelefonszam: 123456789\nBecenev: UjBecenev\n*---------------------*\n";
        // Futtatjuk a metódust
        ures.szemelyModosit(cout,input);

        std::stringstream output2;
        ures.telefonkonyKiir(output2);
        // Kimeneten ellenőrizzük az elvárt eredményt
        EXPECT_EQ(expected, output2.str());


        input << "UjVezeteknev\nKata\n2\nUjKeresztnev\n";
        // Az elvárt kimenet előállítása
        expected = "*---------------------*\nVezeteknev: UjVezeteknev\nKeresztnev: UjKeresztnev\nCim: Kisunyom\nTelefonszam: 123456789\nBecenev: UjBecenev\n*---------------------*\n";
        // Futtatjuk a metódust
        ures.szemelyModosit(cout,input);

        std::stringstream output3;
        ures.telefonkonyKiir(output3);
        // Kimeneten ellenőrizzük az elvárt eredményt
        EXPECT_EQ(expected, output3.str());


         input << "UjVezeteknev\nUjKeresztnev\n3\nUjCim\n";
        // Az elvárt kimenet előállítása
        expected = "*---------------------*\nVezeteknev: UjVezeteknev\nKeresztnev: UjKeresztnev\nCim: UjCim\nTelefonszam: 123456789\nBecenev: UjBecenev\n*---------------------*\n";
        // Futtatjuk a metódust
        ures.szemelyModosit(cout,input);

        std::stringstream output4;
        ures.telefonkonyKiir(output4);
        // Kimeneten ellenőrizzük az elvárt eredményt
        EXPECT_EQ(expected, output4.str());



         input << "UjVezeteknev\nUjKeresztnev\n4\n111\n";
        // Az elvárt kimenet előállítása
        expected = "*---------------------*\nVezeteknev: UjVezeteknev\nKeresztnev: UjKeresztnev\nCim: UjCim\nTelefonszam: 111\nBecenev: UjBecenev\n*---------------------*\n";
        // Futtatjuk a metódust
        ures.szemelyModosit(cout,input);

        std::stringstream output5;
        ures.telefonkonyKiir(output5);
        // Kimeneten ellenőrizzük az elvárt eredményt
        EXPECT_EQ(expected, output5.str());


        input << "Nagy\nGyula\n6\nUjVallalaticim\n";
        // Az elvárt kimenet előállítása
        expected = "*---------------------*\nVezeteknev: Nagy\nKeresztnev: Gyula\nCim: Szombathely\nTelefonszam: 06203040\nVallalat telefonszama: 06305060\nVallalat cime: UjVallalaticim\n*---------------------*\n";
        // Futtatjuk a metódust
        telefonkonyv.szemelyModosit(cout,input);

        std::stringstream output6;
        telefonkonyv.telefonkonyKiir(output6);
        // Kimeneten ellenőrizzük az elvárt eredményt
        EXPECT_EQ(expected, output6.str());

        input << "Nagy\nGyula\n5\n000\n";
        // Az elvárt kimenet előállítása
        expected = "*---------------------*\nVezeteknev: Nagy\nKeresztnev: Gyula\nCim: Szombathely\nTelefonszam: 06203040\nVallalat telefonszama: 000\nVallalat cime: UjVallalaticim\n*---------------------*\n";
        // Futtatjuk a metódust
        telefonkonyv.szemelyModosit(cout,input);

        std::stringstream output7;
        telefonkonyv.telefonkonyKiir(output7);
        // Kimeneten ellenőrizzük az elvárt eredményt
        EXPECT_EQ(expected, output7.str());

    } END

    TEST(Telefonkonyv, SzemelyKereses)  {

        std::string expected = "\nEredmeny:\n*---------------------*\nVezeteknev: Nagy\nKeresztnev: Gyula\nCim: Szombathely\nTelefonszam: 06203040\nVallalat telefonszama: 000\nVallalat cime: UjVallalaticim\n*---------------------*\n\nNyomd meg az Enter-t a kilepeshez...";
        std::stringstream output;
        telefonkonyv.search(NevPredikatum<Szemely>("Nagy", "Gyula"), output);

        EXPECT_EQ(expected,output.str());

        std::stringstream output2;
        telefonkonyv.search(CimPredikatum<Szemely>("Szombathely"), output2);

        EXPECT_EQ(expected,output2.str());

        std::stringstream output3;
        telefonkonyv.search(TelefonszamPredikatum<Szemely>("06203040"), output3);

        EXPECT_EQ(expected,output3.str());

    }END

     TEST(Telefonkonyv, SzemelyKereses2)  {

        std::string expected = "\nEredmeny:\n\nNincs ilyen szemely a telefonkonyvben!\n\nNyomd meg az Enter-t a kilepeshez...";
        std::stringstream output;
        telefonkonyv.search(NevPredikatum<Szemely>("Kis", "Gyula"), output);

        EXPECT_EQ(expected,output.str());

        std::stringstream output2;
        telefonkonyv.search(CimPredikatum<Szemely>("Keszthely"), output2);

        EXPECT_EQ(expected,output2.str());

        std::stringstream output3;
        telefonkonyv.search(TelefonszamPredikatum<Szemely>("01010101"), output3);

        EXPECT_EQ(expected,output3.str());

    }END

     TEST(Telefonkonyv, SzemelyKereses3)  {

        telefonkonyv.szemelyFelvesz(new Magan("Rába", "Dániel", "Szombathely", "987654321", "Dunesz"));
        std::string expected = "\nEredmeny:\n*---------------------*\nVezeteknev: Nagy\nKeresztnev: Gyula\nCim: Szombathely\nTelefonszam: 06203040\nVallalat telefonszama: 000\nVallalat cime: UjVallalaticim\n*---------------------*\n*---------------------*\nVezeteknev: Rába\nKeresztnev: Dániel\nCim: Szombathely\nTelefonszam: 987654321\nBecenev: Dunesz\n*---------------------*\n\nNyomd meg az Enter-t a kilepeshez...";
        std::stringstream output;
        telefonkonyv.search(CimPredikatum<Szemely>("Szombathely"), output);

        EXPECT_EQ(expected,output.str());

    }END


    TEST(Telefonkonyv, TelefonkonyvFajlbolTolt) {

            // Teszteset várható kimenete (itt be kell állítani a várt kimenetet a teszthez)
            std::string expected = "Adatok sikeres betoltese az adatok.txt fajlbol.\n";

            // Kimenet ellenőrzése
            std::stringstream output;
            telefonkonyv.telefonkonyvFajlbolTolt("adatok.txt", output);

            // Teszt
            EXPECT_EQ(expected, output.str());
    }END

    TEST(Telefonkonyv, TelefonkonyvFajlbolTolt2) {

            // Teszteset várható kimenete (itt be kell állítani a várt kimenetet a teszthez)
            std::string expected = "Nem sikerult az adatok.txt fajlt megnyitni\n";

            // Kimenet ellenőrzése
            std::stringstream output;
            telefonkonyv.telefonkonyvFajlbolTolt("nincs.txt", output);

            // Teszt
            EXPECT_EQ(expected, output.str());
    }END

    TEST(Telefonkonyv, TelefonkonyvFajlbaMent) {

        // Teszteset várható kimenete (itt be kell állítani a várt kimenetet a teszthez)
        std::string expected = "Adatok elmentve.\n";

        // Kimenet ellenőrzése
        std::stringstream output;
        telefonkonyv.telefonkonyvFajlbaMent("adatok.txt", output);

        // Teszt
        EXPECT_EQ(expected, output.str());
    }END





    GTEND(std::cout);
    return 0;
}
#endif // TESZTESETEK

#ifndef TESZTESETEK
int main() {
    Telefonkonyv telefonkonyv;

    telefonkonyv.telefonkonyvFajlbolTolt("adatok.txt",cout);

    char choice;
    do {
        cout << "\nTELEFONKONYV" << endl;
        cout <<"----------------------------------------------------------\nValasszon alabbi menupontok kozul a sorszam megadasaval:\n";
        cout << "\n1. Szemely megadasa" << endl;
        cout << "2. Szemely modositasa" << endl;
        cout << "3. Szemely keresese" << endl;
        cout << "4. Szemely torlese" << endl;
        cout << "5. Telefonkonyv adatainak kiirasa" << endl;
        cout << "6. Adatok elmentese adatok.txt fajlba" << endl;
        cout << "\n7. Kilepes" << endl;
        cout << "----------------------------------------------------------"<<endl;
        cout << ">> ";
        cin >> choice;

        switch (choice) {
            case '1':
                clearScreen();
                char choice;
                cout << "\nSZEMELY:" << endl;
                cout << "1. Magan szemely megadasa" << endl;
                cout << "2. Vallalkozo megadasa" << endl;
                cout << "\n>> ";
                cin >> choice;

                char lastName[100], firstName[100], address[100], phoneNumber[100], nickname[100], companyPhoneNumber[100], companyAddress[100];

                switch (choice) {
                     case '1':
                        cout << "Vezeteknev: ";
                        cin.ignore(); // Elõször ki kell üríteni a bemeneti puffert
                        cin.getline(lastName, sizeof(lastName));
                        cout << "Keresztnev: ";
                        cin.getline(firstName, sizeof(firstName));
                        cout << "Cim: ";
                        cin.getline(address, sizeof(address));
                        cout << "Telefonszam: ";
                        cin.getline(phoneNumber, sizeof(phoneNumber));
                        cout << "Becenev: ";
                        cin.getline(nickname, sizeof(nickname));
                        telefonkonyv.szemelyFelvesz(new Magan(lastName, firstName, address, phoneNumber, nickname));
                        clearScreen();
                        cout << "Szemely sikeresen felveve a telefonkonyvbe." << endl;
                        break;
                    case '2':
                        cout << "Vezeteknev: ";
                        cin.ignore(); // Elõször ki kell üríteni a bemeneti puffert
                        cin.getline(lastName, sizeof(lastName));
                        cout << "Keresztnev: ";
                        cin.getline(firstName, sizeof(firstName));
                        cout << "Cim: ";
                        cin.getline(address, sizeof(address));
                        cout << "Telefonszam: ";
                        cin.getline(phoneNumber, sizeof(phoneNumber));
                        cout << "Vallalat telefonszama:";
                        cin.getline(companyPhoneNumber, sizeof(companyPhoneNumber));
                        cout << "Vallalat cime: ";
                        cin.getline(companyAddress, sizeof(companyAddress));
                        telefonkonyv.szemelyFelvesz(new Vallalkozo(lastName, firstName, address, phoneNumber, companyPhoneNumber, companyAddress));
                        clearScreen();
                        cout << "Szemely sikeresen felveve a telefonkonyvbe." << endl;
                        break;
                    default:
                        cout << "\nHibas bemenet!" << endl;
                }
                break;
            case '2':
                clearScreen();
                telefonkonyv.szemelyModosit(cout);
                break;
            case '3':
                clearScreen();
                cout<<"Mi alapjan szeretnel keresni?"<<endl;
                cout<<"1. Nev"<<endl;
                cout<<"2. Cim"<<endl;
                cout<<"3. Telefonszam"<<endl;
                cout<<"\n>> ";
                cin>>choice;

                switch (choice) {
                    case '1': {
                        char lastName[100];
                        char firstName[100];
                        cout << "\nVezeteknev: ";
                        cin.ignore(); // Elõször ki kell üríteni a bemeneti puffert
                        cin.getline(lastName, sizeof(lastName));
                        cout << "Keresztnev: ";
                        cin.getline(firstName, sizeof(firstName));
                        // Predikátum létrehozása és keresés végrehajtása
                        NevPredikatum<Szemely> pred(lastName, firstName);
                        telefonkonyv.search(pred,cout);
                        std::cin.get();
                        break;
                    }
                    case '2': {
                        char address[100];
                        cout << "\nCim: ";
                        cin.ignore(); // Elõször ki kell üríteni a bemeneti puffert
                        cin.getline(address, sizeof(address));
                        // Predikátum létrehozása és keresés végrehajtása
                        CimPredikatum<Szemely> pred(address);
                        telefonkonyv.search(pred,cout);
                        std::cin.get();
                        break;
                    }
                    case '3': {
                        char phoneNumber[100];
                        cout << "\nTelefonszam: ";
                        cin.ignore(); // Elõször ki kell üríteni a bemeneti puffert
                        cin.getline(phoneNumber, sizeof(phoneNumber));
                        // Predikátum létrehozása és keresés végrehajtása
                        TelefonszamPredikatum<Szemely> pred(phoneNumber);
                        telefonkonyv.search(pred,cout);
                        std::cin.get();
                        break;
                    }
                    default:
                        cout << "\nHibas bemenet!" << endl;
                }
                clearScreen();
                break;
            case '4':
                clearScreen();
                cout<<"Kit szeretnel torolni a telefonkonyvbol?\n"<<endl;
                telefonkonyv.telefonkonyKiir(cout);
                cin.ignore(); // Elõször ki kell üríteni a bemeneti puffert
                cout << "\nVezeteknev: ";
                cin.getline(lastName, sizeof(lastName));
                cout << "Keresztnev: ";
                cin.getline(firstName, sizeof(firstName));
                telefonkonyv.szemelyTorol(lastName, firstName, cout);
                break;
            case '5':
                clearScreen();
                cout<<"\nTELEFONKONYV ADATAI:"<<endl;
                telefonkonyv.telefonkonyKiir(cout);
                cout << "\nNyomd meg az Enter-t a kilepeshez...";
                std::cin.get();
                std::cin.ignore();
                clearScreen();
                break;
            case '6':
                clearScreen();
                telefonkonyv.telefonkonyvFajlbaMent("adatok.txt", cout);
                break;
            case '7':
                cout << "\nKilepes..." << endl;
                break;
            default:
                cout << "\nHibas bemenet!" << endl;
        }
    } while (choice != '7');


    return 0;
}

#endif

