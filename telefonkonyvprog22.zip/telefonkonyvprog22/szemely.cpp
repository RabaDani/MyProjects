#include "szemely.h"


using std::ostream, std::endl, std::ofstream;


//!
/*! \brief Be�ll�tja a vezet�kn�vet.
 *
 *  A met�dus be�ll�tja a param�terk�nt kapott vezet�knevet.
 *
 *  \param ln const char*: a be�ll�tand� vezet�kn�v.
 */
void Nev::setLastname(const char* ln) {
        delete[] lastName; // T�r�lj�k az el�z� adatot
        lastName = new char[strlen(ln) + 1]; // L�trehozzuk az �j adatot
        strcpy(lastName, ln); // M�soljuk az �j adatot
    }

//!
/*! \brief Be�ll�tja a vezet�kn�vet.
 *
 *  A met�dus be�ll�tja a param�terk�nt kapott keresztnevet.
 *
 *  \param fn const char*: a be�ll�tand� keresztn�v.
 */
void Nev::setFirstname(const char* fn) {
        delete[] firstName; // T�r�lj�k az el�z� adatot
        firstName = new char[strlen(fn) + 1]; // L�trehozzuk az �j adatot
        strcpy(firstName, fn); // M�soljuk az �j adatot
    }

//!
/*! \brief Be�ll�tja a Szem�ly c�m�t.
 *
 *  A met�dus be�ll�tja a param�terk�nt kapott c�met.
 *
 *  \param addr const char*: a be�ll�tand� c�m.
 */
void Szemely::setAddress(const char* addr) {
        if (addr != nullptr) {
            delete[] address;
            address = new char[strlen(addr) + 1];
            strcpy(address, addr);
        }
    }

//!
/*! \brief Be�ll�tja a Szem�ly telefonsz�m�t.
 *
 *  A met�dus be�ll�tja a param�terk�nt kapott telefonsz�mot.
 *
 *  \param phone const char*: a be�ll�tand� telefonsz�m.
 */
void Szemely::setPhoneNumber(const char* phone) {
        if (phone != nullptr) {
            delete[] phoneNumber;
            phoneNumber = new char[strlen(phone) + 1];
            strcpy(phoneNumber, phone);
        }
    }

    //!
/*! \brief Visszaadja a Szem�ly nev�t.
 *
 *  \return name Nev*: a Szem�ly neve.
 */
    Nev& Szemely::getName() const {
    return *name;
}


/*! \brief Visszaadja a Szem�ly nev�t.
 *
 *  \return address char*: a Szem�ly c�me.
 */
const char* Szemely::getAddress() const {
    return address;
}


/*! \brief Visszaadja a Szem�ly nev�t.
 *
 *  \return phoneNumber char*: a Szem�ly telefonsz�ma.
 */
const char* Szemely::getPhoneNumber() const {
    return phoneNumber;
}

/*! \brief Ki�rja a Szem�ly adatait.
 *
 *  A met�dus ki�rja a param�terk�nt kapott kimenetre a Szem�ly adatait.
 *
 *  \param os std::ostream&: a kimeneti folyam.
 */
void Szemely::szemelykiir(std::ostream& os) const {
        os << "*---------------------*" << endl;
        os << "Vezeteknev: " << name->lastName << endl;
        os << "Keresztnev: " << name->firstName << endl;
        os << "Cim: " << address << endl;
        os << "Telefonszam: " << phoneNumber << endl;
    }


/*! \brief Elmenti a Szem�ly adatait f�jlba.
 *
 *  A met�dus bele�rja a param�terk�nt kapott kimeneti f�jlba a Szem�ly adatait egysorba.
 *
 *  \param outFile std::ofstream&: a kimeneti f�jl.
 */
void Szemely::szemelyfajlbament(std::ofstream& outFile) const {
        outFile << name->lastName << "," << name->firstName << "," << address << "," << phoneNumber << ",";
    }

//!
/*! \brief Be�ll�tja a Mag�n szem�ly becenev�t.
 *
 *  A met�dus be�ll�tja a param�terk�nt kapott becenevet.
 *
 *  \param nn const char*: a be�ll�tand� becen�v.
 */
 void Magan::setNickname(const char* nn) {
        if (nn != nullptr) {
            delete[] nickname;
            nickname = new char[strlen(nn) + 1];
            strcpy(nickname, nn);
        }
    }


/*! \brief Visszaadja a Mag�n szem�ly becenev�t.
 *
 *  \return nickname char*: a Szem�ly beceneve.
 */
const char* Magan::getNickname() const {
    return nickname;
}


/*! \brief Visszaadja a Mag�n szem�ly tipus�t.
 *
 *  \return const char*: a Szem�ly t�pusa.
 */
const char* Magan::getType() const  {
    return "Magan";
}

//!
/*! \brief Ki�rja a Mag�n szem�ly adatait.
 *
 *  A met�dus ki�rja a param�terk�nt kapott kimenetre a Mag�n szem�ly adatait.
 *
 *  \param os std::ostream&: a kimeneti folyam.
 */
 void Magan::szemelykiir(std::ostream& os) const {
    Szemely::szemelykiir(os);
    os << "Becenev: " << nickname << endl;
    os << "*---------------------*" << endl;

}


/*! \brief Elmenti a Mag�n szem�ly adatait f�jlba.
 *
 *  A met�dus bele�rja a param�terk�nt kapott kimeneti f�jlba a Mag�n szem�ly adatait egysorba.
 *
 *  \param outFile std::ofstream&: a kimeneti f�jl.
 */
void Magan::szemelyfajlbament(ofstream& outFile) const {
        Szemely::szemelyfajlbament(outFile);
        outFile << nickname << endl;
    }


//!
/*! \brief Be�ll�tja a V�llalkoz� v�llalati telefonsz�m�t.
 *
 *  A met�dus be�ll�tja a param�terk�nt kapott telefonsz�mot.
 *
 *  \param cp const char*: a be�ll�tand� telefonsz�m.
 */
void Vallalkozo::setCompanyPhoneNumber(const char* cp) {
        if (cp != nullptr) {
            delete[] companyPhoneNumber;
            companyPhoneNumber = new char[strlen(cp) + 1];
            strcpy(companyPhoneNumber, cp);
        }
    }

    //!
/*! \brief Be�ll�tja a V�llalkoz� v�llalati c�m�t.
 *
 *  A met�dus be�ll�tja a param�terk�nt kapott c�met.
 *
 *  \param ca const char*: a be�ll�tand� c�m.
 */
 void Vallalkozo::setCompanyAddress(const char* ca) {
        if (ca != nullptr) {
            delete[] companyAddress;
            companyAddress = new char[strlen(ca) + 1];
            strcpy(companyAddress, ca);
        }
    }

/*! \brief Visszaadja a V�llalkoz� v�llalati telefonsz�m�t.
 *
 *  \return companyPhoneNumber char*: a V�llalkoz� v�llalati telefonsz�ma.
 */
const char* Vallalkozo::getCompanyPhoneNumber() const {
    return companyPhoneNumber;
}

/*! \brief Visszaadja a V�llalkoz� v�llalati c�m�t.
 *
 *  \return companyPhoneNumber char*: a V�llalkoz� v�llalati c�me.
 */
const char* Vallalkozo::getCompanyAddress() const {
    return companyAddress;
}

/*! \brief Visszaadja a V�llalkoz� tipus�t.
 *
 *  \return const char*: a Szem�ly t�pusa.
 */
const char* Vallalkozo::getType() const  {
    return "Vallalkozo";
}

//!
/*! \brief Ki�rja a V�llalkoz� adatait.
 *
 *  A met�dus ki�rja a param�terk�nt kapott kimenetre a V�llalkoz� adatait.
 *
 *  \param os std::ostream&: a kimeneti folyam.
 */
 void Vallalkozo::szemelykiir(std::ostream& os) const {
    Szemely::szemelykiir(os);
    os << "Vallalat telefonszama: " << companyPhoneNumber << endl;
    os << "Vallalat cime: " << companyAddress << endl;
    os << "*---------------------*" << endl;

}

/*! \brief Elmenti a V�llalkoz� szem�ly adatait f�jlba.
 *
 *  A met�dus bele�rja a param�terk�nt kapott kimeneti f�jlba a V�llalkoz� adatait egysorba.
 *
 *  \param outFile std::ofstream&: a kimeneti f�jl.
 */
void Vallalkozo::szemelyfajlbament(ofstream& outFile) const {
    Szemely::szemelyfajlbament(outFile);
    outFile << companyPhoneNumber << "," << companyAddress << endl;
}

