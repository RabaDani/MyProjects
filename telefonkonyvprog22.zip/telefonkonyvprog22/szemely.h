#ifndef SZEMELY_H
#define SZEMELY_H

#include <iostream>

#include "memtrace.h"




/*!
 * \class Nev
 * \brief A szem�ly nev�t reprezent�l� oszt�ly.
 *
 * Ez az oszt�ly tartalmazza a szem�ly vezet�knev�t �s keresztnev�t.
 */
class Nev {
public:
    //! Vezet�kn�v
    char* lastName;
    //! Keresztn�v
    char* firstName;

    //! Konstruktor
    Nev(const char* ln, const char* fn) {
        lastName = new char[strlen(ln) + 1];
        strcpy(lastName, ln);

        firstName = new char[strlen(fn) + 1];
        strcpy(firstName, fn);
    }

    //! M�sol� konstruktor
    Nev(const Nev& other) {
        lastName = new char[strlen(other.lastName) + 1];
        strcpy(lastName, other.lastName);

        firstName = new char[strlen(other.firstName) + 1];
        strcpy(firstName, other.firstName);
    }

    //! Destruktor
    ~Nev() {
        delete[] lastName;
        delete[] firstName;
    }

    //! Be�ll�t� f�ggv�nyek
    void setLastname(const char* ln);

    void setFirstname(const char* fn);
};


/*!
 * \class Szemely
 * \brief Szem�lyt reprezent�l� oszt�ly.
 *
 * Ez az oszt�ly tartalmazza a szem�ly nev�t, c�m�t �s telefonsz�m�t.
 */
class Szemely {
protected:
    //! A szem�ly neve
    Nev* name;
    //! A szem�ly c�me
    char* address;
     //! A szem�ly telefonsz�ma
    char* phoneNumber;

public:
    //! Konstruktor
    Szemely(const char* ln, const char* fn, const char* addr, const char* phone) : address(nullptr), phoneNumber(nullptr) {
        name = new Nev(ln, fn);
        setAddress(addr);
        setPhoneNumber(phone);
    }

    //! M�sol� konstruktor
    Szemely(const Szemely& other) : address(nullptr), phoneNumber(nullptr) {
        name = new Nev(*other.name);
        setAddress(other.address);
        setPhoneNumber(other.phoneNumber);
    }

    //! Destruktor
    virtual ~Szemely() {
        delete name;
        delete[] address;
        delete[] phoneNumber;
    }

    //! Be�ll�t� f�ggv�nyek
    void setAddress(const char* addr);

    void setPhoneNumber(const char* phone);

    //! Adat visszaad� f�ggv�nyek
    Nev& getName() const;

    const char* getAddress() const;

    const char* getPhoneNumber() const;

    virtual const char* getType() const = 0;

    //! Szem�ly adatainak ki�r�sa
    virtual void szemelykiir(std::ostream& os) const;

    //! Adatok ment�se f�jlba
    virtual void szemelyfajlbament(std::ofstream& outFile) const;
};

/*!
 * \class Magan
 * \brief A mag�nszem�lyeket reprezent�l� oszt�ly.
 *
 * Ez az oszt�ly a szem�ly nev�t, c�m�t �s telefonsz�m�t t�rolja,
 * valamint egy becenevet is. A Szemely oszt�lyb�l sz�rmazik.
 */
class Magan : public Szemely {
private:
    //! A mag�nszem�ly beceneve
    char* nickname;

public:
    //! Konstruktor
    Magan(const char* ln, const char* fn, const char* addr, const char* phone, const char* nn)
        : Szemely(ln, fn, addr, phone), nickname(nullptr) {
        setNickname(nn);
    }

    //! M�sol� konstruktor
    Magan(const Magan& other) : Szemely(other), nickname(nullptr) {
        setNickname(other.nickname);
    }

    //! Destruktor
    ~Magan() override {
        delete[] nickname;
    }

    //! Be�ll�t� f�ggv�nyek
    void setNickname(const char* nn);

    //! Adat visszaad� f�ggv�nyek
    const char* getNickname() const;

    const char* getType() const override;

    //! Mag�n szem�ly adatainak ki�r�sa
    void szemelykiir(std::ostream& os) const override;

    //! Adatok ment�se f�jlba
    void szemelyfajlbament(std::ofstream& outFile) const override;
};


/*!
 * \class Vallalkozo
 * \brief A v�llalkoz�kat reprezent�l� oszt�ly.
 *
 * Ez az oszt�ly a szem�ly nev�t, c�m�t �s telefonsz�m�t t�rolja,
 * valamint a v�llalkoz�s telefonsz�m�t �s c�m�t is. A Szemely oszt�lyb�l sz�rmazik.
 */
class Vallalkozo : public Szemely {
private:
    //! A v�llalkoz�s telefonsz�ma
    char* companyPhoneNumber;
    //! A v�llalkoz�s c�me
    char* companyAddress;

public:
    //! Konstruktor
    Vallalkozo(const char* ln, const char* fn, const char* addr, const char* phone, const char* cp, const char* ca)
        : Szemely(ln, fn, addr, phone), companyPhoneNumber(nullptr), companyAddress(nullptr) {
        setCompanyPhoneNumber(cp);
        setCompanyAddress(ca);
    }

    //! M�sol� konstruktor
    Vallalkozo(const Vallalkozo& other) : Szemely(other), companyPhoneNumber(nullptr), companyAddress(nullptr) {
        setCompanyPhoneNumber(other.companyPhoneNumber);
        setCompanyAddress(other.companyAddress);
    }

    //! Destruktor
    ~Vallalkozo() override {
        delete[] companyPhoneNumber;
        delete[] companyAddress;
    }

    //! Be�ll�t� f�ggv�nyek
    void setCompanyPhoneNumber(const char* cp);

    void setCompanyAddress(const char* ca);

    //! Adat visszaad� f�ggv�nyek
    const char* getCompanyPhoneNumber() const;

    const char* getCompanyAddress() const;

    const char* getType() const override;

    //! V�llalkoz� adatainak ki�r�sa
    void szemelykiir(std::ostream& os) const override;

    //! Adatok ment�se f�jlba
    void szemelyfajlbament(std::ofstream& outFile) const override;
};


#endif // SZEMELY_H

