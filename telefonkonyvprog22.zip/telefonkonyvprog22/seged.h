#ifndef SEGED_H
#define SEGED_H

#include <stdexcept>
#include "szemely.h"
#include <cstring>


/*!
 * \brief Képernyő törlése platformfüggő módon.
 *
 * A függvény platformfüggő módon törli a képernyőt. Windows alatt a "cls" parancsot,
 * Linux vagy macOS alatt a "clear" parancsot használja a rendszerhez.
 *
 */
void clearScreen();


// Predikátum struktúra a név alapján kereséshez
template<class T>
struct NevPredikatum {
    //! A keresendő személy vezetékneve.
    const char* lastName;
    //! A keresendő személy keresztneve.
    const char* firstName;

    /*!
     * \brief Konstruktor a név alapján keresési predikátumhoz.
     *
     * \param ln const char*: A keresendő személy vezetékneve.
     * \param fn const char*: A keresendő személy keresztneve.
     */
    NevPredikatum(const char* ln, const char* fn) : lastName(ln), firstName(fn) {}


    /*!
     * \brief Predikátum operátor, ami eldönti, hogy a megadott személy egyezik-e a keresési feltételekkel.
     *
     * \param szemely const T&: A személy, amelyet ellenőrizünk a predikátum alapján.
     * \return true, ha a személy egyezik a keresési feltételekkel, egyébként false.
     */
     bool operator()(const T& szemely) const {
        return strcmp(szemely.getName().lastName, lastName) == 0 &&
               strcmp(szemely.getName().firstName, firstName) == 0;
    }
};

// Predikátum struktúra a cím alapján kereséshez
template<class T>
struct CimPredikatum {
    //! A keresendő személy címe.
    const char* address;

    /*!
     * \brief Konstruktor a cím alapján keresési predikátumhoz.
     *
     * \param addr const char*: A keresendő személy címe.
     */
    CimPredikatum(const char* addr) : address(addr) {}

    /*!
     * \brief Predikátum operátor, ami eldönti, hogy a megadott személy egyezik-e a keresési feltételekkel.
     *
     * \param szemely const T&: A személy, amelyet ellenőrizünk a predikátum alapján.
     * \return true, ha a személy egyezik a keresési feltételekkel, egyébként false.
     */
    bool operator()(const T& szemely) const {
        return strcmp(szemely.getAddress(), address) == 0;
    }
};

// Predikátum struktúra a telefonszám alapján kereséshez
template<class T>
struct TelefonszamPredikatum {
    //! A keresendő személy telefonszáma.
    const char* phoneNumber;


    /*!
     * \brief Konstruktor a telefonszám alapján keresési predikátumhoz.
     *
     * \param phone const char*: A keresendő személy telefonszáma.
     */
    TelefonszamPredikatum(const char* phone) : phoneNumber(phone) {}

    /*!
     * \brief Predikátum operátor, ami eldönti, hogy a megadott személy egyezik-e a keresési feltételekkel.
     *
     * \param szemely const T&: A személy, amelyet ellenőrizünk a predikátum alapján.
     * \return true, ha a személy egyezik a keresési feltételekkel, egyébként false.
     */
      bool operator()(const T& szemely) const {
        return strcmp(szemely.getPhoneNumber(), phoneNumber) == 0;
      }
};






#endif // SEGED_H
