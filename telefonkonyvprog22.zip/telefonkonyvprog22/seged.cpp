#include "seged.h"

void clearScreen() {
    #if defined(_WIN32) || defined(_WIN64) //Ha windowson fut a program.
        system("cls");
    #elif defined (__LINUX__) || defined(__linux__) || defined(__gnu_linux__) || defined(__APPLE__) //linux vagy macOs
        system("clear");
    #elif defined(CPORTA) //Ha CPORTA
        ;

    #endif
}


