#ifndef TELEFONKONYV_H
#define TELEFONKONYV_H

#include "seged.h"

#include "memtrace.h"

/*!
 * \struct ListaElem
 * \brief Egy listaelemet reprezentáló struktúra.
 *
 * Ez a struktúra egy adatot (Szemely* pointer) és egy következő listaelemre mutató pointert tartalmaz.
 */
class ListaElem {
public:
    //! A tárolt adat (Szemely* pointer)
    Szemely* data;
    //! A következő listaelemre mutató pointer
    ListaElem* kov;

    //! Konstruktor
    ListaElem(Szemely* p) : data(p), kov(nullptr) {}

    //! Destruktor
    ~ListaElem() {
        delete data;
    }
};

/*!
 * \class Telefonkonyv
 * \brief A telefonkönyvet reprezentáló osztály.
 *
 * Ez az osztály tartalmazza a telefonkönyv elejét, és az összes funkciót, ami végrehajtható a telefonkönyvön.
 */
class Telefonkonyv {
private:
     //! A telefonkönyv elejét jelző pointer
    ListaElem* eleje;

public:
    //! Konstruktor
    Telefonkonyv() : eleje(nullptr) {}

    //! Destruktor
    ~Telefonkonyv() {
        while (eleje) {
            ListaElem* temp = eleje;
            eleje = eleje->kov;
            delete temp;
        }
    }

/*!
     * \brief Személy hozzáadása a telefonkönyvhöz.
     *
     * \param p Szemely*: A hozzáadandó Szemely objektum pointer.
     */
      void szemelyFelvesz(Szemely* p);

/*!
     * \brief Személy adatainak módosítása.
     *
     * \param os std::ostream&: A kimeneti folyam, amelyre az üzeneteket kiírjuk.
     * \param is std::istream&: A bemeneti folyam, amelyről a felhasználói bemenetet olvassuk.
     * \return void.
     */
     void szemelyModosit(std::ostream& os = std::cout, std::istream& is = std::cin);


 /*!
 * \brief Predikátum alapú személy keresés a telefonkönyvben.
 *
 * Ez a metódus végigiterál a telefonkönyvön, és minden olyan személyt kiír, amelyre a predikátum igaz.
 *
 * \tparam Predikatum A predikátum típusa.
 * \param pred Predikatum: A predikátum, amelyet a felhasználó ad meg a kereséshez.
 * \param os std::ostream&: A kimeneti folyam, amelyre az üzeneteket kiírjuk.
 */
template<class Predikatum>
void search(Predikatum pred, std::ostream& os) {
    ListaElem* temp = eleje;
    bool found = false;
    os<< "\nEredmeny:"<<std::endl;
    while (temp) {
        if (pred(*temp->data)) {
            temp->data->szemelykiir(os);
            found = true;
        }
        temp = temp->kov;
    }
    if (!found) {
        os << "\nNincs ilyen szemely a telefonkonyvben!" << std::endl;
    }
    os << "\nNyomd meg az Enter-t a kilepeshez...";
}


/*!
     * \brief Személy törlése a telefonkönyvből név alapján.
     *
     * \param lastName const char*: A személy vezetékneve.
     * \param firstName const char*: A személy keresztneve.
     * \param os std::ostream&: A kimeneti folyam, amelyre az üzeneteket kiírjuk.
     */
    void szemelyTorol(const char* lastName, const char* firstName, std::ostream& os);


/*!
 * \brief Telefonkönyv kiíratása.
 *
 * \param osstd::ostream&: A kimeneti folyam, amelyre a telefonkönyvet kiírjuk.
 */
     void telefonkonyKiir(std::ostream& os);

/*!
 * \brief Adatok mentése fájlba.
 *
 * \param filename const char*: A fájl neve, amelybe az adatokat mentjük.
 * \param os std::ostream&: A kimeneti folyam, amelyre az üzeneteket kiírjuk.
 */
     void telefonkonyvFajlbaMent(const char* filename, std::ostream& os);

/*!
 * \brief Adatok betöltése fájlból.
 *
 * \param filename const char*: A fájl neve, amelyből az adatokat betöltjük.
 * \param os std::ostream&: A kimeneti folyam, amelyre az üzeneteket kiírjuk.
 */
     void telefonkonyvFajlbolTolt(const char* filename, std::ostream& os);
};





#endif // TELEFONKONYV_H


