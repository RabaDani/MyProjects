#include "telefonkonyv.h"




using std::cin, std::endl, std::ofstream, std::ifstream, std::string, std::stringstream;

// Személy hozzáadása a telefonkönyvhöz
void Telefonkonyv::szemelyFelvesz(Szemely* p) {
    ListaElem* uj = new ListaElem(p);
    if (!eleje) {
        eleje = uj;
    } else {
        ListaElem* temp = eleje;
        while (temp->kov != nullptr) {
            temp = temp->kov;
        }
        temp->kov = uj;
    }
}


// Személy adatainak módosítása
void Telefonkonyv::szemelyModosit(std::ostream& os, std::istream& is) {
char lastName[100], firstName[100];
ListaElem* temp = eleje;
    if(temp == nullptr)
    {
        os<<"\nA telefonkonyv nem tarol adatokat."<<endl;
        return;
    }
os<< "Kinek az adatat szeretned modositani?\n" <<std::endl;
telefonkonyKiir(os);
os << "\nSzemely vezetekneve: ";
is >> lastName;
os << "Szemely keresztneve: ";
is >> firstName;

// Keresés a telefonkönyvben a megadott név alapján
bool found = false;
while (temp) {
    if (strcmp(temp->data->getName().lastName, lastName) == 0 &&
        strcmp(temp->data->getName().firstName, firstName) == 0) {
            found = true;
        break;
    }
    temp = temp->kov;
}

if (!found) {
    os << "Nincs ilyen szemely a telefonkonyvben!" << endl;
    return;
}

// Adat módosítása
char choice;
os << "\nMit szeretnel modositani:" << endl;
os << "1. Vezeteknev" << endl;
os << "2. Keresztnev" << endl;
os << "3. Cim" << endl;
os << "4. Telefonszam" << endl;
if (strcmp(temp->data->getType(), "Magan") == 0) {
    os << "5. Becenev" << endl;
}
else if (strcmp(temp->data->getType(), "Vallalkozo") == 0) {
    os << "5. Vallalati telefonszam" << endl;
    os << "6. Vallalati cim" << endl;
}
os << "\n>> ";
is >> choice;

switch (choice) {
    case '1':
        // Vezetéknév módosítása
            os << "\nUj Vezeteknev: ";
            is.ignore(); // Először ki kell üríteni a bemeneti puffert
            is.getline(lastName, sizeof(lastName));
            temp->data->getName().setLastname(lastName);
            clearScreen();
            os << "\nSikeres modositas!" << endl;
        break;
    case '2':
        // Keresztnév módosítása
            os << "\nUj Keresztnev: ";
            is.ignore(); // Először ki kell üríteni a bemeneti puffert
            is.getline(firstName, sizeof(firstName));
            temp->data->getName().setFirstname(firstName);
            clearScreen();
            os << "\nSikeres modositas!" << endl;
        break;
    case '3':
        // Cím módosítása
        char newAddress[100];
        os << "\nUj Cim: ";
        is.ignore(); // Először ki kell üríteni a bemeneti puffert
        is.getline(newAddress, sizeof(newAddress));
        temp->data->setAddress(newAddress);
        clearScreen();
        os << "\nSikeres modositas!" << endl;
        break;
    case '4':
        // Telefonszám módosítása
        char newPhoneNumber[100];
        os << "\nUj Telefonszam: ";
        is.ignore(); // Először ki kell üríteni a bemeneti puffert
        is.getline(newPhoneNumber, sizeof(newPhoneNumber));
        temp->data->setPhoneNumber(newPhoneNumber);
        clearScreen();
        os << "\nSikeres modositas!" << endl;
        break;
    case '5':
        // Becenev vagy vállalati telefonszám módosítása
        if (strcmp(temp->data->getType(), "Magan") == 0) {
            // Becenev módosítása
            char newNickname[100];
            os << "\nUj Becenev: ";
            is.ignore(); // Először ki kell üríteni a bemeneti puffert
            is.getline(newNickname, sizeof(newNickname));
            dynamic_cast<Magan*>(temp->data)->setNickname(newNickname);
            clearScreen();
            os << "\nSikeres modositas!" << endl;
        }
        else if (strcmp(temp->data->getType(), "Vallalkozo") == 0) {
            // Vallalati telefonszam módosítása
            char newCompanyPhoneNumber[100];
            os << "\nUj Vallalati telefonszam: ";
            is.ignore(); // Először ki kell üríteni a bemeneti puffert
            is.getline(newCompanyPhoneNumber, sizeof(newCompanyPhoneNumber));
            dynamic_cast<Vallalkozo*>(temp->data)->setCompanyPhoneNumber(newCompanyPhoneNumber);
            clearScreen();
            os << "\nSikeres modositas!" << endl;
        }
        break;
    case '6':
        // Vallalati cím módosítása
        if (strcmp(temp->data->getType(), "Vallalkozo") == 0) {
            char newCompanyAddress[100];
            os << "\nUj Vallalati Cim: ";
            is.ignore(); // Először ki kell üríteni a bemeneti puffert
            is.getline(newCompanyAddress, sizeof(newCompanyAddress));
            dynamic_cast<Vallalkozo*>(temp->data)->setCompanyAddress(newCompanyAddress);
            clearScreen();
            os << "\nSikeres modositas!" << endl;
        }
        break;
    default:
        clearScreen();
        os << "\nHibas bemenet!" << endl;
    }
}



// Személy törlése a telefonkönyvbõl név alapján
void Telefonkonyv::szemelyTorol(const char* lastName, const char* firstName, std::ostream& os) {
    clearScreen();
    if (!eleje) {
        os << "Nincs ilyen szemely a telefonkonyvben!" << endl;
        return;
    }
    ListaElem* curr = eleje;
    ListaElem* prev = nullptr;
    bool found = false;
    while (curr != nullptr) {
        if (strcmp(curr->data->getName().lastName, lastName) == 0 &&
            strcmp(curr->data->getName().firstName, firstName) == 0) {
            if (prev == nullptr) {
                eleje = curr->kov;
            } else {
                prev->kov = curr->kov;
            }
            delete curr;
            os << "Szemely sikeresen torolve." << endl;
            found = true;
            break;
        }
        prev = curr;
        curr = curr->kov;
    }
    if (!found) {
        os << "Nincs ilyen szemely a telefonkonyvben!" << endl;
    }
}

 // Telefonkönyv kiíratása
void Telefonkonyv::telefonkonyKiir(std::ostream& os) {
    ListaElem* temp = eleje;
    if(temp == nullptr)
        os<<"\nA telefonkonyv nem tarol adatokat."<<endl;
    while (temp) {
        temp->data->szemelykiir(os);
        temp = temp->kov;
    }
}

 // Adatok mentése fájlba
void Telefonkonyv::telefonkonyvFajlbaMent(const char* filename, std::ostream& os) {
   ofstream outFile(filename, std::ios::out | std::ios::binary); // Megfelelő módban nyitjuk meg a fájlt
    if (!outFile) {
        os << "Nem sikerult az adatok.txt fajlt megnyitni" << endl;
        return;
    }

    // Adatok kiírása a fájlba
    ListaElem* temp = eleje;
    while (temp) {
        temp->data->szemelyfajlbament(outFile);
        temp = temp->kov;
    }

    outFile.close();
    os << "Adatok elmentve." << endl;
}

 // Adatok betöltése fájlból
 void Telefonkonyv::telefonkonyvFajlbolTolt(const char* filename, std::ostream& os) {
    ifstream inFile(filename, std::ios::in | std::ios::binary); // Megfelelő módban nyitjuk meg a fájlt
    if (!inFile) {
        os << "Nem sikerult az adatok.txt fajlt megnyitni" << endl;
        return;
    }

    string line;
    const int maxTokens = 6; // Maximális tokenek száma egy sorban
    string tokens[maxTokens];

    // Adatok beolvasása a fájlból
    while (getline(inFile, line)) {
        stringstream ss(line);
        string token;
        int tokenCount = 0;

        while (getline(ss, token, ',')) {
            tokens[tokenCount++] = token;
            if (tokenCount >= maxTokens) {
                break; // Ha túl sok token van, kilépünk
            }
        }

        if (tokenCount == 5) {
            szemelyFelvesz(new Magan(tokens[0].c_str(), tokens[1].c_str(), tokens[2].c_str(), tokens[3].c_str(), tokens[4].c_str()));
        } else if (tokenCount == 6) {
            szemelyFelvesz(new Vallalkozo(tokens[0].c_str(), tokens[1].c_str(), tokens[2].c_str(), tokens[3].c_str(), tokens[4].c_str(), tokens[5].c_str()));
        } else {
            os << "Hibas adatsor: " << line << endl;
        }
    }

    inFile.close();
    os << "Adatok sikeres betoltese az adatok.txt fajlbol." << endl;
}
