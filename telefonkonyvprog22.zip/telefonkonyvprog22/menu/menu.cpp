#include "menu.h"
#include "memtrace.h"


using std::endl, std::cin;
void Menu::betoltes(std::ostream& os) {
        telefonkonyv.telefonkonyvFajlbolTolt("adatok.txt",os);
    }

void Menu::showMenu(std::ostream& os,std::istream& is) {
    char choice;
    do {
        os << "\nTELEFONKONYV" << endl;
        os <<"----------------------------------------------------------\nValasszon alabbi menupontok kozul a sorszam megadasaval:\n";
        os << "\n1. Szemely megadasa" << endl;
        os << "2. Szemely modositasa" << endl;
        os << "3. Szemely keresese" << endl;
        os << "4. Szemely torlese" << endl;
        os << "5. Telefonkonyv adatainak kiirasa" << endl;
        os << "6. Adatok elmentese adatok.txt fajlba" << endl;
        os << "\n7. Kilepes" << endl;
        os << "----------------------------------------------------------"<<endl;
        os << ">> ";
        is >> choice;

        switch (choice) {
            case '1':
                clearScreen();
                felvesz(os,is);
                break;
            case '2':
                clearScreen();
                modosit(os);
                break;
            case '3':
                clearScreen();
                keres(os);
                clearScreen();
                break;
            case '4':
                clearScreen();
                torles(os);
                break;
            case '5':
                clearScreen();
                kiir(os);
                clearScreen();
                break;
            case '6':
                clearScreen();
                mentes(os);
                break;
            case '7':
                os << "\nKilepes..." << endl;
                break;
            default:
                os << "\nHibas bemenet!" << endl;
        }
    } while (choice != '7');
}


void Menu::felvesz(std::ostream& os, std::istream& is) {
    char choice;
    os << "\nSZEMELY:" << endl;
    os << "1. Magan szemely megadasa" << endl;
    os << "2. Vallalkozo megadasa" << endl;
    os << "\n>> ";
    is >> choice;

    char lastName[100], firstName[100], address[100], phoneNumber[100], nickname[100], companyPhoneNumber[100], companyAddress[100];

    switch (choice) {
         case '1':
            os << "Vezeteknev: ";
            is.ignore(); // El�sz�r ki kell �r�teni a bemeneti puffert
            is.getline(lastName, sizeof(lastName));
            os << "Keresztnev: ";
            is.getline(firstName, sizeof(firstName));
            os << "Cim: ";
            is.getline(address, sizeof(address));
            os << "Telefonszam: ";
            is.getline(phoneNumber, sizeof(phoneNumber));
            os << "Becenev: ";
            is.getline(nickname, sizeof(nickname));
            telefonkonyv.szemelyFelvesz(new Magan(lastName, firstName, address, phoneNumber, nickname));
            clearScreen();
            os << "Szemely sikeresen felveve a telefonkonyvbe." << endl;
            break;
        case '2':
            os << "Vezeteknev: ";
            is.ignore(); // El�sz�r ki kell �r�teni a bemeneti puffert
            is.getline(lastName, sizeof(lastName));
            os << "Keresztnev: ";
            is.getline(firstName, sizeof(firstName));
            os << "Cim: ";
            is.getline(address, sizeof(address));
            os << "Telefonszam: ";
            is.getline(phoneNumber, sizeof(phoneNumber));
            os << "Vallalat telefonszama:";
            is.getline(companyPhoneNumber, sizeof(companyPhoneNumber));
            os << "Vallalat cime: ";
            is.getline(companyAddress, sizeof(companyAddress));
            telefonkonyv.szemelyFelvesz(new Vallalkozo(lastName, firstName, address, phoneNumber, companyPhoneNumber, companyAddress));
            clearScreen();
            os << "Szemely sikeresen felveve a telefonkonyvbe." << endl;
            break;
        default:
            os << "\nHibas bemenet!" << endl;
    }
}

 // Szem�ly keres�se n�v alapj�n
void Menu::keres(std::ostream& os) {
    char choice;
    os<<"Mi alapjan szeretnel keresni?"<<endl;
    os<<"1. Nev"<<endl;
    os<<"2. Cim"<<endl;
    os<<"3. Telefonszam"<<endl;
    os<<"\n>> ";
    cin>>choice;

    switch (choice) {
        case '1': {
            char lastName[100];
            char firstName[100];
            os << "\nVezeteknev: ";
            cin.ignore(); // El�sz�r ki kell �r�teni a bemeneti puffert
            cin.getline(lastName, sizeof(lastName));
            os << "Keresztnev: ";
            cin.getline(firstName, sizeof(firstName));
            // Predik�tum l�trehoz�sa �s keres�s v�grehajt�sa
            NevPredikatum<Szemely> pred(lastName, firstName);
            telefonkonyv.search(pred,os);
            std::cin.get();
            break;
        }
        case '2': {
            char address[100];
            os << "\nCim: ";
            cin.ignore(); // El�sz�r ki kell �r�teni a bemeneti puffert
            cin.getline(address, sizeof(address));
            // Predik�tum l�trehoz�sa �s keres�s v�grehajt�sa
            CimPredikatum<Szemely> pred(address);
            telefonkonyv.search(pred,os);
            std::cin.get();
            break;
        }
        case '3': {
            char phoneNumber[100];
            os << "\nTelefonszam: ";
            cin.ignore(); // El�sz�r ki kell �r�teni a bemeneti puffert
            cin.getline(phoneNumber, sizeof(phoneNumber));
            // Predik�tum l�trehoz�sa �s keres�s v�grehajt�sa
            TelefonszamPredikatum<Szemely> pred(phoneNumber);
            telefonkonyv.search(pred,os);
            std::cin.get();
            break;
        }
        default:
            os << "\nHibas bemenet!" << endl;
    }
}

// Szem�ly t�rl�se
void Menu::torles(std::ostream& os) {
    char lastName[100], firstName[100];
    os<<"Kit szeretnel torolni a telefonkonyvbol?\n"<<endl;
    telefonkonyv.telefonkonyKiir(os);
    cin.ignore(); // El�sz�r ki kell �r�teni a bemeneti puffert
    os << "\nVezeteknev: ";
    cin.getline(lastName, sizeof(lastName));
    os << "Keresztnev: ";
    cin.getline(firstName, sizeof(firstName));
    telefonkonyv.szemelyTorol(lastName, firstName, os);
}

// Telefonk�nyv ki�rat�sa
void Menu::kiir(std::ostream& os) {
    os<<"\nTELEFONKONYV ADATAI:"<<endl;
    telefonkonyv.telefonkonyKiir(os);
    os << "\nNyomd meg az Enter-t a kilepeshez...";
    std::cin.get();
    std::cin.ignore();
}

// Adatok ment�se f�jlba
void Menu::mentes(std::ostream& os) {
    telefonkonyv.telefonkonyvFajlbaMent("adatok.txt", os);
}

void Menu::modosit(std::ostream& os)
{
    telefonkonyv.szemelyModosit(os);
}

