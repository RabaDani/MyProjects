#ifndef MENU_H
#define MENU_H
#include "telefonkonyv.h"



// Men� megval�s�t�sa
class Menu {
private:
    Telefonkonyv telefonkonyv;

public:
    void betoltes(std::ostream& os = std::cout);
    // Men� megjelen�t�se
    void showMenu(std::ostream& os = std::cout, std::istream& is = std::cin);

    // Telefonk�nyv ki�rat�sa
    void kiir(std::ostream& os);


private:
    // �j szem�ly hozz�ad�sa a telefonk�nyvh�z
    void felvesz(std::ostream& os, std::istream& is);

  // Szem�ly keres�se n�v alapj�n
void keres(std::ostream& os);



// Szem�ly t�rl�se
void torles(std::ostream& os);




// Adatok ment�se f�jlba
void mentes(std::ostream& os);

// Adatok bet�lt�se f�jlb�l


void modosit(std::ostream& os);


};




#endif
