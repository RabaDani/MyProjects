/**
 * A lassító spórákat reprezentáló osztály, amely a semleges spórák egy speciális típusa.
 * A rovarok elfogyasztva pontot kapnak, és a sebességük csökken.
 */
public class SlowSpore extends NeutralSpore{

    /**
     * A SlowSpore osztály konstruktora.
     */
    public SlowSpore(){

    }

    /**
     * Meghívásakor a megadott rovar elfogyasztja a spórát, és pontot kap a tápérték alapján.
     * Ezen kívül a rovar sebessége csökken.
     * A spóra ezt követően eltávolításra kerül a játéktérből.
     *
     * @param rovar A rovar, amely elfogyasztja a spórát.
     */
    @Override
    public void getAte(Bug rovar) {
        rovar.increasePoints(nutrient);
        rovar.decreaseSpeed();
        GameLogic.removeNeutralSpore(this);
    }
}
