import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class ScorePanel extends JPanel {

    private int WIDTH = 1600;
    private int HEIGTH = 900;
    public GameWindow gameWindow;
    List<Integer> fungusScoreOrder;
    List<Integer> bugScoreOrder;
    LinkedHashMap<Integer, Integer> fungusPlayerOrder = new LinkedHashMap<>();
    LinkedHashMap<Integer, Integer> bugPlayersOrder = new LinkedHashMap<>();
    public ScorePanel(GameWindow gameWindow) {

//        setSize(WIDTH, HEIGTH);
        setDoubleBuffered(true);
        setVisible(true);
        this.gameWindow = gameWindow;
        setBackground(Color.gray);
        addButton();
        calculateWinner();
        repaint();
    }

    private void addButton() {
        Button exitButton = new Button("Exit");
        exitButton.addActionListener(e -> {gameWindow.addMenu();});
        add(exitButton);
    }

    private void calculateWinner() {
        HashMap<Integer, Integer> fungusPlayers = GameLogic.getFungusPlayers();
        HashMap<Integer, Integer> bugPlayers = GameLogic.getBugPlayers();
        fungusScoreOrder = fungusPlayers.values().stream().sorted(Comparator.reverseOrder()).toList();
        bugScoreOrder = bugPlayers.values().stream().sorted(Comparator.reverseOrder()).toList();

        orderScores(fungusPlayers, fungusScoreOrder, fungusPlayerOrder);
        orderScores(bugPlayers, bugScoreOrder, bugPlayersOrder);
    }

    public void orderScores(HashMap<Integer, Integer> map, List<Integer> scores, LinkedHashMap<Integer, Integer> orderedScores) {
        for(Integer sc : scores) {
            for(Integer key : map.keySet()) {
                int score = map.get(key);
                if(score == sc) {
                    orderedScores.put(key, score);
                }
            }
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D graphics = (Graphics2D) g;

        draw(graphics);

        graphics.dispose();
    }

    private void draw(Graphics2D graphics) {

        graphics.setFont(new Font("Arial", Font.PLAIN, 20));

        int lastScore = -1;
        int score = -1;
        int place = 1;
        int x = 30;
        int y = 30;
        for(Integer key : fungusPlayerOrder.keySet()) {
            score = fungusPlayerOrder.get(key);
            if(lastScore == -1) {
                lastScore = score;

                graphics.drawString("FungusPlayer team_"+key+", point: "+score+", place: "+place, x, y);
            } else if(lastScore > score) {
                place++;
                graphics.drawString("FungusPlayer team_"+key+", point: "+score+", place: "+place, x, y);
            } else {
                graphics.drawString("FungusPlayer team_"+key+", point: "+score+", place: "+place, x, y);
            }
            lastScore = score;
            y += 20;
        }
        lastScore = -1;
        place = 1;
        for(Integer key : bugPlayersOrder.keySet()) {
            score = bugPlayersOrder.get(key);
            if(lastScore == -1) {
                lastScore = score;

                graphics.drawString("BugPlayer team_"+key+", point: "+score+", place: "+place, x, y);
            } else if(lastScore > score) {
                place++;
                graphics.drawString("BugPlayer team_"+key+", point: "+score+", place: "+place, x, y);
            } else {
                graphics.drawString("BugPlayer team_"+key+", point: "+score+", place: "+place, x, y);
            }
            lastScore = score;
            y += 20;
        }
    }

}
