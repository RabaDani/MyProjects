import java.util.ArrayList;

/**
 * A ThreadSavingTecton egy speciális Tecton, amely megvédi a rajta lévő fonalakat mindentől
 */
public class ThreadSavingTecton extends Tecton{

    /**
     * Létrehoz egy új ThreadSavingTecton példányt.
     */
    public ThreadSavingTecton() {}

    public boolean addThreadSavingTecton(ThreadSavingTecton tecton){
        return GameLogic.addThreadSavingTecton(tecton);
    }
    /**
     * Frissíti a Tecton állapotát. Ha a breakTime eléri a 0-t és nincs rajta Bug,
     * akkor a Tecton szétesik két új Tectonná, megszüntetve az összes kapcsolatát.
     * Ha lenne rajta fonal, ami meghalna, akkor megmenti azt.
     */
    @Override
    public void update() {
        breakTime--;
        if(breakTime == 0 && bugs.isEmpty()) {
           tectonBreak();
        }else{
            ArrayList<FungalThread> fungalThreadsCopy = new ArrayList<>(fungalThreads);
            for(FungalThread thread : fungalThreadsCopy){
               thread.heal();
            }
        }
    }

    @Override
    public String toString() {
        return "savingtecton";
    }
}

