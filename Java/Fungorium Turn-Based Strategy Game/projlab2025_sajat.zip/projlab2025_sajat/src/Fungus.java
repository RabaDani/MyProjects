import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 * A gombatesteket reprezentáló osztály.
 * A gombatestek a tektonokon helyezkednek el, és spórákat képesek kibocsátani, valamint gombafonalakat létrehozni.
 */
public class Fungus implements Serializable {
    private int sporeTank;
    private int sporeRemainingShots;
    private int sporeGeneratingTime;
    private int sporeType;
    private int upgradeTime;
    private int teamID;
    private Tecton tecton;
    private FungalThread thread;

    /**
     * A Fungus osztály konstruktora.
     * Meghívását jelzi a Skeleton segédosztály segítségével.
     */
    public Fungus() {
        Random rad = new Random();
        sporeTank = 5;
        sporeRemainingShots = 0;
        sporeGeneratingTime = 2;
        upgradeTime = 5;

        if(GameLogic.getRandom()){
            sporeType = rad.nextInt(6) + 1;
        }else{
            sporeType = 1;
        }

        //TODO
        teamID = -1;
    }

    /**
     * Beállítja a gombatest tektonját, arra amire nőtt a gombatest.
     * Meghívását jelzi a Skeleton segédosztály segítségével.
     *
     * @param tecton A gombatest tektonja.
     */
    public void setTecton(Tecton tecton) {
        this.tecton = tecton;
    }

    /**
     * Beállítja a gombatest aktuális gombafonalát.
     * Meghívását jelzi a Skeleton segédosztály segítségével.
     *
     * @param thread A gombatest gombafonala.
     */
    public void setFungalThread(FungalThread thread) {
        this.thread = thread;
    }

    /**
     * Visszaadja a gombatest tektonját
     * @return A gombatest tektonja.
     */
    public Tecton getTecton() {
        return tecton;
    }

    /**
     * Visszaadja a gombatest gombafonalát
     * @return A gombatest gombafonala.
     */
    public FungalThread getThread(){
        return thread;
    }

    /**
     * A Fungus osztály sporeType random generált
     * érték alapján létrehoz egy spórát és hozzáadja a paraméterül kapott tectonhoz.
     * @param t a tecton amihez hozzáadja a létrehozott spórát
     */
    public void generateSpore(Tecton t) {
        switch(sporeType) {
            case 1:
                NeutralSpore s = new NeutralSpore();
                //TODO
                //s.addToGame(s);
                GameLogic.addNeutralSpore(s);
                t.addSpore(s);
                break;
            case 2:
                SpeedSpore sps = new SpeedSpore();
                //TODO
                //sps.addToGame(sps);
                GameLogic.addSpeedSpore(sps);
                t.addSpore(sps);
                break;
            case 3:
                SlowSpore ss = new SlowSpore();
                //TODO
                //ss.addToGame(ss);
                GameLogic.addSlowSpore(ss);
                t.addSpore(ss);
                break;
            case 4:
                ParalyzeSpore ps = new ParalyzeSpore();
                //TODO
                //ps.addToGame(ps);
                GameLogic.addParalyzeSpore(ps);
                t.addSpore(ps);
                break;
            case 5:
                CloneSpore cs = new CloneSpore();
                //TODO
                //cs.addToGame(cs);
                GameLogic.addCloneSpore(cs);
                t.addSpore(cs);
                break;
            case 6:
                CuttingInhibitorSpore cis = new CuttingInhibitorSpore();
                //TODO
                //cis.addToGame(cis);
                GameLogic.addCuttingInhibitorSpore(cis);
                t.addSpore(cis);
                break;
            default:
                System.out.println("Ismeretlen sporeType: " + sporeType);
                break;
        }
    }

    /**
     * Megpróbál spórát kibocsátani a megadott tektonra.
     * Ha a gombatest kitermelt lővéseinek száma legalább 1 (sporeRemainingShots >= 1) és
     * a céltekton szomszédos (ha fejlett szomszéd szomszédja), akkor sikeres lehet a spórakibocsátás.
     * Ha a spóratár kapacitása kimerül (sporeTank == 0), a gomba elpusztul.
     *
     * Meghívását jelzi a Skeleton segédosztály segítségével.
     *
     * @param t A céltekton, ahova a spórát kibocsátja.
     * @return Igaz, ha a spórakibocsátás sikeres volt, különben hamis.
     */
    public boolean releaseSpore(Tecton t) {
        if(sporeRemainingShots < 1 || sporeTank < 1) {
            GameLogic.addInnerError("-not enough spore");
            return false;
        }

        if(!tecton.isNeighbour(t)) {
            if(upgradeTime <= 0) {
                ArrayList<Tecton> neighbourList = tecton.getNeighbourList();

                for(Tecton neighbour : neighbourList) {
                    if(neighbour.isNeighbour(t)) {
                        generateSpore(t);
                        sporeRemainingShots--;
                        sporeTank--;
                        if(sporeTank < 1)
                            die();

                        return true;
                    }
                }
            }
            GameLogic.addInnerError("-tecton too far");
            return false;
        } else {
            generateSpore(t);
            sporeRemainingShots--;
            sporeTank--;
            if(sporeTank < 1)
                die();

            return true;
        }
    }

    /**
     * Megpróbál új gombafonalat létrehozni a gombatest tektonján.
     * Ha a gombatestnek még nincs gombafonala, akkor újat hoz létre, és hozzáadja a tektonhoz.
     * Meghívását jelzi a Skeleton segédosztály segítségével.
     *
     * @return Igaz, ha a gombafonal sikeresen létrejött és hozzáadódott, különben hamis.
     */
    public boolean createFungalThread() {
        if(thread == null) {
            FungalThread newThread = new FungalThread();
            newThread.setTeamID(teamID);

            if(tecton.addFungalThread(newThread) == newThread){
                thread = newThread;
                newThread.setFungus(this);
                GameLogic.addFungalThread(newThread);
                return true;
            }
            return false;
        }
        GameLogic.addInnerError("-thread already present");
        return false;
    }

    /**
     * A gombatest elpusztul, és eltávolítja magát a hozzá kapcsolódó tektonról és gombafonalról.
     * Meghívását jelzi a Skeleton segédosztály segítségével.
     */
    public void die() {
        if(thread != null) {
            thread.setFungus(null);
            thread = null;
        }
        if (tecton != null) {
            tecton.setFungus(null);
            tecton = null;
        }
        GameLogic.removeFungus(this);
    }

    /**
     * Frissíti a gomba állapotát.
     * Jelenleg nem valósít meg konkrét logikát.
     * Meghívását jelzi a Skeleton segédosztály segítségével.
     */
    public void update() {
        sporeGeneratingTime--;
        if(sporeGeneratingTime == 0) {
            sporeGeneratingTime = 2;
            sporeRemainingShots++;
        }
        if(upgradeTime > 0) {
            upgradeTime--;
        }
    }

    /**
     * Visszaadja a csapat kódját
     * @return a csapat kódja, 1-3.
     */
    public int getTeamID() {
        return teamID;
    }

    /**
     * Beállítja a gombatest csapatszámát
     * @param teamID a csapatszám
     */
    public void setTeamID(int teamID) {
        this.teamID = teamID;
    }

    /**
     * Beállítja a gombatest spórakilővéseinek hátralévő számát
     * Ha elfogy, akkor a gombatest elpusztul.
     * @param sporeRemainingShots A kilőhető spórák száma
     */
    public void setSporeRemainingShots(int sporeRemainingShots){
        this.sporeRemainingShots = sporeRemainingShots;
    }

    /**
     * Visszaadja a gombatest spórakilővéseinek hátralévő számát
     * @return hátralévő spórák száma
     */
    public int getSporeRemainingShots(){
        return sporeRemainingShots;
    }

    /**
     * Beállítja a gombatest spóratankjának értékét
     * @param sporeTank a gombatest aktuálisan tárolt spóráinak a száma
     */
    public void setSporeTank(int sporeTank){
        this.sporeTank = sporeTank;
    }

    /**
     * Visszaadja a gombatest spóratankjának értékét
     * @return Megadja hogy hány termelt spórája van a gombatestnek
     */
    public int getSporeTank(){
        return sporeTank;
    }

    /**
     * Visszaadja a spóra típusát
     * @return a spóra típusa, 1-6.
     */
    public int getSporeType() {
        return sporeType;
    }

    /**
     * Beállítja a spóra típusát
     * @param sporeType a spóra típusa, 1-6.
     */
    public void setSporeType(int sporeType) {
        this.sporeType = sporeType;
    }

    /**
     * Visszaadja a spóra generálásának az idejét
     * @return A spóra hátralévő generálásának ideje, 0-2.
     */
    public int getSporeGeneratingTime() {
        return sporeGeneratingTime;
    }

    /**
     * Beállítja a gombatest spóra generálásának hátralévő idejét
     * @param sporeGeneratingTime a spóra generálásának ideje, 0-2.
     */
    public void setSporeGeneratingTime(int sporeGeneratingTime) {
        this.sporeGeneratingTime = sporeGeneratingTime;
    }

    /**
     * Visszaadja a gombatest fejlettségéhez szükséges időt
     * @return a fejlettséghez szükséges idő, 0-5.
     */
    public int getUpgradeTime() {
        return upgradeTime;
    }

    /**
     * Beállítja a gombatest fejlettségéhez szükséges időt
     * @param upgradeTime gombatest fejlettségéhez szükséges időt
     */
    public void setUpgradeTime(int upgradeTime) {
        this.upgradeTime = upgradeTime;
    }


}
