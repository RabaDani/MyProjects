/**
 * A gyorsító spórákat reprezentáló osztály, amely a semleges spórák egy speciális típusa.
 * A rovarok elfogyasztva pontot kapnak, és a sebességük növekszik.
 */
public class SpeedSpore extends NeutralSpore{

    /**
     * A SpeedSpore osztály konstruktora.
     */
    public SpeedSpore(){

    }

    /**
     * Meghívásakor a megadott rovar elfogyasztja a spórát, és pontot kap a tápérték alapján.
     * Ezen kívül a rovar sebessége növekszik.
     * A spóra ezt követően eltávolításra kerül a játéktérből.
     *
     * @param rovar A rovar, amely elfogyasztja a spórát.
     */
    @Override
    public void getAte(Bug rovar) {
        rovar.increasePoints(nutrient);
        rovar.increaseSpeed();
        GameLogic.removeNeutralSpore(this);
    }
}
