import java.io.*;
import java.util.*;

/**
 * A játék logikáját kezelő osztály.
 * Itt történik a parancsok beolvasása, értelmezése, a játék inicializálása, a körök lejátszása és az eredmény meghatározása.
 */
public class GameLogic_old {
    /** A bolygót alkotó tektonok listája. */
    private static ArrayList<Tecton> planet = new ArrayList<>();
    /** A játékban jelen lévő semleges spórák listája. */
    private static ArrayList<NeutralSpore> spores = new ArrayList<>();
    /** Az összes jelen lévő gomba példányokat tárolja. */
    private static ArrayList<Fungus> funguses = new ArrayList<>();
    /** A gombafonalak listája. */
    private static ArrayList<FungalThread> fungalThreads = new ArrayList<>();
    /** Az összes rovar példányokat tárolja. */
    private static ArrayList<Bug> bugs = new ArrayList<>();
    /** A rovarászokat reprezentáló ID-k és pontjaik. */
    private static HashMap<Integer, Integer> bugPlayers = new HashMap<>();
    /** A gombászokat reprezentáló ID-k és pontjaik. */
    private static HashMap<Integer, Integer> fungusPlayers = new HashMap<>();
    /** Objektumok név szerinti leképezése. */
    private static LinkedHashMap<String, Object> objects = new LinkedHashMap<>();
    /** A játék összes köre. */
    private static int gameRounds;
    /** A rovarászok száma. */
    private static int bugPlayerNumber;
    /** A gombászok száma. */
    private static int fungusPlayerNumber;
    /** Meghatározza, hogy véletlenszerű-e a játék. */
    private static boolean random = true;
    /** Az aktuális kör száma. */
    private static int actualRound;

    private static Scanner sc = new Scanner(System.in);

    /** Elmenti a játék állapotát a megadott fájlba. */
    public static void saveGame(String filename) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(planet);
            out.writeObject(spores);
            out.writeObject(funguses);
            out.writeObject(fungalThreads);
            out.writeObject(bugs);
            out.writeObject(bugPlayers);
            out.writeObject(fungusPlayers);
            out.writeObject(objects);
            out.writeInt(gameRounds);
            out.writeInt(bugPlayerNumber);
            out.writeInt(fungusPlayerNumber);
            out.writeBoolean(random);
            out.writeInt(actualRound);
            System.out.println("Game saved");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** Betölti a játék állapotát a megadott fájlból. */
    @SuppressWarnings("unchecked")
    public static void loadGame(String filename) {
        File file = new File(filename);
        if (!file.exists()) {
            System.out.println("Error: There is no previous save");
            return;
        }

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            planet = (ArrayList<Tecton>) in.readObject();
            spores = (ArrayList<NeutralSpore>) in.readObject();
            funguses = (ArrayList<Fungus>) in.readObject();
            fungalThreads = (ArrayList<FungalThread>) in.readObject();
            bugs = (ArrayList<Bug>) in.readObject();
            bugPlayers = (HashMap<Integer, Integer>) in.readObject();
            fungusPlayers = (HashMap<Integer, Integer>) in.readObject();
            objects = (LinkedHashMap<String, Object>) in.readObject();
            gameRounds = in.readInt();
            bugPlayerNumber = in.readInt();
            fungusPlayerNumber = in.readInt();
            random = in.readBoolean();
            actualRound = in.readInt();
            System.out.println("Last save loaded");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    /**
     * A program belépési pontja.
     * Parancssori argumentumoktól függően tesztek futtatása, parancssoros működtetés vagy pálya betöltéses konzolos indítás.
     *
     * @param args Parancssori argumentumok.
     */
    public static void main(String[] args){

        if(args.length == 0){
            startGame();
        } else if (args.length == 1){
            if(args[0].equals("-auto")){
                sys_load(new String[]{"sys_load", "tests/test_list.txt"});
            } else if (args[0].equals("-cmd")){
                commandStart();
            }
        } else if (args.length == 2 && args[0].equals("-p")) {
            if (args.length == 2) {
                sys_load(new String[]{"sys_load", "tests/input/input_"+args[1]});
                sys_log(new String[]{"sys_log", "-s", "tests/output/output_"+args[1]});
            }
        }
    }

    /**
     * Egy listaelemet választ a felhasználótól.
     *
     * @param list A választási lehetőségek listája.
     * @param prompt A megjelenítendő kérdés.
     * @param <T> Az elemek típusa.
     * @return A kiválasztott elem, vagy null, ha nincs elérhető.
     */
    private static <T> T selectFromList(List<T> list, String prompt) {
        if (list.isEmpty()) return null;
        if (list.size() == 1) return list.get(0);
        for(int i = 0; i < list.size(); i++){
            System.out.println("\t["+i+"]" + " " + getObjectName(list.get(i)));
        }
        int index = askInt(prompt + " (0 - " + (list.size() - 1) + "): ", 0, list.size() - 1);
        return list.get(index);
    }

    /**
     * Bekér egy számot a felhasználótól egy adott intervallumban.
     *
     * @param prompt A megjelenítendő kérdés.
     * @param min Az elfogadható minimum érték.
     * @param max Az elfogadható maximum érték.
     * @return A felhasználó által megadott érték.
     */
    private static int askInt(String prompt, int min, int max) {
        int input = -1;
        System.out.print(prompt);
        while (input < min || input > max) {
            while (!sc.hasNextInt()) {
                System.out.print("\tInvalid input. Enter a number: ");
                sc.next();
            }
            input = sc.nextInt();
            if (input < min || input > max) {
                System.out.print("\tOut of range. Try again: ");
            }
        }
        return input;
    }

    /**
     * Inicializálja a játékosokat és pontjaikat.
     */
    private static void initializePlayers() {
        for (int i = 1; i <= fungusPlayerNumber; i++) {
            fungusPlayers.put(i, 0);
        }
        int j = fungusPlayerNumber+1;
        for (int i = 1; i <= bugPlayerNumber; i++) {
            bugPlayers.put(j, 0);
            j++;
        }
    }

    /**
     * Egy rovarász köre.
     *
     * @param id A játékos ID-ja.
     * @return Igaz, ha az akció sikeres volt.
     */
    private static boolean bugTurn(int id){
        if(id == -1) {
            System.out.println("Nem letezo jatekos!");
            return false;
        }

        List<Bug> teamBugs = new ArrayList<>();
        for (Bug bug : bugs) {
            if (bug.getTeamID() == id) {
                teamBugs.add(bug);
            }
        }

        System.out.println("\t[0] Skip action");
        System.out.println("\t[1] Cut thread");
        System.out.println("\t[2] Eat spore");
        System.out.println("\t[3] Move");
        int choice =  askInt("Choose action: ", 0, 3);;
        if (choice == 0) return true;

        Bug selectedBug = selectFromList(teamBugs, "Choose bug");
        if (selectedBug == null) return false;

        switch (choice) {
            case 1: {
                List<Tecton> neighbours = selectedBug.getTecton().getNeighbourList();
                Tecton target = selectFromList(neighbours, "Choose direction to cut");
                if (target != null) return selectedBug.cutThreadAtGap(target);
                return false;
            }
            case 2:
                return selectedBug.eatSpore();
            case 3: {
                List<Tecton> neighbours = selectedBug.getTecton().getNeighbourList();
                Tecton target = selectFromList(neighbours, "Choose direction to move");
                if (target != null) return selectedBug.moveTo(target);
                return false;
            }
            default: return false;
        }
    }

    /**
     * Egy gombász köre.
     *
     * @param id A játékos ID-ja.
     * @return Igaz, ha az akció sikeres volt.
     */
    private static boolean fungusTurn(int id){
        if(id == -1) {
            System.out.println("Nem letezo jatekos!");
            return false;
        }

        List<Fungus> teamFunguses = new ArrayList<>();
        for (Fungus f : funguses) {
            if (f.getTeamID() == id) {
                teamFunguses.add(f);
            }
        }
        List<FungalThread> teamThreads = new ArrayList<>();
        for (FungalThread ft : fungalThreads) {
            if (ft.getTeamID() == id) {
                teamThreads.add(ft);
            }
        }

        System.out.println("\t[0] Skip action");
        System.out.println("\t[1] Grow fungus");
        System.out.println("\t[2] Shoot spore");
        System.out.println("\t[3] Grow thread from fungus");
        System.out.println("\t[4] Grow thread from thread");
        System.out.println("\t[5] Eat paralyzed bugs");
        int choice =  askInt("Choose action: ", 0, 5);;
        if (choice == 0)  return true;

        switch (choice) {
            case 1: {
                FungalThread selected = selectFromList(teamThreads, "Choose thread to grow fungus from: ");
                if (selected != null) return selected.growFungus();
                return false;
            }
            case 2:
                Fungus source = selectFromList(teamFunguses, "Choose fungus to shoot from");
                if (source == null) return false;

                Set<Tecton> targets = new LinkedHashSet<>();
                List<Tecton> directNeighbours = source.getTecton().getNeighbourList();
                targets.addAll(directNeighbours);
                if (source.getUpgradeTime() <= 0) {
                    for (Tecton n : directNeighbours) {
                        targets.addAll(n.getNeighbourList()); // hozzáadja a szomszéd szomszédait
                    }
                }
                targets.remove(source.getTecton()); // ne tudjon saját magára lőni

                List<Tecton> selectableTargets = new ArrayList<>(targets);
                Tecton target = selectFromList(selectableTargets, "Choose direction to shoot spore");
                if (target != null) return source.releaseSpore(target);
                return false;
            case 3:
                Fungus fSource = selectFromList(teamFunguses, "Choose fungus to grow thread from");
                if (fSource != null)  return fSource.createFungalThread();
                return false;
            case 4:
                FungalThread ftSource = selectFromList(teamThreads, "Choose thread to grow from");
                if (ftSource == null || ftSource.getTecton() == null) return false;
                Tecton ftTarget = selectFromList(ftSource.getTecton().getNeighbourList(), "Choose direction");
                if (ftTarget != null) return ftSource.growFungalThread(ftTarget);
                return false;
            case 5: {
                FungalThread selected = selectFromList(teamThreads, "Choose thread to eat bugs from: ");
                if (selected != null) return selected.eatBugs();
                return false;
            }
            default: return false;
        }
    }

    /**
     * A játék indítása, a játékmód kiválasztásával és a pálya betöltésével.
     */
    private static void startGame() {
        // Constants and configuration
        final String SAVE_FILE_PATH = "mentes.txt";
        final String MAP_2V2_PATH = "assets//map//2v2_mode.txt";
        final String MAP_3V3_PATH = "assets//map//3v3_mode.txt";

        int gameMode;
        File saveFile = new File(SAVE_FILE_PATH);
        int MODE_2V2 = 0;
        int MODE_3V3 = 1;

        if (saveFile.exists()) {
            System.out.println("=== Fungorium ===");
            System.out.println("Welcome!");
            int loadChoice = askInt("Want to load the last save?\n\t[0]: yes \n\t[1]: no\nChoose: ", 0, 1);

            if (loadChoice == 0) {
                loadGame(SAVE_FILE_PATH);
            } else {
                System.out.println("Choose game mode:");
                gameMode = askInt("\t[0]: 2v2 \n\t[1]: 3v3\nChoose game mode: ", MODE_2V2, MODE_3V3);
                bugPlayerNumber = (gameMode == MODE_2V2) ? 2 : 3;
                fungusPlayerNumber = bugPlayerNumber;

                initializePlayers();
                gameRounds = askInt("Number of rounds (5 - 50): ", 5, 50);

                String[] mapToLoad = {"sys_load", (gameMode == MODE_2V2) ? MAP_2V2_PATH : MAP_3V3_PATH};
                sys_load(mapToLoad);
                actualRound = 1;
            }
        } else {
            //Nincs mentés
            System.out.println("=== Fungorium ===");
            System.out.println("Welcome!");
            gameMode = askInt("\t[0]: 2v2 \n\t[1]: 3v3\nChoose game mode: ", MODE_2V2, MODE_3V3);
            bugPlayerNumber = (gameMode == MODE_2V2) ? 2 : 3;
            fungusPlayerNumber = bugPlayerNumber;

            initializePlayers();
            gameRounds = askInt("Number of rounds (5 - 50): ", 5, 50);

            // Load appropriate map file based on game mode
            String[] mapToLoad = {"sys_load", (gameMode == MODE_2V2) ? MAP_2V2_PATH : MAP_3V3_PATH};
            sys_load(mapToLoad);
            actualRound = 1;
        }

        while (actualRound <= gameRounds) {
            for (Integer teamID : fungusPlayers.keySet()) {
                startTurn(teamID);
            }

            for (Integer teamID : bugPlayers.keySet()) {
                startTurn(teamID);
            }

            endTurn();
            actualRound++;

            if (actualRound <= gameRounds) {
                System.out.println("\n=== End of the round ===");
                System.out.println("\t[0] Go to next round");
                System.out.println("\t[1] Save game");
                System.out.println("\t[2] Load last save");

                int choice = askInt("Choose: ", 0, 2);
                switch (choice) {
                    case 0:
                        break;
                    case 1:
                        saveGame(SAVE_FILE_PATH);
                        break;
                    case 2:
                        loadGame(SAVE_FILE_PATH);
                        break;
                }
            }
        }

        endGame();
    }

    /**
     * Egy játékos körének lejátszása.
     *
     * @param id A játékos ID-ja.
     */
    private static void startTurn(int id) {
        int actions = 2;
        while(actions > 0){

            boolean res = false;
            if(id <= fungusPlayerNumber) {
                //Akkor gombásznak megfelelő actions-ket fogad el
                System.out.println("\nRound: "+actualRound+"\nFungusPlayer"+id+" turn:\n(actions: "+actions+")");
                res = fungusTurn(id);
                System.out.println(res ? "Success" : "Failure");
            } else if(id > fungusPlayerNumber && id <= (fungusPlayerNumber + bugPlayerNumber)) {
                //Akkor rovarásznak megfelelő actions-ket fogad el
                System.out.println("\nRound: "+actualRound+"\nBugPlayer"+id+" turn:\n(actions: "+actions+")");
                res = bugTurn(id);
                System.out.println(res ? "Success" : "Failure");
            }  else {
                //rossz bement, hibát dob.
            }

            if(res)
                actions--;
        }
    }

    /**
     * Egy kör végén frissíti az összes entitás állapotát.
     */
    private static void endTurn() {
        List<Bug> bugList = new ArrayList<>(bugs);
        for(Bug b : bugList) {
            b.update();
        }

        List<FungalThread> threadList = new ArrayList<>(fungalThreads);
        for(FungalThread f : threadList) {
            f.update();
        }

        List<Tecton> tectonList = new ArrayList<>(planet);
        for (Tecton t : tectonList) {
            t.update();
        }

        List<Fungus> fungusList = new ArrayList<>(funguses);
        for(Fungus f : fungusList) {
            f.update();
        }
    }

    /**
     * Kiértékeli a játék végén az eredményeket, és meghirdeti a győzteseket.
     */
    private static void endGame() {
        int maxBugPoints = -1;
        List<Integer> bestBugPlayers = new ArrayList<>();

        // Rovarász nyertesek keresése
        for (Map.Entry<Integer, Integer> entry : bugPlayers.entrySet()) {
            int teamID = entry.getKey();
            int points = entry.getValue();

            if (points > maxBugPoints) {
                maxBugPoints = points;
                bestBugPlayers.clear();
                bestBugPlayers.add(teamID);
            } else if (points == maxBugPoints) {
                bestBugPlayers.add(teamID);
            }
        }

        int maxFungusPoints = -1;
        List<Integer> bestFungusPlayers = new ArrayList<>();

        // Gombász nyertesek keresése
        for (Map.Entry<Integer, Integer> entry : fungusPlayers.entrySet()) {
            int teamID = entry.getKey();
            int points = entry.getValue();

            if (points > maxFungusPoints) {
                maxFungusPoints = points;
                bestFungusPlayers.clear();
                bestFungusPlayers.add(teamID);
            } else if (points == maxFungusPoints) {
                bestFungusPlayers.add(teamID);
            }
        }

        // Kiírás
        System.out.println("\n=== Game Over ===");
        System.out.println("Winner Bug Player(s) with " + maxBugPoints + " point(s):");
        for (int id : bestBugPlayers) {
            System.out.println("\tBugPlayer" + id);
        }
        System.out.println("Winner Fungus Player(s) with " + maxFungusPoints + " point(s):");
        for (int id : bestFungusPlayers) {
            System.out.println("\tFungusPlayer" + id);
        }
    }


    public GameLogic_old(int gameRounds, int bugPlayerNumber, int fungusPlayerNumber) {
        this.gameRounds = gameRounds;
        this.bugPlayerNumber = bugPlayerNumber;
        this.fungusPlayerNumber = fungusPlayerNumber;
    }

    public static boolean addTecton(Tecton t) {
        tectonId++;
        objects.put("tecton"+tectonId, t);

        return planet.add(t);
    }

    public static boolean removeTecton(Tecton t) {
        objects.remove(getObjectName(t));

        return planet.remove(t);
    }

    public static ArrayList<Tecton> getTectons() {
        return planet;
    }

    public static boolean addNeutralSpore(NeutralSpore s) {
        neutralSporeId++;
        objects.put("n_spore"+neutralSporeId, s);

        return spores.add(s);
    }

    public static boolean removeNeutralSpore(NeutralSpore s) {
        objects.remove(getObjectName(s));
        return spores.remove(s);
    }

    public static ArrayList<NeutralSpore> getSporeList() {
        return spores;
    }

    public static boolean addFungus(Fungus f) {
        fungusId++;
        objects.put("fungus"+fungusId, f);
        return funguses.add(f);
    }

    public static boolean removeFungus(Fungus f) {
        objects.remove(getObjectName(f));
        return funguses.remove(f);
    }

    public static ArrayList<Fungus> getFungusList() {
        return funguses;
    }

    public static boolean addBug(Bug b) {
        bugId++;
        objects.put("bug"+bugId, b);
        return bugs.add(b);
    }

    public static boolean removeBug(Bug b) {
        objects.remove(getObjectName(b));
        return bugs.remove(b);
    }

    public static ArrayList<Bug> getBugList() {
        return bugs;
    }

    public static boolean addFungalThread(FungalThread ft) {
        threadId++;
        objects.put("fthread"+threadId, ft);
        return fungalThreads.add(ft);
    }

    public static boolean removeFungalThread(FungalThread ft) {
        objects.remove(getObjectName(ft));
        return fungalThreads.remove(ft);
    }

    public static boolean addThreadDissolvingTecton(ThreadDissolvingTecton tdt) {
        dissolvingTectonId++;
        objects.put("td_tecton"+dissolvingTectonId, tdt);
        return planet.add(tdt);
    }

    public static boolean addThreadSavingTecton(ThreadSavingTecton tsd) {
        savingTectonId++;
        objects.put("ts_tecton"+savingTectonId, tsd);
        return planet.add(tsd);
    }

    public static boolean addSpeedSpore(SpeedSpore sps){
        speedSporeId++;
        objects.put("sp_spore"+speedSporeId, sps);
        return spores.add(sps);
    }

    public static boolean addSlowSpore(SlowSpore sls){
        slowSporeId++;
        objects.put("sl_spore"+slowSporeId, sls);
        return spores.add(sls);
    }

    public static boolean addParalyzeSpore(ParalyzeSpore pas){
        paralyzeSporeId++;
        objects.put("p_spore"+paralyzeSporeId, pas);
        return spores.add(pas);
    }

    public static boolean addCloneSpore(CloneSpore cs){
        cloneSporeId++;
        objects.put("c_spore"+cloneSporeId, cs);
        return spores.add(cs);
    }

    public static boolean addCuttingInhibitorSpore(CuttingInhibitorSpore cis){
        ciSporeId++;
        objects.put("ci_spore"+ciSporeId, cis);
        return spores.add(cis);
    }


    public static ArrayList<FungalThread> getFungalThreadList() {
        return fungalThreads;
    }

    //Példa fv csak
    public static boolean removeObject(Object o) {
        String key = null;

        for(String k: objects.keySet()) {
            if(objects.get(k).equals(o)) {
                key=k;
                break;
            }
        }
        return objects.remove(key) != null;
    }

    public static LinkedHashMap<String, Object> getObjects() {
        return objects;
    }

    public static int getBugPlayerNumber(){
        return bugPlayerNumber;
    }

    public static int getFungusPlayerNumber(){
        return fungusPlayerNumber;
    }

    public static int getGameRounds(){
        return gameRounds;
    }

    public static boolean getRandom(){
        return random;
    }

    public static void addPoints(int teamId, int points) {
        if (bugPlayers.containsKey(teamId)) {
            bugPlayers.put(teamId, bugPlayers.get(teamId) + points);
        } else if (fungusPlayers.containsKey(teamId)) {
            fungusPlayers.put(teamId, fungusPlayers.get(teamId) + points);
        }
    }


    //Új
    public static String getObjectName(Object obj) {
        for(String key : objects.keySet()) {
            if(obj == objects.get(key))
                return key;
        }
        return "";
    }

    /**
     * Innen kezdődik a parancsfeldolgozással kapcsolatos rész.
     */

    /**
     * Parancsfeldolgozással kapcsolatos attribútumok
     */
    // Tárolja a log üzenetek tartalmát: Hiba üzenetek, státusz üzenetek, játék vége üzenet
    private static List<String> logger = new ArrayList<>();
    //Tárolja a rovarász és gombász parancsain belül történő hibaüzeneteket
    private static List<String> errorLog = new ArrayList<>();

    // A pillanatnyilag felhasznált legnagyobb Id az adott típusnak megfelelően
    private static int tectonId = 0;
    private static int savingTectonId = 0;
    private static int dissolvingTectonId = 0;
    private static int threadId = 0;
    private static int fungusId = 0;
    private static int bugId = 0;
    private static int neutralSporeId = 0;
    private static int speedSporeId = 0;
    private static int slowSporeId = 0;
    private static int paralyzeSporeId = 0;
    private static int cloneSporeId = 0;
    private static int ciSporeId = 0;

    // A parancsfeldolgozás során a futtást jelzi
    private static boolean commandRunning = true;

    /**
     * Inicializálja a parancssoros irányítást, majd ciklikusan inputot vár,
     * amíg a kilépést jelző commandRunning nem állítódik false értékre.
     * A parancssorok elején található whitespace karaktereket levágja,
     * majd a "SPACE" karakterek mentén feldarabolja a beolvasott sort.
     */
    public static void commandStart() {
        gameRounds = 30;

        //Új játék indítása és inicializálása 2v2 módban.
        sys_startGame(new String[] {"", "2"});
        String line;
        while (commandRunning) {
            line = sc.nextLine();
            //A sor elején található whitespace karakterek levágása, és SPACE karakterek mentén történő feldarabolása.
            String[] commandLine = line.strip().split(" ");
            if(commandLine.length > 0)
                commandProcess(commandLine);
        }
    }

    /**
     * A GameLogicban keletkező és a paraméterben érkező hibaüzeneteket írja ki a konzolra
     * és menti el a loggerbe.
     * @param error A kiírásra és mentésrekerülő hibaüzenet.
     */
    private static void addErrorLine(String error) {
        System.out.println(error);
        logger.add(error);
    }

    /**
     * A rovarász és gombász utasításaiban keletkező hibaüzenetek fogadásáért és eltárolásáért felelős.
     * Ezt a hibaüzenetet a GameLogic később felhasználhatja a loggerbe mentésre kerülő hibaüzenet létrehozására.
     * @param error A mentésre kerülő hibaüzenet.
     */
    public static void addInnerError(String error) {
        errorLog.add(error);
    }

    /**
     * A parancssorok feldolgozásának első lépése.
     * A megfelelő parancskezelőt hivja meg a commandLine első értéke alapján amennyiben az nem "#"-gel kezdődik.
     * Amennyiben nem található az értéknek megfelelő parancs, és a sor nem "#"-gel kezdődik, úgy hibaüzenet ad.
     * @param commandLine A feldolgozandó parancssor
     */
    private static void commandProcess(String[] commandLine) {
        if(commandLine[0].equals("sys_create")) {
            sys_create(commandLine);

        } else if(commandLine[0].equals("sys_add_T")) {
            sys_add_T(commandLine);

        } else if(commandLine[0].equals("sys_add_F")) {
            sys_add_F(commandLine);

        } else if(commandLine[0].equals("sys_delete")) {
            sys_delete(commandLine);

        } else if(commandLine[0].equals("sys_remove_T")) {
            sys_remove_T(commandLine);

        } else if(commandLine[0].equals("sys_remove_F")) {
            sys_remove_F(commandLine);

        } else if(commandLine[0].equals("sys_tecton")) {
            sys_tecton(commandLine);

        } else if(commandLine[0].equals("sys_fungus")) {
            sys_fungus(commandLine);

        } else if(commandLine[0].equals("sys_bug")) {
            sys_bug(commandLine);

        } else if(commandLine[0].equals("sys_fungal")) {
            sys_fungal(commandLine);

        } else if(commandLine[0].equals("sys_spore")) {
            sys_spore(commandLine);

        } else if(commandLine[0].equals("sys_update")) {
            sys_update(commandLine);

        } else if(commandLine[0].equals("sys_status")) {
            sys_status(commandLine);

        } else if(commandLine[0].equals("sys_list")) {
            sys_list(commandLine);

        } else if(commandLine[0].equals("sys_load")) {
            sys_load(commandLine);

        } else if(commandLine[0].equals("sys_help")) {
            sys_help();

        } else if(commandLine[0].equals("sys_randgen")) {
            sys_randgen();

        } else if(commandLine[0].equals("sys_exit")) {
            commandRunning = false;

        } else if(commandLine[0].equals("sys_startGame")) {
            sys_startGame(commandLine);

        } else if(commandLine[0].equals("sys_gameOver")) {
            sys_gameOver();

        } else if(commandLine[0].equals("sys_log")) {
            sys_log(commandLine);

        } else if(commandLine[0].equals("move")) {
            move(commandLine);

        } else if(commandLine[0].equals("cut")) {
            cut(commandLine);

        } else if(commandLine[0].equals("eat")) {
            eat(commandLine);

        } else if(commandLine[0].equals("growThread")) {
            growThread(commandLine);

        } else if(commandLine[0].equals("growFungus")) {
            growFungus(commandLine);

        } else if(commandLine[0].equals("shootSpore")) {
            shootSpore(commandLine);

        } else if(commandLine[0].equals("dissolveBug")) {
            dissolveBug(commandLine);

        } else if (!commandLine[0].isBlank() && !commandLine[0].equals("#")) {
            addErrorLine(commandLine[0] + " FAIL -unkown command");
        }
    }

    /**
     * Az objektumok létrehozását végző parancskezelő.
     * <p>
     * Létrehozza a cmd második értékének megfelelő típusú objektumot,
     * és hozzáadja azt a GameLogichoz.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <br> -missing parameter: Ha nem adnak meg opciót.
     * <br>-incorrect parameter: Ha nem létező opciót adnak meg.
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_create(String[] cmd) {
        if(cmd.length == 1) {
            addErrorLine("sys_create FAIL -missing parameter");
            return;
        }

        if(cmd[1].equals("-t")) {
            addTecton(new Tecton());

        } else if(cmd[1].equals("-tdt")) {
            addThreadDissolvingTecton(new ThreadDissolvingTecton());

        } else if(cmd[1].equals("-tst")) {
            addThreadSavingTecton(new ThreadSavingTecton());

        } else if(cmd[1].equals("-f")) {
            addFungalThread(new FungalThread());

        } else if(cmd[1].equals("-g")) {
            addFungus(new Fungus());

        } else if(cmd[1].equals("-b")) {
            addBug(new Bug());

        } else if(cmd[1].equals("-ns")) {
            addNeutralSpore(new NeutralSpore());

        } else if(cmd[1].equals("-sps")) {
            addSpeedSpore(new SpeedSpore());

        } else if(cmd[1].equals("-sls")) {
            addSlowSpore(new SlowSpore());

        } else if(cmd[1].equals("-ps")) {
            addParalyzeSpore(new ParalyzeSpore());

        } else if(cmd[1].equals("-cs")) {
            addCloneSpore(new CloneSpore());

        } else if(cmd[1].equals("-cis")) {
            addCuttingInhibitorSpore(new CuttingInhibitorSpore());

        } else {
            addErrorLine("sys_create FAIL -incorrect parameter");
        }
    }

    /**
     * Egy Tecton és egy másik objektum közötti kapcsolat létrehozását végző parancskezelő.
     * <p>
     * A cmd 2. és 3. értéke alapján megpróbál azonos Id-val rendelkező objektumot keresni.
     * Ha a 2. értékű Id létezik és valóban egy Tecton típushoz (vagy leszármazotthoz) tartozik,
     * továbbá a 3. értékű Id is létezik, akkor a típusának megfelelő módon kapcsolatot hoz létre
     * közte és a tekton között.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Ha kevesebb mint 2 id van megadva.
     *     <li> unkown id: Ha a két id közül bármely olyan, hogy az nem található a rendszerben.
     *     <li> incorrect parameter: Ha tekton_id-nak nem Tecton (vagy leszármozottai) típusú objektum id-ját adnak meg.
     *     <li> max fungus reached: Gombatest hozzáadása esetén, ha már nem fér a tektonra több tekton
     *     <li> max thread reached: Gombafonal hozzáadása esetén, ha már nem fér a tektonra több fonal, vagy a tektonon már található a csapathoz tartozó fonal.
     *     <li> cannot add tecton: Ha az objektum amit a tektonhoz szeretnénk adni (és ezzel az objektumhoz a tekton adni), már rendelkezik tekton asszociációval, akkor az nem állítható át szabadon. Érintett típusok: Bug, FungalThread, Fungus
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_add_T(String[] cmd) {
        if(cmd.length <= 2) {
            //Hiányos opció
            addErrorLine("sys_add_T FAIL -missing parameter");
            return;
        }

        //Az megadott id alapján az objektumok lekérdezése
        Object t = objects.get(cmd[1]);
        Object other_o = objects.get(cmd[2]);

        //Annak ellenőrzése, hogy mindkettő Id-hoz tartozik objektum
        if(t == null || other_o == null) {
            addErrorLine("sys_add_T FAIL -unknown id");
            return;
        }

        //Az objektumok típusának lekérdezése
        String t_name = t.getClass().getName();
        String other_name = other_o.getClass().getName();

        //Annak ellenőrzése, hogy az első Id-hoz tartozó objektum Tecton típusú
        if(!t_name.contains("Tecton")) {
            addErrorLine("sys_add_T FAIL -incorrect parameter");
            return;
        }

        Tecton tecton = (Tecton) t;

        if(other_name.contains("Tecton")) {
            //Ha a második Id-nak megfelelő objektum Tecton vagy leszármazott típusú
            Tecton other_tecton = (Tecton) other_o;
            if (tecton == other_tecton) {
                addErrorLine("sys_add_T FAIL -cannot add tecton");
                return;
            }
            // tecton - tecton odavissza történő kapcsolat beállítása
            tecton.addNeighbour(other_tecton);
            other_tecton.addNeighbour(tecton);

        } else if(other_name.contains("Spore")) {
            //Ha a második Id-nak megfelelő objektum NeutralSpore vagy leszármazott típusú
            NeutralSpore spore = (NeutralSpore) other_o;

            // tecton - spore egyirányú kapcsolat beállítása
            tecton.addSpore(spore);

        } else if(other_name.equals("Fungus")) {
            //Ha a második Id-nak megfelelő objektum Fungus típusú
            Fungus fungus = (Fungus)other_o;
            if(tecton.getFungus() == fungus) {
                //Már létező kapcsolat, nincs hiba
                return;
            }

            if(tecton.maxFungus == 0 || tecton.getFungus() != null) {
                //Annak ellenőrzése, hogy a tektonra még fér gombatest
                addErrorLine("sys_add_T FAIL -max fungus reached");
                return;
            } else if(fungus.getTecton() != null && fungus.getTecton() != tecton) {
                //Annak ellenőrzése, hogy a gombatestnek nincs tekton beállítva, vagy ha nem azonos a mostanival
                addErrorLine("sys_add_T FAIL -cannot add tecton");
                return;
            }
            // tecton - fungus odavissza történő kapcsolat beállítása
            tecton.setFungus(fungus);
            fungus.setTecton(tecton);

        } else if(other_name.equals("FungalThread")) {
            //Ha a második Id-nak megfelelő objektum FungalThread típusú
            FungalThread fungalThread = (FungalThread)other_o;
            if(tecton.getThreadList().contains(fungalThread)) {
                //Már létező kapcsolat, nincs hiba
                return;
            }

            //A tektonon levő fonalak lekérése
            List<FungalThread> threadList = tecton.getThreadList();
            boolean hasTeam = false;
            for(FungalThread thread : threadList) {
                //Ellenőrzés, hogy van-e azonos csapathoz tartozó fonal a tektonon
                if(thread.getTeamID() == fungalThread.getTeamID()) {
                    hasTeam = true;
                    break;
                }
            }
            if(tecton.getMaxFungalThread() == tecton.getThreadList().size() || hasTeam) {
                //Ha nem fér több fonal a tektonra.
                addErrorLine("sys_add_T FAIL -max thread reached");
                return;
            } else if(fungalThread.getTecton() != null && fungalThread.getTecton() != tecton) {
                //Ha a fonal rendelkezik beállított tektonnal, ami különbözik a beállítandótól
                addErrorLine("sys_add_T FAIL -cannot add tecton");
                return;
            }
            // tecton - fonal odavissza történő kapcsolat beállítása
            fungalThread.setTecton(tecton);
            tecton.addFungalThread(fungalThread);

        } else if(other_name.equals("Bug")) {
            Bug bug = (Bug)other_o;
            if(bug.getTecton() != null && bug.getTecton() != tecton) {
                //Ha a rovar rendelkezik beállított tektonnal, ami különbözik a beállítandótól
                addErrorLine("sys_add_T FAIL -cannot add tecton");
                return;
            }
            // tecton - rovar odavissza történő kapcsolat beállítása
            bug.setTecton(tecton);
            tecton.addBug(bug);
        }
    }

    /**
     * Egy Fonal és egy másik objektum közötti kapcsolat létrehozását végző parancskezelő.
     * <p>
     * A cmd 2. és 3. értéke alapján megpróbál azonos Id-val rendelkező objektumot keresni.
     * Ha a 2. értékű Id létezik és valóban egy FungalThread típushoz tartozik,
     * továbbá a 3. értékű Id is létezik, akkor a típusának megfelelő módon kapcsolatot hoz létre
     * közte és a fonal között. A hozzáadandó objektumok csak: FungalThread, Fungus, Tecton és leszármazottai típusúak lehetnek.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Ha kevesebb mint 2 id van megadva.
     *     <li> incorrect parameter: Ha a 2. Id olyan objektumhoz tartozik aminek a típusa: Bug, NeutralSpore (vagy leszármazottai)
     *     <li> unkown id: Ha a két id közül bármely nem található a rendszerben.
     *     <li> cannot add tecton: A 2. Id egy tectonhoz tartozik, és a fonal már rendelkezik tecton asszociációval.
     *     <li> max thread reached: A 2. Id egy tectonhoz tartozik, és a tectonhoz már nem adható több fonal, vagy a tektonon már található a csapathoz tartozó fonal.
     *     <li> cannot add fungus: A 2. Id  egy gombatesthez tartozik és a fonal - gombatest kapcsolat nem jöhet létre.
     *     <li> cannot add thread: A 2. Id egy fonalhoz tartozik és a két fonal nem egy csapatba tartozik, vagy nem szomszédosak a tektonjaik.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_add_F(String[] cmd) {
        // Paraméterek számának ellenőrzése
        if(cmd.length <= 2) {
            addErrorLine("sys_add_F FAIL -missing parameter");
            return;
        }

        //Az megadott id alapján az objektumok lekérdezése
        Object first_o = objects.get(cmd[1]);
        Object other_o = objects.get(cmd[2]);

        //Annak ellenőrzése, hogy mindkettő Id-hoz tartozik objektum
        if(first_o == null || other_o == null) {
            addErrorLine("sys_add_F FAIL -unknown id");
            return;
        }

        //Az objektumok típusának lekérdezése
        String f_name = first_o.getClass().getName();
        String other_name = other_o.getClass().getName();

        // Ha az első id nem fonalhoz tartozik, vagy éppen spórát vagy rovart próbálnak hozzáadni a fonalhoz
        if(!f_name.equals("FungalThread") || other_name.contains("Spore") || other_name.equals("Bug")) {
            addErrorLine("sys_add_F FAIL -incorrect parameter");
            return;
        }
        // Az első objektum castolása fonallá
        FungalThread fungalThread = (FungalThread) first_o;

        if(other_name.contains("Tecton")) {
            //Ha a második Id-nak megfelelő objektum Tecton vagy leszármazott típusú
            Tecton tecton = (Tecton) other_o;
            if(fungalThread.getTecton() == tecton) {
                //Már létező kapcsolat, nincs hiba
                return;
            }

            List<FungalThread> threadList = tecton.getThreadList();
            boolean hasTeam = false;
            for(FungalThread thread : threadList) {
                if(thread.getTeamID() == fungalThread.getTeamID()) {
                    hasTeam = true;
                    break;
                }
            }
            if(tecton.getMaxFungalThread() == tecton.getThreadList().size() || hasTeam) {
                addErrorLine("sys_add_F FAIL -max thread reached");
                return;

            } else if(fungalThread.getTecton() != null && fungalThread.getTecton() != tecton) {
                addErrorLine("sys_add_F FAIL -cannot add tecton");
                return;
            }

            fungalThread.setTecton(tecton);
            tecton.addFungalThread(fungalThread);

        } else if(other_name.equals("FungalThread")) {
            //Ha a második Id-nak megfelelő objektum FungalThread típusú
            FungalThread other_fungalThread = (FungalThread)other_o;
            if(fungalThread.getConnections().contains(other_fungalThread)) {
                //Már létező kapcsolat, nincs hiba
                return;
            }

            if(other_fungalThread.getTeamID() != fungalThread.getTeamID()) {
                //Egyező teamId-k ellenőrzése
                addErrorLine("sys_add_F FAIL -cannot add thread");
                return;
            }

            if(fungalThread.getTecton() == null || other_fungalThread.getTecton() == null || !fungalThread.getTecton().getNeighbourList().contains(other_fungalThread.getTecton())) {
                //Ha a két fonal tektonja nem szomszédos
                addErrorLine("sys_add_F FAIL -cannot add thread");
                return;
            }
            fungalThread.addConnection(other_fungalThread);
            other_fungalThread.addConnection(fungalThread);

        } else if(other_name.equals("Fungus")) {
            Fungus fungus = (Fungus) other_o;
            if(fungalThread.getFungus() == fungus){
                //Már létező kapcsolat, nincs hiba
                return;
            }

            if(fungus.getThread() != null || fungus.getTeamID() != fungalThread.getTeamID() || fungus.getTecton() == null || !fungus.getTecton().equals(fungalThread.getTecton())) {
                addErrorLine("sys_add_F FAIL -cannot add fungus");
                return;
            }

            fungalThread.setFungus(fungus);
            fungus.setFungalThread(fungalThread);
        }
    }

    /**
     *  Az objektumokat törlő parancskezelő.
     * <p>
     * Opció megadása nélkül az összes objektumot törli a rendszerből
     * és az aktuálisan leganygobb Id számlálóját kezdetire állítja.
     * Opció megadása esetén (cmd 2. értéke) csak az adott Id-nak megfelelő objektumot törli a rendszerból.
     * A törléssel együtt az összes asszociációs kapcsolatát is megszünteti a törölt objektumnak
     * és azokból is törli, akik kapcsolatban voltak vele.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> -missing parameter: Ha kevesebb mint 2 id van megadva.
     *     <li>
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_delete(String[] cmd) {
        if(cmd.length > 1) {
            //Csak a kijelölt objektum törlésének esete

            //Az megadott id alapján az objektum lekérdezése
            Object first_o = objects.get(cmd[1]);
            if(first_o == null) {
                addErrorLine("sys_delete FAIL -unknown id");
                return;
            }
            String f_name = first_o.getClass().getName();

            if(f_name.equals("FungalThread")) {
                FungalThread fungalThread = (FungalThread) first_o;
                fungalThread.die();
            } else if(f_name.equals("Bug")) {
                Bug bug = (Bug)first_o;
                bug.dissolve();
            } else if(f_name.equals("Fungus")) {
                Fungus fungus = (Fungus) first_o;
                fungus.die();
            } else if(f_name.contains("Tecton")) {
                Tecton tecton = (Tecton) first_o;

                // Új listát kap return-ben ezért nincs concurrentmodification hiba
                List<Tecton> nbs = tecton.getNeighbourList();
                // Szomszédsági kapcsolatok törlése
                for(Tecton nb : nbs) {
                    nb.removeNeighbour(tecton);
                    tecton.removeNeighbour(nb);
                }

                // A tekton listáját kapja és nem másolatot
                List<FungalThread> threadList = tecton.getThreadList();
                // Fonalakkal kapcsolatok törlése
                for(FungalThread thread : threadList) {
                    thread.setTecton(null);
                }
                threadList.clear();

                //Gombatesttel kapcsolat törlése
                Fungus f = tecton.getFungus();
                if(f != null) {
                    f.setTecton(null);
                    tecton.setFungus(null);
                }

                //Az eredeti listát kapja nem másolatot.
                List<Bug> bugList = tecton.getBugList();
                // Rovarokkal kapcsolatok törlése
                for(Bug bug : bugList) {
                    bug.setTecton(null);
                }
                bugList.clear();

                //Másolatot kap
                List<NeutralSpore> sporeList = tecton.getSporeList();
                for(NeutralSpore spore : sporeList) {
                    tecton.removeSpore(spore);
                }

                removeTecton(tecton);

            } else if(f_name.contains("Spore")) {
                NeutralSpore delSpore = (NeutralSpore) first_o;

                //Minden tekton átnézése a spóra után
                for (Tecton tecton : planet) {
                    List<NeutralSpore> sporeList = tecton.getSporeList();
                    for(NeutralSpore spore : sporeList) {
                        if(spore.equals(delSpore)) {
                            tecton.removeSpore(spore);
                            break;
                        }
                    }
                }
                removeNeutralSpore(delSpore);
            }
        } else {
            //Ha nincs opció megadva akkor minden elemet töröl
            for(Bug b : bugs) {
                b.setTecton(null);
            }
            bugs.clear();

            List<FungalThread> threadList = new ArrayList<>(fungalThreads);
            for(FungalThread f : threadList) {
                f.die();
            }
            fungalThreads.clear();

            List<Fungus> fungusList = new ArrayList<>(funguses);
            for (Fungus f : fungusList) {
                f.die();
            }
            funguses.clear();

            for (Tecton t : planet) {
                List<NeutralSpore> sporeList = t.getSporeList();
                for (NeutralSpore spore : sporeList) {
                    t.removeSpore(spore);
                }
            }
            spores.clear();
            planet.clear();
            objects.clear();
            tectonId = 0;
            savingTectonId = 0;
            dissolvingTectonId = 0;
            fungusId = 0;
            threadId = 0;
            bugId = 0;
            neutralSporeId = 0;
            speedSporeId = 0;
            slowSporeId = 0;
            paralyzeSporeId = 0;
            cloneSporeId = 0;
            ciSporeId = 0;
        }
    }

    /**
     * Egy tekton kapcsolatainak megszűntetését végző parancskezelő.
     * <p>
     * Opció megadása nélkül az összes objektum kapcsolatát törli a tektonnak, és az objektumokból is törli a tekton kapcsolatukat.
     * Opció megadása esetén a kijelölt objektummal való kapcsolatát szünteti meg.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Az id hiánya esetén.
     *     <li> unkown id: Ha az id nem található a rendszerben vagy az 1. Id nem Tektonhoz tartozik.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_remove_T(String[] cmd) {
        if(cmd.length <= 1) {
            addErrorLine("sys_remove_T FAIL -missing parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        String f_name = first_o.getClass().getName();

        if(first_o == null || !f_name.contains("Tecton")) {
            addErrorLine("sys_remove_T FAIL -unkonwn id");
            return;
        }

        Tecton tecton = (Tecton) first_o;

        if(cmd.length >= 3) {
            Object other_o = objects.get(cmd[2]);
            String other_name = other_o.getClass().getName();
            if (other_o == null) {
                addErrorLine("sys_remove_T FAIL -unkonwn id");
                return;
            }

            if(other_name.contains("Tecton")) {
                Tecton other = (Tecton) other_o;
                tecton.removeNeighbour(other);
                other.removeNeighbour(tecton);
            } else if(other_name.contains("Spore")) {
                NeutralSpore other = (NeutralSpore) other_o;
                tecton.removeSpore(other);
            } else if(other_name.equals("Bug")) {
                Bug other = (Bug) other_o;
                if(other.getTecton() == tecton) {
                    other.setTecton(null);
                    tecton.removeBug(other);
                }
            } else if(other_name.equals("FungalThread")) {
                FungalThread other = (FungalThread) other_o;
                if(other.getTecton() == tecton) {
                    removeFungalThreadAssoc(other);
                }
            } else if(other_name.equals("Fungus")) {
                Fungus other = (Fungus) other_o;
                if(other.getTecton() == tecton) {
                    other.setTecton(null);
                    FungalThread thread = other.getThread();

                    if(thread != null) {
                        thread.setFungus(null);
                        other.setFungalThread(null);
                    }
                    tecton.setFungus(null);
                }
            }
        } else {
            //2. Id megadása nélkül az 1. Id-nak megfelelő tekton minden kapcsolata megszűnik.
            Fungus fungus = tecton.getFungus();
            if (fungus != null) {
                fungus.setTecton(null);
                tecton.setFungus(null);
            }

            List<NeutralSpore> sporeList = tecton.getSporeList();
            for (NeutralSpore spore : sporeList) {
                tecton.removeSpore(spore);
            }

            List<Bug> bugList = tecton.getBugList();
            for (Bug bug : bugList) {
                bug.setTecton(null);
            }
            bugList.clear();

            List<FungalThread> threadList = new ArrayList<>(tecton.getThreadList());
            for (FungalThread thread : threadList) {
                removeFungalThreadAssoc(thread);
            }

            List<Tecton> tectonList = tecton.getNeighbourList();
            for (Tecton t : tectonList) {
                tecton.removeNeighbour(t);
                t.removeNeighbour(tecton);
            }
        }
    }

    /**
     * Egy fonal kapcsolatainak megszűntetését végző parancskezelő.
     * <p>
     * Opció megadása nélkül az összes objektum kapcsolatát törli a fonalnak, és az objektumokból is törli a fonal kapcsolatukat.
     * Opció megadása esetén a kijelölt objektummal való kapcsolatát szünteti meg.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Az id hiánya esetén.
     *     <li> unkown id: Ha az id nem található a rendszerben, vagy az 1. Id nem fonalhoz tartozik, vagy a 2. Id Bug vagy NeutralSpore (+leszármazottai) típushoz tartozik.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_remove_F(String[] cmd) {
        if(cmd.length <= 1) {
            addErrorLine("sys_remove_F FAIL -missing parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        String f_name = first_o.getClass().getName();

        if(first_o == null || !f_name.equals("FungalThread")) {
            addErrorLine("sys_remove_F FAIL -unkonwn id");
        }

        FungalThread fungalThread = (FungalThread) first_o;

        if(cmd.length >= 3) {
            Object other = objects.get(cmd[2]);
            if(other == null) {
                addErrorLine("sys_remove_F FAIL -unkonwn id");
                return;
            }

            String other_name = other.getClass().getName();
            if(other_name.contains("Tecton")) {
                Tecton tecton = (Tecton) other;
                if(fungalThread.getTecton() == tecton) {
                    removeFungalThreadAssoc(fungalThread);
                }

            } else if(other_name.contains("FungalThread")) {
                FungalThread otherThread = (FungalThread) other;
                fungalThread.removeConnection(otherThread);
                otherThread.removeConnection(fungalThread);

            } else if(other_name.contains("Fungus")) {
                Fungus fungus = (Fungus) other;
                if(fungus.getThread() == fungalThread) {
                    fungus.setFungalThread(null);
                    fungalThread.setFungus(null);
                }
            } else {
                // Ha a fonalból olyan elemet akarunk kivenni ami nem is lehet benne (Bug, NeutralSpore + leszármazottai)
                addErrorLine("sys_remove_F FAIL -unkonwn id");
                return;
            }
        } else {
            removeFungalThreadAssoc(fungalThread);
        }
    }

    /**
     * Törli a paraméterben kapott fonalnak minden kapcsolatát (mindkét irányú kapcsolat törlése).
     * @param thread A fonal aminek a kapcsolatait törölni kell.
     */
    private static void removeFungalThreadAssoc(FungalThread thread) {
        Tecton tecton = thread.getTecton();
        if(tecton != null) {
            tecton.removeFungalThread(thread);
            thread.setTecton(null);
        }

        //Az eredeti listát kapja meg.
        LinkedHashSet<FungalThread> threadList = thread.getConnections();
        for(FungalThread t : threadList) {
            t.removeConnection(thread);
        }
        threadList.clear();

        Fungus fungus = thread.getFungus();
        if (fungus != null) {
            fungus.setFungalThread(null);
            thread.setFungus(null);
        }
    }

    /**
     * Egy tecton belső állapotainak beállításáért felelős parancskezelő.
     * <p>
     * Az opcióknak megfelelő belső állapotot módosítja a megadott értékre, ha az a szabályos intervballumon belül található.
     * <ul>
     *      <li> -bt [ÉRTÉK]: A tekton kettétörésének ideje (>0)
     *      <li> -mg [ÉRTÉK]: A tekton maximális gombáinak száma (0 vagy 1)
     *      <li> -mf [ÉRTÉK]: A tekton maximális gombafonalainak száma (1-játékosok száma)
     * </ul>
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Az id hiánya esetén.
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> incorrect parameter: Ismeretlen opciók megadása esetén.
     *     <li> invalid attribute value: Ha olyan értéket adnak meg az egyik attribútumnak, ami nem fordulhat elő.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_tecton(String[] cmd) {
        // Ha nincs elég paraméter megadva
        if(cmd.length <= 3) {
            addErrorLine("sys_tecton FAIL -missing parameter");
            return;
        }

        // A megadottt object id alapján lekérjük az objektet
        Object first_o = objects.get(cmd[1]);

        // Ha nem található ilyen névvel objektum
        if(first_o == null ) {
            addErrorLine("sys_tecton FAIL -unkonwn id");
            return;
        }

        // Lekérjük az objektum típusát
        String f_name = first_o.getClass().getName();

        // Ha a típus nem tekton
        if(!f_name.contains("Tecton")) {
            addErrorLine("sys_tecton FAIL -incorrect parameter");
            return;
        }

        Tecton tecton = (Tecton) first_o;
        int cmd_index = 2;
        HashMap<String, Integer> parameters = new HashMap<>();
        for(; cmd_index < cmd.length-1; cmd_index += 2) {
            try {
                if (cmd[cmd_index].equals("-bt") && parameters.get("-bt") == null) {
                    int bt = 0;

                    bt = Integer.parseInt(cmd[cmd_index + 1]);

                    if (bt < 0) {
                        addErrorLine("sys_tecton FAIL -invalid attribute value");
                        return;
                    }
                    parameters.put("-bt", bt);
                } else if (cmd[cmd_index].equals("-mg") && parameters.get("-mg") == null) {
                    int mg = Integer.parseInt(cmd[cmd_index + 1]);
                    if (mg < 0 || mg > 1 || (mg == 0 && tecton.getFungus() != null)) {
                        addErrorLine("sys_tecton FAIL -invalid attribute value");
                        return;
                    }
                    parameters.put("-mg", mg);
                } else if (cmd[cmd_index].equals("-mf") && parameters.get("-mf") == null) {
                    int mf = Integer.parseInt(cmd[cmd_index + 1]);
                    if (mf < 0 || mf > fungusPlayerNumber || mf < tecton.getThreadList().size()) {
                        addErrorLine("sys_tecton FAIL -invalid attribute value");
                        return;
                    }
                    parameters.put("-mf", mf);
                } else {
                    addErrorLine("sys_tecton FAIL -incorrect parameter");
                    return;
                }
            } catch (NumberFormatException e) {
                addErrorLine("sys_tecton FAIL -invalid attribute value");
                return;
            }

        }
        Integer bt = parameters.get("-bt");
        Integer mg = parameters.get("-mg");
        Integer mf = parameters.get("-mf");
        if(bt != null)
            tecton.setBreakTime(bt);
        if(mg != null)
            tecton.setMaxFungus(mg);
        if(mf != null)
            tecton.setMaxFungalThread(mf);
    }
    /**
     * Egy fonal belső állapotainak beállításáért felelős parancskezelő.
     * <p>
     * Az opcióknak megfelelő belső állapotot módosítja a megadott értékre, ha az a szabályos intervballumon belül található.
     * <ul>
     *      <li> -sp [ÉRTÉK]: A spóra tankjában hány spóra van (0-5)
     *      <li> -sr [ÉRTÉK]: A gombatest fentmaradó spóralövéseinek száma (0>)
     *      <li> -st [ÉRTÉK]: A gombatest spóratermelésének ideje (Kör) (0-2)
     *      <li> -ut [ÉRTÉK]: A gombatest fejlődésének ideje (0-5)
     *      <li>  -t [ÉRTÉK]: A gombatest csapatának száma
     *      <li> -sptp [ÉRTÉK]: A gombatest következő spóra kilövés determinisztikus spórája (ha a random működés be van kapcsolva, akkor nem ez az érték kerül használatra) (0-6)
     * </ul>
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Az id hiánya esetén.
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> incorrect parameter: Ismeretlen opciók megadása esetén.
     *     <li> invalid attribute value: Ha olyan értéket adnak meg az egyik attribútumnak, ami nem fordulhat elő.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_fungus(String[] cmd) {
        if(cmd.length <= 3) {
            addErrorLine("sys_fungus FAIL -missing parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        if(first_o == null ) {
            addErrorLine("sys_fungus FAIL -unkonwn id");
            return;
        }

        String f_name = first_o.getClass().getName();
        if(!f_name.contains("Fungus")) {
            addErrorLine("sys_fungus FAIL -incorrect parameter");
            return;
        }

        Fungus fungus = (Fungus) first_o;
        int cmd_index = 2;
        HashMap<String, Integer> parameters = new HashMap<>();
        for(; cmd_index < cmd.length-1; cmd_index += 2) {

            try {
                // Spóratár
                if(cmd[cmd_index].equals("-sp") && parameters.get("-sp") == null) {
                    int sp = Integer.parseInt(cmd[cmd_index+1]);
                    if(sp < 0 || sp > 5) {
                        addErrorLine("sys_fungus -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-sp", sp);

                    //sporeRemainingShots
                } else if (cmd[cmd_index].equals("-sr") && parameters.get("-sr") == null) {
                    int sr = Integer.parseInt(cmd[cmd_index+1]);
                    if (sr < 0) {
                        addErrorLine("sys_fungus -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-sr", sr);

                    //sporeTime
                } else if (cmd[cmd_index].equals("-st") && parameters.get("-st") == null) {
                    int st = Integer.parseInt(cmd[cmd_index+1]);
                    if (st < 0 || st > 2) {
                        addErrorLine("sys_fungus -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-st", st);

                    //upgradeTime
                } else if (cmd[cmd_index].equals("-ut") && parameters.get("-ut") == null) {
                    int ut = Integer.parseInt(cmd[cmd_index+1]);
                    if (ut < 0 || ut > 5) {
                        addErrorLine("sys_fungus -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-ut", ut);

                } else if (cmd[cmd_index].equals("-t") && parameters.get("-t") == null) {
                    int t = Integer.parseInt(cmd[cmd_index+1]);

                    parameters.put("-t", t);


                } else if (cmd[cmd_index].equals("-sptp") && parameters.get("-sptp") == null) {
                    int sptp = Integer.parseInt(cmd[cmd_index+1]);
                    if (sptp < 0 || sptp > 6) {
                        addErrorLine("sys_fungus -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-sptp", sptp);
                }
            } catch (NumberFormatException e) {
                addErrorLine("sys_fungus FAIL -invalid attribute value");
                return;
            }
        }

        Integer sp = parameters.get("-sp");
        Integer sr = parameters.get("-sr");
        Integer st = parameters.get("-st");
        Integer ut = parameters.get("-ut");
        Integer t = parameters.get("-t");
        Integer sptp = parameters.get("-sptp");
        if (sp != null)
            fungus.setSporeTank(sp);
        if (sr != null)
            fungus.setSporeRemainingShots(sr);
        if (st != null)
            fungus.setSporeGeneratingTime(st);
        if(ut != null)
            fungus.setUpgradeTime(ut);
        if(t != null)
            fungus.setTeamID(t);
        if(sptp != null)
            fungus.setSporeType(sptp);
    }

    /**
     * Egy rovar belső állapotainak beállításáért felelős parancskezelő.
     * <p>
     * Az opcióknak megfelelő belső állapotot módosítja a megadott értékre, ha az a szabályos intervballumon belül található.
     * <ul>
     *      <li>  -s [ÉRTÉK]: A rovar lépéseinek száma (speed) (0-2)
     *      <li> -p [ÉRTÉK]: A rovar bénításának ideje (kör) (0-2)
     *      <li> -sit [ÉRTÉK]: A rovar gyorsítottságának ideje (kör) (0-2)
     *      <li> -sdt [ÉRTÉK]: A rovar lassítottságának ideje (kör) (0-2)
     *      <li>  -cit [ÉRTÉK]: A rovar fonalvágás gátlásának ideje (kör) (0-2)
     *      <li> -t [ÉRTÉK]: A rovar csapatának száma
     * </ul>
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Az id hiánya esetén.
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> incorrect parameter: Ismeretlen opciók megadása esetén.
     *     <li> invalid attribute value: Ha olyan értéket adnak meg az egyik attribútumnak, ami nem fordulhat elő.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_bug(String[] cmd) {
        if(cmd.length <= 3) {
            addErrorLine("sys_bug FAIL -missing parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        if(first_o == null ) {
            addErrorLine("sys_bug FAIL -unkonwn id");
            return;
        }

        String f_name = first_o.getClass().getName();
        if(!f_name.contains("Bug")) {
            addErrorLine("sys_bug FAIL -incorrect parameter");
            return;
        }

        Bug bug = (Bug) first_o;
        int cmd_index = 2;
        HashMap<String, Integer> parameters = new HashMap<>();
        for(; cmd_index < cmd.length-1; cmd_index += 2) {

            //speed
            try {
                if(cmd[cmd_index].equals("-s") && parameters.get("-s") == null) {
                    int s = Integer.parseInt(cmd[cmd_index+1]);
                    if(s < 0 || s > 2) {
                        addErrorLine("sys_bug -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-s", s);

                    //paralyzeTime
                } else if (cmd[cmd_index].equals("-p") && parameters.get("-p") == null) {
                    int p = Integer.parseInt(cmd[cmd_index+1]);
                    if (p < 0 || p > 2) {
                        addErrorLine("sys_bug -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-p", p);

                    //sporeTime
                } else if (cmd[cmd_index].equals("-sit") && parameters.get("-sit") == null) {
                    int sit = Integer.parseInt(cmd[cmd_index+1]);
                    if (sit < 0 || sit > 2) {
                        addErrorLine("sys_bug -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-sit", sit);

                    //upgradeTime
                } else if (cmd[cmd_index].equals("-sdt") && parameters.get("-sdt") == null) {
                    int sdt = Integer.parseInt(cmd[cmd_index+1]);
                    if (sdt < 0 || sdt > 2) {
                        addErrorLine("sys_bug -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-sdt", sdt);

                } else if (cmd[cmd_index].equals("-cit") && parameters.get("-cit") == null) {
                    int cit = Integer.parseInt(cmd[cmd_index+1]);
                    if (cit < 0 || cit > 2) {
                        addErrorLine("sys_bug -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-cit", cit);


                } else if (cmd[cmd_index].equals("-t") && parameters.get("-t") == null) {
                    int t = Integer.parseInt(cmd[cmd_index+1]);

                    parameters.put("-t", t);
                } else {
                    addErrorLine("sys_bug FAIL -incorrect parameter");
                    return;
                }
            } catch (NumberFormatException e) {
                addErrorLine("sys_bug FAIL -invalid attribute value");
                return;
            }
        }

        Integer s = parameters.get("-s");
        Integer p = parameters.get("-p");
        Integer sit = parameters.get("-sit");
        Integer sdt = parameters.get("-sdt");
        Integer cit = parameters.get("-cit");
        Integer t = parameters.get("-t");
        if (s != null)
            bug.setSpeed(s);
        if (p != null)
            bug.setParalyzedTime(p);
        if (sit != null)
            bug.setSpeedIncTime(sit);
        if(sdt != null)
            bug.setSpeedDecTime(sdt);
        if(cit != null)
            bug.setCutInhibitTime(cit);
        if(t != null)
            bug.setTeamID(t);

    }

    /**
     * Egy fonal belső állapotainak beállításáért felelős parancskezelő.
     * <p>
     * Az opcióknak megfelelő belső állapotot módosítja a megadott értékre, ha az a szabályos intervballumon belül található.
     * <ul>
     *      <li>  -tdt [ÉRTÉK]: A tekton fonalfelszívásának ideje (kör) (0-3)
     *      <li>  -ft [ÉRTÉK]: Annak az értéke, hogy a gombafonal mennyi ideig lehet még életben gombatest kapcsolat nélkül (0-3)
     *      <li> -gt [ÉRTÉK]: A gombafonal kinövésének ideje (kör) (0-3)
     *      <li> -t [ÉRTÉK]: A gombafonal csapatának száma
     * </ul>
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Az id hiánya esetén.
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> incorrect parameter: Ismeretlen opciók megadása esetén.
     *     <li> invalid attribute value: Ha olyan értéket adnak meg az egyik attribútumnak, ami nem fordulhat elő.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_fungal(String[] cmd) {
        if (cmd.length <= 3) {
            addErrorLine("sys_fungal FAIL -missing parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        if (first_o == null) {
            addErrorLine("sys_fungal FAIL -unkonwn id");
            return;
        }

        String f_name = first_o.getClass().getName();
        if (!f_name.contains("FungalThread")) {
            addErrorLine("sys_fungal FAIL -incorrect parameter");
            return;
        }

        FungalThread thread = (FungalThread) first_o;
        int cmd_index = 2;
        HashMap<String, Integer> parameters = new HashMap<>();
        for (; cmd_index < cmd.length - 1; cmd_index += 2) {

            try {
                //TectonDissolvingTime
                if (cmd[cmd_index].equals("-tdt") && parameters.get("-tdt") == null) {
                    int tdt = Integer.parseInt(cmd[cmd_index + 1]);
                    if (tdt < 0 || tdt > 3) {
                        addErrorLine("sys_fungal -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-tdt", tdt);

                    //fungusFreeTime
                } else if (cmd[cmd_index].equals("-ft") && parameters.get("-ft") == null) {
                    int ft = Integer.parseInt(cmd[cmd_index + 1]);
                    if (ft < 0 || ft > 3) {
                        addErrorLine("sys_fungal -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-ft", ft);

                    //growTime
                } else if (cmd[cmd_index].equals("-gt") && parameters.get("-gt") == null) {
                    int gt = Integer.parseInt(cmd[cmd_index + 1]);
                    if (gt < 0 || gt > 3) {
                        addErrorLine("sys_fungal -FAIL invalid attribute value");
                        return;
                    }
                    parameters.put("-gt", gt);

                    //upgradeTime
                } else if (cmd[cmd_index].equals("-t") && parameters.get("-t") == null) {
                    int t = Integer.parseInt(cmd[cmd_index + 1]);

                    parameters.put("-t", t);
                } else {
                    addErrorLine("sys_fungal FAIL -incorrect parameter");
                    return;
                }
            } catch (NumberFormatException e) {
                addErrorLine("sys_fungal FAIL -invalid attribute value");
                return;
            }
        }

        Integer tdt = parameters.get("-tdt");
        Integer ft = parameters.get("-ft");
        Integer gt = parameters.get("-gt");
        Integer t = parameters.get("-t");
        if (tdt != null)
            thread.setTectonDissolvingTime(tdt);
        if(ft != null)
            thread.setFungusFreeTime(ft);
        if(gt != null)
            thread.setGrowTime(gt);
        if(t != null)
            thread.setTeamID(t);
    }
    /**
     * Egy fonal belső állapotainak beállításáért felelős parancskezelő.
     * <p>
     * A megadott értékre állítja be a spóra nutrient értékét, ha az szabályos intervallumon (1-5) belül van.
     *
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Az id hiánya esetén.
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> invalid attribute value: Ha olyan értéket adnak meg az egyik attribútumnak, ami nem fordulhat elő.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_spore(String[] cmd) {
        if (cmd.length <= 2) {
            addErrorLine("sys_spore FAIL -missing parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        if (first_o == null) {
            addErrorLine("sys_spore FAIL -unkonwn id");
            return;
        }

        String f_name = first_o.getClass().getName();
        if (!f_name.contains("Spore")) {
            addErrorLine("sys_spore FAIL -incorrect parameter");
            return;
        }

        NeutralSpore spore = (NeutralSpore) first_o;
        try {
            Integer n = Integer.parseInt(cmd[2]);
            if (n < 1 || n > 5) {
                addErrorLine("sys_spore -FAIL invalid attribute value");
                return;
            }
            spore.setNutrient(n);
        } catch (NumberFormatException e) {
            addErrorLine("sys_spore -FAIL invalid attribute value");
        }
    }

    /**
     * Az idő múlását jelző parancskezelő.
     * <p>
     * Opció megadása nélkül minden objektumnak aminek lehetséges jelzi az idő múlását.
     * Opció megadása esetén csak az cmd 2. értékének megfelelő Id-val rendelkező objektumnak jelzi az idő múlását.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id nem található a rendszerben.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_update(String[] cmd) {
        if (cmd.length == 1) {
            endTurn();
        } else {
            Object first_o = objects.get(cmd[1]);
            if (first_o == null) {
                addErrorLine("sys_update FAIL -unkonwn id");
                return;
            }
            String f_name = first_o.getClass().getName();
            if(f_name.contains("FungalThread")) {
                FungalThread thread = (FungalThread) first_o;
                thread.update();
            } else if(f_name.contains("Tecton")) {
                Tecton tecton = (Tecton) first_o;
                tecton.update();
            } else if(f_name.contains("Bug")) {
                Bug bug = (Bug) first_o;
                bug.update();
            } else if(f_name.contains("Fungus")) {
                Fungus fungus = (Fungus) first_o;
                fungus.update();
            } else {
                addErrorLine("sys_update FAIL -unkonwn id");
            }
        }
    }

    /**
     * Az objektumok státuszát megjelenítő és elmentő parancskezelő.
     * <p>
     * Opció megadása nélkül minden objektumnak a státuszát megjeleníti és elmenti a loggerben.
     * Opció megadása esetén csak az cmd opcióinak megfelelő objektumnak jelzi az idő múlását.
     * <p> Opciók:
     * <ul>
     *     <li>-n [objekt id]: Csak az objekt id-val rendelkező objektum státuszát írja ki. Nem használható más opcióval együtt.
     *     <li>-t: Tecton
     *     <li>-tdt: ThreadDissolvingTecton
     *     <li>-tst: ThreadSavingTecton
     *     <li>-f: FungalThread
     *     <li>-g: Fungus
     *     <li>-b: Bug
     *     <li>-ns: NeutralSpore
     *     <li>-sps: SpeedSpore
     *     <li>-sls: SlowSpore
     *     <li>-ps: ParalyzeSpore
     *     <li>-cs: CloneSpore
     *     <li>-cis: CuttingInhibitorSpore
     * </ul>
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> incorrect parameter: Ismeretlen opciók megadása esetén.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_status(String[] cmd) {

        List<String> statusList = new ArrayList<>();
        if(cmd.length <= 1) {
            for(String key : objects.keySet()) {
                Object obj = objects.get(key);
                List<String> resStatus = getObjectStatus(key, obj);
                if (resStatus != null) {
                    statusList.addAll(resStatus);
                }
            }
        } else {
            if(cmd[1].equals("-n")) {
                if(cmd.length < 3) {
                    addErrorLine("sys_status -unkown id");
                    return;
                }

                Object obj = objects.get(cmd[2]);
                if(obj == null) {
                    addErrorLine("sys_status -unkonwn id");
                    return;
                }
                List<String> resStatus = getObjectStatus(cmd[2], obj);
                if(resStatus != null) {
                    statusList.addAll(resStatus);
                }

            } else {
                Set<String> statusTypes = new HashSet<>();
                for(int i = 1; i < cmd.length; i++) {
                    if(cmd[i].equals("-t")) {
                        statusTypes.add("Tecton");
                    } else if(cmd[i].equals("-tst")) {
                        statusTypes.add("ThreadSavingTecton");
                    } else if(cmd[i].equals("-tdt")) {
                        statusTypes.add("ThreadDissolvingTecton");
                    } else if(cmd[i].equals("-f")) {
                        statusTypes.add("FungalThread");
                    } else if(cmd[i].equals("-g")) {
                        statusTypes.add("Fungus");
                    } else if(cmd[i].equals("-b")) {
                        statusTypes.add("Bug");
                    } else if(cmd[i].equals("-ns")) {
                        statusTypes.add("NeutralSpore");
                    } else if(cmd[i].equals("-sps")) {
                        statusTypes.add("SpeedSpore");
                    } else if(cmd[i].equals("-sls")) {
                        statusTypes.add("SlowSpore");
                    } else if(cmd[i].equals("-ps")) {
                        statusTypes.add("ParalyzeSpore");
                    } else if(cmd[i].equals("-cs")) {
                        statusTypes.add("CloneSpore");
                    } else if(cmd[i].equals("-cis")) {
                        statusTypes.add("CuttingInhibitorSpore");
                    } else {
                        addErrorLine("sys_status -incorrect parameter");
                        return;
                    }
                }

                for(String key : objects.keySet()) {
                    Object obj = objects.get(key);
                    String objClass_name = obj.getClass().getName();
                    if(statusTypes.contains(objClass_name)) {
                        List<String> resStatus = getObjectStatus(key, obj);
                        if(resStatus != null) {
                            statusList.addAll(resStatus);
                        }
                    }
                }
            }
        }
        if(statusList.size() > 0) {
            for (String s : statusList) {
                System.out.println(s);
                logger.add(s);
            }
        }
    }

    /**
     * A paraméterben kapott Objectumnak, a típusának megfelelően hívja meg a státuszt lekérdező függvényt.
     * @param name A paraméterben kapott objektum neve (Id-ja).
     * @param obj Az objektum aminek a státuszát le kell kérdezni.
     * @return Stringekből álló lista, ahol egy listaelem megfelel a státusz egy sorának.
     */
    private static List<String> getObjectStatus(String name, Object obj) {
        String objClass_name = obj.getClass().getName();
        if (objClass_name.equals("Tecton")) {
            Tecton tecton = (Tecton) obj;
            return(getTectonStatus("Tecton", name, tecton));
        } else if (objClass_name.equals("ThreadDissolvingTecton")) {
            ThreadDissolvingTecton tecton = (ThreadDissolvingTecton) obj;
            return(getTectonStatus("ThreadDissolvingTecton", name, tecton));
        } else if(objClass_name.equals("ThreadSavingTecton")) {
            Tecton tecton = (Tecton) obj;
            return(getTectonStatus("ThreadSavingTecton", name, tecton));
        } else if(objClass_name.equals("Bug")) {
            Bug bug = (Bug) obj;
            return(getBugStatus("Bug", name, bug));
        } else if(objClass_name.equals("FungalThread")) {
            FungalThread fthread = (FungalThread) obj;
            return(getFungalThreadStatus("FungalThread", name, fthread));
        } else if(objClass_name.equals("Fungus")) {
            Fungus fungus = (Fungus) obj;
            return(getFungusStatus("Fungus", name, fungus));
        } else if(objClass_name.equals("NeutralSpore")) {
            NeutralSpore spore = (NeutralSpore) obj;
            return(getSporeStatus("NeutralSpore", name, spore));
        } else if(objClass_name.equals("SpeedSpore")) {
            NeutralSpore spore = (NeutralSpore) obj;
            return(getSporeStatus("SpeedSpore", name, spore));
        } else if(objClass_name.equals("SlowSpore")) {
            NeutralSpore spore = (NeutralSpore) obj;
            return(getSporeStatus("SlowSpore", name, spore));
        } else if(objClass_name.equals("ParalyzeSpore")) {
            NeutralSpore spore = (NeutralSpore) obj;
            return(getSporeStatus("ParalyzeSpore", name, spore));
        } else if(objClass_name.equals("CloneSpore")) {
            NeutralSpore spore = (NeutralSpore) obj;
            return(getSporeStatus("CloneSpore", name, spore));
        } else if(objClass_name.equals("CuttingInhibitorSpore")) {
            NeutralSpore spore = (NeutralSpore) obj;
            return(getSporeStatus("CuttingInhibitorSpore", name, spore));
        }
        return null;
    }

    /**
     * Egy tecton státuszát ekészítő függvény.
     * @param class_name A tecton pontos típusa (Tecton vagy leszármazottai)
     * @param o_name A tecton neve (Id-ja)
     * @param tecton A tecton objetum amiről a státusz készül
     * @return Stringekből álló lista, ahol egy listaelem megfelel a státusz egy sorának.
     */
    private static List<String> getTectonStatus(String class_name, String o_name, Tecton tecton) {
        List<String> t_status = new ArrayList<>();
        List<String> tmpList = new ArrayList<>();

        StringBuilder sb = new StringBuilder();
        sb.append(class_name).append(", ").append(o_name).append(", maxFungalThread, ").append(tecton.getMaxFungalThread()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", breakTime, ").append(tecton.getBreakTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", maxFungus, ").append(tecton.getMaxFungus()).append("\n");

        for(int i = 0; i < tecton.getBugList().size(); i++) {
            tmpList.add(getObjectName(tecton.getBugList().get(i)));
        }
        sb.append(class_name).append(", ").append(o_name).append(", bugList, ").append(tmpList).append("\n");
        tmpList.clear();

        sb.append(class_name).append(", ").append(o_name).append(", fungus, ").append(getObjectName(tecton.getFungus())).append("\n");

        for(int i = 0; i < tecton.getThreadList().size(); i++) {
            tmpList.add(getObjectName(tecton.getThreadList().get(i)));
        }
        sb.append(class_name).append(", ").append(o_name).append(", fungalThreadList, ").append(tmpList).append("\n");
        tmpList.clear();

        for(int i = 0; i < tecton.getSporeList().size(); i++) {
            tmpList.add(getObjectName(tecton.getSporeList().get(i)));
        }
        sb.append(class_name).append(", ").append(o_name).append(", sporeList, ").append(tmpList).append("\n");
        tmpList.clear();

        for(int i = 0; i < tecton.getNeighbourList().size(); i++) {
            tmpList.add(getObjectName(tecton.getNeighbourList().get(i)));
        }
        sb.append(class_name).append(", ").append(o_name).append(", neighbours, ").append(tmpList).append("\n");
        sb.append("#");

        t_status.add(sb.toString());
        return t_status;
    }

    /**
     * Egy fungus státuszát ekészítő függvény.
     * @param class_name A fungus osztály neve
     * @param o_name A fungus neve (Id-ja)
     * @param fungus A fungus objektum amiről a státusz készül
     * @return Stringekből álló lista, ahol egy listaelem megfelel a státusz egy sorának.
     */
    private static List<String> getFungusStatus(String class_name, String o_name, Fungus fungus) {
        List<String> tmpList = new ArrayList<>();
        StringBuilder sb = new StringBuilder();

        sb.append(class_name).append(", ").append(o_name).append(", sporeTank, ").append(fungus.getSporeTank()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", sporeRemainingShots, ").append(fungus.getSporeRemainingShots()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", sporeGeneratingTime, ").append(fungus.getSporeGeneratingTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", upgradeTime, ").append(fungus.getUpgradeTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", sporeType, ").append(fungus.getSporeType()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", teamId, ").append(fungus.getTeamID()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", tecton, ").append(getObjectName(fungus.getTecton())).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", fungalThread, ").append(getObjectName(fungus.getThread())).append("\n");
        sb.append("#");

        tmpList.add(sb.toString());
        return tmpList;
    }

    /**
     * Egy fonal státuszát ekészítő függvény.
     * @param class_name A fonal osztály neve
     * @param o_name A fonal neve (Id-ja)
     * @param fthread A fonal objektum amiről a státusz készül
     * @return Stringekből álló lista, ahol egy listaelem megfelel a státusz egy sorának.
     */
    private static List<String> getFungalThreadStatus(String class_name, String o_name, FungalThread fthread) {
        List<String> tmpList = new ArrayList<>();
        StringBuilder sb = new StringBuilder();

        List<String> conList = new ArrayList<>();
        List<FungalThread> connections = fthread.getConnections().stream().toList();
        for(FungalThread connection : connections) {
            conList.add(getObjectName(connection));
        }

        sb.append(class_name).append(", ").append(o_name).append(", fungusFreeTime, ").append(fthread.getFungusFreeTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", growTime, ").append(fthread.getGrowTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", tectonDissolvingTime, ").append(fthread.getTectonDissolvingTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", teamId, ").append(fthread.getTeamID()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", tecton, ").append(getObjectName(fthread.getTecton())).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", connections, ").append(conList).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", fungus, ").append(getObjectName(fthread.getFungus())).append("\n");
        sb.append("#");
        tmpList.add(sb.toString());
        return tmpList;
    }

    /**
     * Egy spóra státuszát ekészítő függvény.
     * @param class_name A spóra osztály neve
     * @param o_name A spóra neve (Id-ja)
     * @param spore A spóra objektum amiről a státusz készül
     * @return Stringekből álló lista, ahol egy listaelem megfelel a státusz egy sorának.
     */
    private static List<String> getSporeStatus(String class_name, String o_name, NeutralSpore spore) {
        List<String> tmpList = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        sb.append(class_name).append(", ").append(o_name).append(", nutrient, ").append(spore.getNutrient()).append("\n");
        sb.append("#");
        tmpList.add(sb.toString());
        return tmpList;
    }

    /**
     * Egy rovar státuszát ekészítő függvény.
     * @param class_name A rovar osztály neve
     * @param o_name A rovar neve (Id-ja)
     * @param bug A rovar objektum amiről a státusz készül
     * @return Stringekből álló lista, ahol egy listaelem megfelel a státusz egy sorának.
     */
    private static List<String> getBugStatus(String class_name, String o_name, Bug bug) {
        List<String> tmpList = new ArrayList<>();
        StringBuilder sb = new StringBuilder();

        sb.append(class_name).append(", ").append(o_name).append(", speed, ").append(bug.getSpeed()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", paralyzedTime, ").append(bug.getParalyzedTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", speedIncTime, ").append(bug.getSpeedIncTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", speedDecTime, ").append(bug.getSpeedDecTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", cutInhibitTime, ").append(bug.getCutInhibitTime()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", teamId, ").append(bug.getTeamID()).append("\n");
        sb.append(class_name).append(", ").append(o_name).append(", tecton, ").append(getObjectName(bug.getTecton())).append("\n");
        sb.append("#");

        tmpList.add(sb.toString());
        return tmpList;
    }

    /**
     * A rendszerben megtalálható objektumok típusát és nevét listázó parancskezelő.
     * <p>
     *  Opciók megadása nélkül minden elem típusát és nevét listázza a rendszerhez történő hozzáadás sorrendjében.
     *  Opció megadása esetén a cmd 2. értékének megfelelő típusú objektumokat jeleníti csak meg.
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_list(String[] cmd) {
        if(cmd.length == 1){
            for(String key : objects.keySet()) {
                System.out.println(objects.get(key).getClass().getName() + " " +  key);
            }
        } else {
            String type = null;
            if(cmd[1].equals("-t")) {
                type = "Tecton";
            } else if(cmd[1].equals("-tst")) {
                type = "ThreadSavingTecton";
            } else if(cmd[1].equals("-tdt")) {
                type = "ThreadDissolvingTecton";
            } else if(cmd[1].equals("-f")) {
                type = "FungalThread";
            } else if(cmd[1].equals("-g")) {
                type = ("Fungus");
            } else if(cmd[1].equals("-b")) {
                type = ("Bug");
            } else if(cmd[1].equals("-ns")) {
                type = ("NeutralSpore");
            } else if(cmd[1].equals("-sps")) {
                type = ("SpeedSpore");
            } else if(cmd[1].equals("-sls")) {
                type = ("SlowSpore");
            } else if(cmd[1].equals("-ps")) {
                type = ("ParalyzeSpore");
            } else if(cmd[1].equals("-cs")) {
                type = ("CloneSpore");
            } else if(cmd[1].equals("-cis")) {
                type = ("CuttingInhibitorSpore");
            } else {
                addErrorLine("sys_status -incorrect parameter");
                return;
            }
            for(String key : objects.keySet()) {
                String objClassName = objects.get(key).getClass().getName();
                if(objClassName.equals(type)) {
                    System.out.println(objClassName + " " +  key);
                }
            }
        }

    }

    /**
     * A szkripteket betöltő és futtató parancskezelő.
     * <p>
     *  A megadott elérési útnak megfelelő fájl megpróbálja megnyitni és a benne található szkriptet beolvassa és futtatja.
     *  A meghívása több hibaüzenettel is járhat mivel a futtatott szkriptben található parancsok hibaüzenetei is megjelennek a futása alatt.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Ha nincs Path megadva.
     *     <li> file not found: Ha nem található a keresett fájl.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_load(String[] cmd) {
        if(cmd.length >= 2){
            try {
                FileInputStream fis = new FileInputStream(cmd[1]);
                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String line = null;
                while((line = br.readLine()) != null) {
                    String[] tmp = line.split(" ");
                    commandProcess(tmp);
                }

                br.close();
            } catch (FileNotFoundException e) {
                addErrorLine("sys_load FAIL -file not found");

            } catch (IOException ie) {
                addErrorLine("sys_load FAIL -file not found");
            }
        }
    }

    /**
     * A rendszerben elérhető parancsokat listázza.
     */
    private static void sys_help() {
        System.out.println("sys_create");
        System.out.println("sys_add_T");
        System.out.println("sys_add_F");
        System.out.println("sys_delete");
        System.out.println("sys_remove_T");
        System.out.println("sys_remove_F");
        System.out.println("sys_tecton");
        System.out.println("sys_fungus");
        System.out.println("sys_bug");
        System.out.println("sys_fungal");
        System.out.println("sys_spore");
        System.out.println("sys_update");
        System.out.println("sys_status");
        System.out.println("sys_list");
        System.out.println("sys_load");
        System.out.println("sys_help");
        System.out.println("sys_randgen");
        System.out.println("sys_exit");
        System.out.println("sys_startGame");
        System.out.println("sys_gameOver");
        System.out.println("sys_log");
        System.out.println("move");
        System.out.println("cut");
        System.out.println("eat");
        System.out.println("growThread");
        System.out.println("growFungus");
        System.out.println("shootSpore");
        System.out.println("dissolveBug");
    }

    /**
     * A rendszer logikai random értékét állítja át az ellenkező értékre.
     */
    private static void sys_randgen() {
        if(random)
            random = false;
        else
            random = true;
    }

    /**
     * A játék inicializálását végző parancskezelő.
     * <p>
     *  A cmd 2. értékében megadott számú játékosra inicializálja a játékot. A játékosok száma csak 2-3 értéket vehetnek fel.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Ha érték megadva.
     *     <li> incorrect parameter:Ha szabálytalan érték van megadva.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_startGame(String[] cmd) {
        if(cmd.length == 1) {
            addErrorLine("sys_start FAIL -missing parameter");
        } else {
            int playerNum = 0;
            if(cmd[1].equals("2")) {
                playerNum = 2;
            } else if (cmd[1].equals("3")) {
                playerNum = 3;
            } else {
                addErrorLine("sys_start FAIL -incorrect parameter");
                return;
            }
            sys_delete(new String[] {});
            random = true;
            logger.clear();
            bugPlayers.clear();
            fungusPlayers.clear();
            fungusPlayerNumber = playerNum;
            bugPlayerNumber = playerNum;
            initializePlayers();
        }
    }

    /**
     * Megjeleníti a győztes játékosokat a pontszámoknak és a játékosok számának megfelelően.
     * Nem állítja le a játékot csak a győztes hirdetésért felel. Döntetlen esetén a győzteseket vesszővel elválasztva jeleníti meg egy sorban.
     */
    private static void sys_gameOver() {
        List<String> tmpList = new ArrayList<>();
        tmpList.add("Winners");
        int maxFPoints = 0;
        int maxBPoints = 0;
        for(Integer i : fungusPlayers.keySet()) {
            int p = fungusPlayers.get(i);
            if(p > maxFPoints)
                maxFPoints = p;
        }
        for(Integer i : bugPlayers.keySet()) {
            int p = bugPlayers.get(i);
            if(p > maxBPoints)
                maxBPoints = p;
        }
        StringBuilder sb = new StringBuilder();

        boolean first = true;
        sb.append("FungusPlayer: ");
        for(Integer i : fungusPlayers.keySet()) {
            if(fungusPlayers.get(i) == maxFPoints) {
                if(first) {
                    sb.append("team_").append(i);
                    first = false;
                } else {
                    sb.append(", ").append("team_").append(i);
                }
            }
        }
        tmpList.add(sb.toString());
        sb.setLength(0);

        first = true;
        sb.append("BugPlayer: ");
        for(Integer i : bugPlayers.keySet()) {
            if(bugPlayers.get(i) == maxBPoints) {
                if(first) {
                    sb.append("team_").append(i);
                    first = false;
                } else {
                    sb.append(", ").append("team_").append(i);
                }
            }
        }
        tmpList.add(sb.toString());
        logger.addAll(tmpList);
        for(String s : tmpList) {
            System.out.println(s);
        }
    }

    /**
     * A logger tartalmának kezelését végző parancskezelő.
     * <p>
     *  Amennyiben nincs opció megadva úgy megjeleníti a tartalmát amiben,
     *  ha nincs státusz üzenet, akkor minden elem státuszát megjeleníti a tartalmának megjelenítése után.
     *  Ha opcióként -d van megadva, akkor törli a logger tartalmát. Ha opcióként -s [Path] van megadva, akkor a
     *  konzolos megjelenítés helyetta Path-nak megfelelő fájlba próbálja írni a tartalmát, ugyanolyan működéssel,
     *  mint a konzolra tenné.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> missing parameter: Ha nincs Path megadva a -s opció esetében.
     *     <li> cannot write to file: Ha nem lehetséges a megadott elérési útvonalon megadott fájlba történő írás.
     *     <li> incorrect parameter: Ha nem létető opció van megadva.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void sys_log(String[] cmd) {
        if(cmd.length == 1) {
            boolean hasStatus = false;
            for(String log : logger) {
                System.out.println(log);
                if (log.contains("#")) {
                    hasStatus = true;
                    break;
                }
            }
            if(!hasStatus) {
                sys_status(new String[]{});
            }

        } else {
            if(cmd[1].equals("-s")) {
                if(cmd.length == 2) {
                    addErrorLine("sys_log FAIL -missing parameter");
                    return;
                }

                try {
                    boolean hasStatus = false;
                    for(String log : logger) {
                        if (log.contains("#")) {
                            hasStatus = true;
                            break;
                        }
                    }
                    if(!hasStatus) {
                        sys_status(new String[]{});
                    }
                    File f = new File(cmd[2]);
                    FileWriter fw = new FileWriter(f);
                    PrintWriter pw = new PrintWriter(fw);
                    for(String line : logger) {
                        pw.println(line);
                    }

                    pw.close();
                } catch (IOException e) {
                    addErrorLine("sys_log FAIL -cannot write to file");
                }
            } else if(cmd[1].equals("-d")) {
                logger.clear();
            } else {
                addErrorLine("sys_log FAIL -incorrect parameter");
            }
        }

    }

    /**
     * A rovar mozgatását végző parancskezelő.
     * <p>
     *  A rovar id-nak megfelelő rovarnak kiadja a mozgásra utasítást, a tekton id-nak megfelelő tektonra.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id-k közül valamelyik nem található a rendszerben.
     *     <li> incorrect parameter: Ha nincs megfelelő számú id megadva.
     *     <li> bug is paralyzed: Ha a rovar bénított állapota miatt nem tud mozogni.
     *     <li> bug is slow: Ha a rovar lassított állapota miatt nem tud mozogni.
     *     <li> tecton too far: Ha a rovar sebessége 1, akkor a tekton nem szomszédos a rovar tektonjával. Ha a rovar sebessége 2, akkor a tekton nem található a szomszédok szomszédjai között sem.
     *     <li> cannot find thread: Ha a célnak megadott tekton elérhető távolságon belül van, de nem vezet rá már kinőtt állapotban levő fonal. Ha csak növekvő állapotban levő fonal található meg, akkor is ezt a hibát dobja.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void move(String[] cmd) {
        if(cmd.length <= 2) {
            addErrorLine("move FAIL -incorrect parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        Object other_o = objects.get(cmd[2]);

        if(first_o == null || other_o == null) {
            addErrorLine("move FAIL -unkonwn id");
            return;
        }

        String f_name = first_o.getClass().getName();
        String other_name = other_o.getClass().getName();

        boolean didMove = false;
        if(f_name.equals("Bug") && other_name.contains("Tecton")) {
            Bug bug = (Bug) first_o;
            Tecton tecton = (Tecton) other_o;
            didMove = bug.moveTo(tecton);
            if(!didMove) {
                if (errorLog.size() > 0) {
                    if(errorLog.contains("-cannot find thread"))
                        addErrorLine("move FAIL " + ("-cannot find thread"));
                    else
                        addErrorLine("move FAIL " + errorLog.get(0));
                    errorLog.clear();
                } else {
                    addErrorLine("move FAIL -move inner error");
                }
                return;
            }
        } else {
            addErrorLine("move FAIL -unkonwn id");
        }
    }

    /**
     * A rovar fonal vágás utasítását végző parancskezelő.
     * <p>
     *  A rovar id-nak megfelelő rovarnak adja ki a fonalvágás parancsot, a rovar tektonja és a paraméterben kapott tekton id-jú tekton közé.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id-k közül valamelyik nem található a rendszerben.
     *     <li> incorrect parameter: Ha nincs megfelelő számú id megadva.
     *     <li> tecton is not neighbour: Ha a megadott tekton nem is szomszédja a rovar tektonjának.
     *     <li> cannot find thread: Ha nem található az adott tektonra vezető, nem növekvő, fonal.
     *     <li> bug is paralyzed: Ha a rovar bénított állapotban van, és ezért nem tud fonalat vágni.
     *     <li> bug is cut inhibited: Ha a rovar fonal vágása gátolva van.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void cut(String[] cmd) {
        if(cmd.length <= 2) {
            addErrorLine("cut FAIL -incorrect parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        Object other_o = objects.get(cmd[2]);

        if(first_o == null || other_o == null) {
            addErrorLine("cut FAIL -unkonwn id");
            return;
        }

        String f_name = first_o.getClass().getName();
        String other_name = other_o.getClass().getName();

        boolean didCut = false;
        if(f_name.equals("Bug") && other_name.contains("Tecton")) {
            Bug bug = (Bug) first_o;
            Tecton tecton = (Tecton) other_o;
            didCut = bug.cutThreadAtGap(tecton);
            if(!didCut) {
                if (errorLog.size() > 0) {
                    addErrorLine("cut FAIL " + errorLog.get(0));
                    errorLog.clear();
                } else {
                    addErrorLine("cut FAIL -cut inner error");
                }
                return;
            }
        } else {
            addErrorLine("cut FAIL -unkonwn id");
        }
    }

    /**
     * A rovar spóra evés utasítását végző parancskezelő.
     * <p>
     *  A rovar id-nak megfelelő rovart spóra evésre utasítja.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> incorrect parameter: Ha nincs megfelelő számú id megadva.
     *     <li> bug is paralyzed: Ha a rovar bénított állapotban van, és ezért nem tud spórát enni.
     *     <li> no spore to eat: Ha nem található spóra a tektonon.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void eat(String[] cmd) {
        if(cmd.length <= 1) {
            addErrorLine("eat FAIL -incorrect parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        if(first_o == null) {
            addErrorLine("eat FAIL -unkonwn id");
            return;
        }

        String f_name = first_o.getClass().getName();
        boolean didEat = false;
        if(f_name.equals("Bug")) {
            Bug bug = (Bug) first_o;
            didEat = bug.eatSpore();
            if(!didEat) {
                if (errorLog.size() > 0) {
                    addErrorLine("eat FAIL " + errorLog.get(0));
                    errorLog.clear();
                } else {
                    addErrorLine("eat FAIL -eat inner error");
                }
            }
        } else {
            addErrorLine("eat FAIL -incorrect parameter");
        }

    }

    /**
     * A fonal növesztés utasítását végző parancskezelő.
     * <p>
     *  A cmd[1]-ben levő opciónak megfelelően fonalból (-th), vagy gombatestből (-f) próbálkozik fonalat növeszteni.
     *  A fonalból történő növesztés esetén a cmd[2] érték a (Thread Id) a fonal növesztésre utasított fonal,
     *  a cmd[3] érték a (Tekton Id) a cél tektont jelöli.
     *  A gombatestből történő növesztés esetén a cmd[2] a (Fungus Id) fonal növesztésre utasított gombatest.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id-k közül valamelyik nem található a rendszerben.
     *     <li> incorrect parameter: Ha hibásan van paraméterezve a parancs.
     *     <li> max thread reached: Ha már nem fér a tektonra több fonal.
     *     <li> thread already present: Ha már van fonal növesztve arra a tektonra.
     *     <li> thread is still growing: Ha olyan fonalon hívják meg, ami még növekvő állapotban van.
     *     <li> tecton is not neighbour: Ha a fonal növeszt fonalat és olyan cél tektont kap, ami nem szomszédos a saját tektonjával.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void growThread(String[] cmd) {
        if(cmd.length <= 2) {
            addErrorLine("growThread FAIL -incorrect parameter");
            return;
        }

        if(cmd[1].equals("-th")) {
            if(cmd.length == 3) {
                addErrorLine("growThread FAIL -incorrect parameter");
                return;
            }

            Object first_o = objects.get(cmd[2]);
            Object other_o = objects.get(cmd[3]);
            if(first_o == null || other_o == null) {
                addErrorLine("growThread FAIL -unkonwn id");
                return;
            }

            String f_name = first_o.getClass().getName();
            String other_name = other_o.getClass().getName();
            if(f_name.equals("FungalThread") && other_name.contains("Tecton")) {
                FungalThread thread = (FungalThread) first_o;
                Tecton tecton = (Tecton) other_o;
                boolean didGrow = thread.growFungalThread(tecton);
                if(!didGrow) {
                    if (errorLog.size() > 0) {
                        addErrorLine("growThread FAIL " + errorLog.get(0));
                        errorLog.clear();
                    } else {
                        addErrorLine("growThread FAIL -growThread inner error");
                    }
                }
            } else {
                addErrorLine("growThread FAIL -unkonwn id");
            }

        } else if(cmd[1].equals("-f")) {
            Object first_o = objects.get(cmd[2]);
            if(first_o == null) {
                addErrorLine("growThread FAIL -unkonwn id");
                return;
            }

            String f_name = first_o.getClass().getName();
            if(f_name.equals("Fungus")) {
                Fungus fungus = (Fungus) first_o;
                boolean didGrow = fungus.createFungalThread();
                if(!didGrow) {
                    if (errorLog.size() > 0) {
                        addErrorLine("growThread FAIL " + errorLog.get(0));
                        errorLog.clear();
                    } else {
                        addErrorLine("growThread FAIL -growThread inner error");
                    }
                }
            } else {
                addErrorLine("growThread FAIL -unkonwn id");
            }

        } else {
            addErrorLine("growThread FAIL -incorrect parameter");
        }
    }

    /**
     * A gombatest növesztés utasítását végző parancskezelő.
     * <p>
     *  A cmd[1]-ben levő Thread Id-nak megfelelő fonalat utasítja a gombatest növesztésre.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> incorrect parameter: Ha hibásan van paraméterezve a parancs.
     *     <li> maxFungus reached: Ha már nem fér több gombatest a tektonra.
     *     <li> not enough spores: Ha nincs elegendő spóra a növesztésre.
     *     <li> thread is still growing: Ha olyan fonalon hívják meg, ami még növekvő állapotban van.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void growFungus(String[] cmd) {
        if(cmd.length <= 1) {
            addErrorLine("growFungus FAIL -incorrect parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        if(first_o == null) {
            addErrorLine("growFungus FAIL -unkonwn id");
        }
        String f_name = first_o.getClass().getName();
        if(f_name.equals("FungalThread")) {
            FungalThread fungalThread = (FungalThread) first_o;
            boolean didGrow = fungalThread.growFungus();
            if(!didGrow) {
                if (errorLog.size() > 0) {
                    addErrorLine("growFungus FAIL " + errorLog.get(0));
                    errorLog.clear();
                } else {
                    addErrorLine("growFungus FAIL -growFungus inner error");
                }
            }
        } else {
            addErrorLine("growFungus FAIL -unkonwn id");
        }
    }

    /**
     * A gombatest spóra lövés utasítását végző parancskezelő.
     * <p>
     *  A cmd[1]-ben levő Fungus Id-nak megfelelő gombatestet utasítja
     *  a cmd[2]-ben levő Tekton Id-nak megfelelő tektonra történő spóralövésre.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id-k közül valamelyik nem található a rendszerben.
     *     <li> incorrect parameter: Ha hibásan van paraméterezve a parancs.
     *     <li> tekton too far: Nem fejlett gombatest esetén a tekton nem szomszédos a gombatest tektonjával.
     *     Fejlett gombatest esetén a tekton nem található a szomszédok és azok szomszédai között sem.
     *     <li> not enough spore: Ha nincs elegendő spóra a kilövéshez.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void shootSpore(String[] cmd) {
        if(cmd.length <= 2) {
            addErrorLine("shootSpore FAIL -incorrect parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        Object other_o = objects.get(cmd[2]);

        if(first_o == null || other_o == null) {
            addErrorLine("shootSpore FAIL -unkonwn id");
            return;
        }

        String f_name = first_o.getClass().getName();
        String other_name = other_o.getClass().getName();

        if(f_name.equals("Fungus") && other_name.contains("Tecton")) {
            Fungus fungus = (Fungus) first_o;
            Tecton tecton = (Tecton) other_o;

            boolean didShoot = fungus.releaseSpore(tecton);
            if (!didShoot) {
                if (errorLog.size() > 0) {
                    addErrorLine("shootSpore FAIL " + errorLog.get(0));
                    errorLog.clear();
                } else {
                    addErrorLine("shootSpore FAIL -shootSpore inner error");
                }
            }
        } else {
            addErrorLine("shootSpore FAIL -unkonwn id");
        }
    }

    /**
     * A fonal rovar felszívás utasítását végző parancskezelő.
     * <p>
     *  A cmd[1]-ben levő Thread Id-nak megfelelő fonalat utasítja a bénított rovarok felszívásra.
     * <p>
     * Az általa dobott hibaüzenetek:
     * <ul>
     *     <li> unkown id: Ha az id nem található a rendszerben.
     *     <li> incorrect parameter: Ha hibásan van paraméterezve a parancs.
     *     <li> thread is still growing: Ha a fonal még növekvő állapotban van.
     *     <li> no bug present: Ha nincs rovar a tektonon.
     *     <li> no paralyzed bug present: Ha nincs bénított rovar a tektonon.
     * </ul>
     * @param cmd A feldolgozandó parancssor.
     */
    private static void dissolveBug(String[] cmd) {
        if(cmd.length <= 1) {
            addErrorLine("dissolveBug FAIL -incorrect parameter");
            return;
        }

        Object first_o = objects.get(cmd[1]);
        if(first_o == null) {
            addErrorLine("dissolveBug FAIL -unkonwn id");
            return;
        }
        String f_name = first_o.getClass().getName();
        if(f_name.equals("FungalThread")) {
            FungalThread fungalThread = (FungalThread) first_o;
            boolean didDissolve = fungalThread.eatBugs();
            if(!didDissolve && errorLog.size() > 0) {
                if (errorLog.size() > 0) {
                    addErrorLine("dissolveBug FAIL " + errorLog.get(0));
                    errorLog.clear();
                } else {
                    addErrorLine("dissolveBug FAIL -dissolveBug inner error");
                }
            }
        } else {
            addErrorLine("dissolveBug FAIL -unkonwn id");
        }
    }
}
