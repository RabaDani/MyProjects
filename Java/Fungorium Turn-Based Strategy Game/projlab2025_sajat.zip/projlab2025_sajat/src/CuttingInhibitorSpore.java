/**
 * A vágást gátló spórákat reprezentáló osztály, amely a semleges spórák egy speciális típusa.
 * A rovarok elfogyasztva pontot kapnak, és képtelenné válnak a vágásra.
 */
public class CuttingInhibitorSpore extends NeutralSpore {

    /**
     * A CuttingInhibitorSpore osztály konstruktora.
     */
    public CuttingInhibitorSpore(){

    }

    /**
     * Meghívásakor a megadott rovar elfogyasztja a spórát, és pontot kap a tápérték alapján.
     * Ezen kívül a rovar nem lesz képes vágást végrehajtani.
     * A spóra ezt követően eltávolításra kerül a játéktérből.
     *
     * @param rovar A rovar, amely elfogyasztja a spórát.
     */
    @Override
    public void getAte(Bug rovar) {
        rovar.increasePoints(nutrient);
        rovar.preventsCutting();
        GameLogic.removeNeutralSpore(this);
    }
}
