import java.io.Serializable;
import java.util.*;

/**
 * A Tecton osztály egy tekton egységet reprezentál, amelyhez rovarok, spórák,
 * gombák és gombafonalak kapcsolódhatnak. Szomszédos tektonokkal hálózatot alkothat.
 */
public class Tecton implements Serializable {

    //Ezek protectedek, nem private-ok (doksiban elrontottam, upsz)
    protected int breakTime;
    protected int maxFungalThread;
    protected int maxFungus;
    protected ArrayList<Tecton> neighbours;
    protected ArrayList<NeutralSpore> spores;
    protected ArrayList<FungalThread> fungalThreads;
    protected ArrayList<Bug> bugs;
    protected Fungus fungus;

    /**
     * Létrehoz egy új tekton egységet.
     */
    public Tecton() {
        Random rand = new Random();
        //Létrehozzuk a tekton asszociációs tárolóit
        neighbours = new ArrayList<>();
        bugs = new ArrayList<>();
        spores = new ArrayList<>();
        fungalThreads = new ArrayList<>();

        //Beállítjuk a kezdő belső értékeket
        if(GameLogic.getRandom()){
            breakTime = rand.nextInt(GameLogic.getGameRounds() * 2) + 1;
            if(breakTime <= 5)
                breakTime = 5;
        }else{
            breakTime = 20;
        }
        maxFungalThread = GameLogic.getFungusPlayerNumber();
        maxFungus = 1;
    }

    /**
     * Visszaadja a kettétörés idejét
     * @return breakTime
     */
    public int getBreakTime() {
        return breakTime;
    }

    /**
     * Visszaadja a maximális gombafonalak számát
     * @return maxFungalThread
     */
    public int getMaxFungalThread() {
        return maxFungalThread;
    }

    /**
     * Visszaadja a maximális gombatestek számát
     * @return maxFungus
     */
    public int getMaxFungus() {
        return maxFungus;
    }

    /**
     * Visszaadja a tecton rovarlistáját
     * @return bugs
     */
    public List<Bug> getBugList() {
        return bugs;
    }

    /**
     * Visszaadja a tecton gombatestét
     * @return fungus
     */
    public Fungus getFungus() {
        return fungus;
    }

    /**
     * Beállítja a tekton kettétörésének idejét
     * @param breakTime tekton kettétörésének ideje
     */
    public void setBreakTime(int breakTime) {
        this.breakTime = breakTime;
    }

    /**
     * Beállítja a tekton maximális gombafonalainak számát
     * @param maxFungalThread maximális gombafonalak száma a tektonon
     */
    public void setMaxFungalThread(int maxFungalThread) {
        this.maxFungalThread = maxFungalThread;
    }

    /**
     * Beállítja a tekton maximális gombáinak számát
     * @param maxFungus maximális gombák száma a tektonon
     */
    public void setMaxFungus(int maxFungus){
        this.maxFungus = maxFungus;
    }

    /**
     * Beállítja a tektonon lévő gombát.
     * @param f Az új gomba objektum.
     */
    public void setFungus(Fungus f) {
        this.fungus = f;
    }

    /**
     * Visszaadja a tektonon lévő spórák listáját.
     * @return A spóralista másolata.
     */
    public ArrayList<NeutralSpore> getSporeList() {
        return new ArrayList<>(spores);
    }

    /**
     * Megadja a tekton gombafonal listáját
     * @return a visszaadott fonal lista.
     */
    public ArrayList<FungalThread> getThreadList() {
        return fungalThreads;
    }

    /**
     * Visszaadja a tekton szomszédossági listáját
     * @return A viszaadott szomszédosági lista
     */
    public ArrayList<Tecton> getNeighbourList() {
        return new ArrayList<>(neighbours);
    }

    /**
     * Hozzáad egy spórát a tektonhoz.
     * @param spore A hozzáadandó spóra.
     */
    public void addSpore(NeutralSpore spore) {
        if(!spores.contains(spore)){
            spores.add(spore);
        }
    }

    /**
     * Eltávolít egy spórát a tektonról.
     * @param spore Az eltávolítandó spóra
     */
    public void removeSpore(NeutralSpore spore) {
        if(spores.contains(spore)){
            spores.remove(spore);
            boolean removedSpore = spores.remove(spore);
            GameLogic.removeNeutralSpore(removedSpore ? spore : null);
        }
    }

    /**
     * Hozzáad egy rovart a tektonhoz.
     * @param rovar A hozzáadandó rovar.
     */
    public void addBug(Bug rovar) {
        if(!bugs.contains(rovar)){
            bugs.add(rovar);
        }
    }

    /**
     * Eltávolít egy rovart a tektonról.
     * @param rovar Az eltávolítandó rovar.
     */
    public void removeBug(Bug rovar) {
        if(bugs.contains(rovar)){
            bugs.remove(rovar);
        }
    }

    /**
     * Ellenőrzi, hogy egy másik tekton szomszédos-e ezzel a tektonnal.
     * @param other A vizsgált szomszédos tekton.
     * @return true, ha a tekton szomszédos, egyébként false.
     */
    public boolean isNeighbour(Tecton other) {
        return neighbours.contains(other);
    }

    /**
     * Hozzáad egy szomszédos tekton egységet.
     * @param other A hozzáadandó szomszédos tekton.
     */
    public void addNeighbour(Tecton other) {
        if(!neighbours.contains(other)) {
            neighbours.add(other);
        }
    }

    /**
     * Törli a paraméterül kapott tekton a szomszédossági listából
     * @param other A törölni kíván tekton.
     */
    public void removeNeighbour(Tecton other) {
        if(neighbours.contains(other)) {
            neighbours.remove(other);
        }
    }

    /**
     *Ez a függvény segíti a rovar lépkedését a tektonok között, annak lépésszáma és holléte alapján.
     * A distancetől függően tud lépni.
     * @param dest A kiválasztott tekton, ahova el szeretnénk jutni
     * @param distance A rovar lépéseinek száma
     * @return false értékkel tér vissza, ha a lépésszámunk 0 vagy 2<, amúgy meg 1 vagy 2 lépés esetén true
     */
    public boolean isThreadTo(Tecton dest, int distance) {

        if(distance <= 0) {
            GameLogic.addInnerError("-tecton too far");
            return false;
        }

        if(neighbours.contains(dest)){
            for(FungalThread thread : fungalThreads){
                if(thread.getConnectionTo(dest) != null) {
                    return true;
                }
            }
            if(distance == 1)
                GameLogic.addInnerError("-cannot find thread");
        } else {
            GameLogic.addInnerError("-tecton too far");
        }

        if(distance == 2) {
            for(Tecton neighbour : neighbours){
                if(neighbour != dest && this.isThreadTo(neighbour, distance-1))
                    if(neighbour.isThreadTo(dest, distance-1)) {
                        return true;
                    }
            }
        }
        return false;
    }

    /**
     * Ha sikeres a gombatest növesztés akkor kitöröl 2 spórát a tekton spóralistájából
     * @return false értékkel, ha a gombatest növesztés feltételei nem teljesülnek, amúgy meg true.
     */
    public boolean removeSporesToGrowFungus() {
        if (maxFungus == 0 || fungus != null) {
            GameLogic.addInnerError("-maxFungus reached");
            return false;
        } else if(spores.size() < 3) {
            GameLogic.addInnerError("-not enough spores");
            return false;
        }

        GameLogic.removeNeutralSpore(spores.remove(0));
        GameLogic.removeNeutralSpore(spores.remove(0));
        return true;
    }

    /**
     * Hozzáadja a tektonhoz a paraméterül kapott gombafonalat a gombafonallistához.
     * Majd ezek után beállítja a szükséges kapcsolatokat a tektonnal, gombatestel.
     * Ha van a tektonon spóra, akkor gyorsítja a gombafonal növekedést
     * @param thread A hozzáadandó gombafonal
     * @return false értékkel tér vissza, ha nem sikerült hozzáadni, ha sikeres a hozzáadás akkor pedig true
     */
    public FungalThread addFungalThread(FungalThread thread) {
        if (maxFungalThread == fungalThreads.size()) {
            GameLogic.addInnerError("-max thread reached");
            return null;
        }

        if(!spores.isEmpty()){
            thread.reduceGrowTime();
        }

        ArrayList<FungalThread> fungalThreadsCopy = new ArrayList<>(fungalThreads);
        for(FungalThread fungalThread : fungalThreadsCopy) {
            if(fungalThread.getTeamID() == thread.getTeamID()){
                return fungalThread;
            }
        }

        if(fungus != null && fungus.getTeamID() == thread.getTeamID()) {
            fungus.setFungalThread(thread);
            thread.setFungus(fungus);
        }
        thread.setTecton(this);
        fungalThreads.add(thread);
        return thread;
    }

    /**
     * Eltávolítja a paraméterül kapott gombafonalat a tektonról (törli a listájából)
     * @param thread Az eltávolítandó gombafonal
     */
    public void removeFungalThread(FungalThread thread) {
        if(fungalThreads.contains(thread)) {
            fungalThreads.remove(thread);
        }
    }



    /**
     * Frissíti a szomszédos tekton szomszédossági listáját
     * @param tectons Egy megadott szomszédossági lista.
     */
    public void updateTectonNeighbourList(List<Tecton> tectons) {
        neighbours.addAll(tectons);
        for(Tecton tecton : tectons){
            tecton.addNeighbour(this);
        }
    }

    /**
     * Meghívja a rovarlistájában lévő összes rovaron a felszívást.
     */
    public boolean removeBugsToGrowFungus(){
        boolean res = false;
        List<Bug> bugList = new ArrayList<>(bugs);
        for(Bug bug : bugList){
            boolean succes = bug.dissolve();
            if(succes) {
                res = true;
            }
        }
        if(bugs.size() == 0 && ! res)
            GameLogic.addInnerError("-no bug present");
        else if(!res)
            GameLogic.addInnerError("-no paralyzed bug present");
        return res;
    }

    //Kiszedtem ide a kód duplikációk miatt.
    //Mivel nem egyezik a doksikkal, ezért vissza lehet tenni, csak így szebb volt.
    public void tectonBreak(){

        //Két új tekton létrehozása és hozzáadása a játékhoz
        Tecton newTecton1 = new Tecton();
        GameLogic.addTecton(newTecton1);
        Tecton newTecton2 = new Tecton();
        GameLogic.addTecton(newTecton2);

        //Az új tektonok belső értékeit beállítjuk a szülő értékeire
        newTecton1.setMaxFungalThread(this.getMaxFungalThread());
        newTecton1.setMaxFungus(this.getMaxFungus());
        newTecton2.setMaxFungalThread(this.getMaxFungalThread());
        newTecton2.setMaxFungus(this.getMaxFungus());

        List<Tecton> t1List, t2List;
        int splitNum = neighbours.size()/2;
        t1List = new ArrayList<>(neighbours.subList(0, splitNum));
        t2List = new ArrayList<>(neighbours.subList(splitNum, neighbours.size()));

        newTecton1.addNeighbour(newTecton2);
        newTecton2.addNeighbour(newTecton1);

        newTecton1.updateTectonNeighbourList(t1List);
        newTecton2.updateTectonNeighbourList(t2List);

        //Az éppen széttörő tektonról törlünk minden és a rajta lévő objektumok törlődnek a játékból
        for(Tecton neighbour : neighbours){
            neighbour.removeNeighbour(this);
        }
        neighbours.clear();

        if(fungus != null) {
            fungus.die();
            fungus = null;
        }

        List<FungalThread> threadList = new ArrayList<>(fungalThreads);
        for(FungalThread thread : threadList){
            thread.die();
        }
        fungalThreads.clear();

        List<NeutralSpore> sporesList = new ArrayList<>(spores);
        for(NeutralSpore spore : sporesList){
            GameLogic.removeNeutralSpore(spore);
        }
        spores.clear();

        //A ketté törő tekton törlése a játékból
        GameLogic.removeTecton(this);
    }

    /**
     * Frissíti a tekton állapotát, és ha eljön a tekton kettétörésének ideje,
     * és éppen akkor nincs rovar a tektonon, akkor ketté töri azt, létrehozva 2 új tekton.
     */
    public void update() {
        breakTime--;
        if(breakTime == 0 && bugs.isEmpty()) {
            tectonBreak();
        }
    }

    @Override
    public String toString() {
        return "tecton";
    }
}
