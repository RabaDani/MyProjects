public class CloneSpore extends NeutralSpore {

    /**
     * A CloneSpore osztály konstruktora.
     */
    public CloneSpore(){

    }

    /**
     * Meghívásakor a megadott rovar elfogyasztja a spórát, és pontot kap a tápérték alapján.
     * Ezen kívül a rovar lemásolódik.
     * A spóra ezt követően eltávolításra kerül a játéktérből.
     *
     * @param rovar A rovar, amely elfogyasztja a spórát.
     */
    @Override
    public void getAte(Bug rovar) {
        rovar.increasePoints(nutrient);
        rovar.cloneBug();
        GameLogic.removeNeutralSpore(this);
    }
}
