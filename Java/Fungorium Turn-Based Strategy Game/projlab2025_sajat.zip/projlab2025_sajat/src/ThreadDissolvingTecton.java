import java.util.ArrayList;

/**
 * A ThreadDissolvingTecton egy speciális Tecton, amely idővel megszünteti a rajta lévő fonalakat
 */
public class ThreadDissolvingTecton extends Tecton {

    /**
     * Létrehoz egy új ThreadDissolvingTecton példányt.
     */
    public ThreadDissolvingTecton() {}

    public boolean addToGame(ThreadDissolvingTecton tecton){
        return GameLogic.addThreadDissolvingTecton(tecton);
    }
    /**
     * Frissíti a Tecton állapotát. Ha a breakTime eléri a 0-t és nincs rajta Bug,
     * akkor a Tecton szétesik két új Tectonná, megszüntetve az összes kapcsolatát.
     * Ellenkező esetben a rajta lévő FungalThread objektumok elkezdenek feloldódni.
     */
    @Override
    public void update() {
        breakTime--;
        if(breakTime == 0 && bugs.isEmpty()) {
            tectonBreak();
        } else {
            ArrayList<FungalThread> fungalThreadsCopy = new ArrayList<>(fungalThreads);
            for(FungalThread thread : fungalThreadsCopy){
                thread.dissolve();
            }
        }
    }

    @Override
    public String toString() {
        return "dissolvingtecton";
    }
}
