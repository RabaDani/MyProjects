import java.util.*;

public class Skeleton {

    /**
     * Ebben a HashMap-ben tároljuk az egyes tesztek során létrejövő objektumokat és a nevüket.
     * */
    private static HashMap<Object, String> entityList = new HashMap<>();
    // Az indentálás mértékt tároló érték
    private static int indent = 0;
    // Jelzi, ha éppen inícializálás közben van a rendszer
    public static boolean init;
    private static Scanner scn = new Scanner(System.in);
    private  static List<String> nameList = new ArrayList<>();
    private static List<String> testList = new ArrayList<>();

    /**
     * A soreleji behúzást végzi.
    * */
    public static void indentLine() {
        for(int i = 0; i < Skeleton.indent; i++)
            System.out.print("\t");
    }

    /**
     * A paraméterként átadott szöveget indentálva írja ki a konzolra, és a végén soremelést is végez.
    * */
    public static void writeIndentedLine(String line) {
        indentLine();
        System.out.println(line);
    }

    /**
     * A paraméterként átadott szöveget indentálva írja ki a konzolra, és a végén nem végez soremelést.
     * */
    public static void writeIndentedText(String line) {
        indentLine();
        System.out.print(line);
    }

    public static void entranceLine(String method) {
        indentLine();
        System.out.print("->");
        System.out.println(method);
        indent++;
    }

    /**
     * A paraméterként átadott szöveget és objektumot az objektumon történő metódushívás formájában jeleníti meg a kijelzőn.
     * A megjelenítés formátuma:
     * ->[ob entityList-ben tárolt neve].[method]
     * */
    public static void entranceLine(String method, Object ob) {
        indentLine();
        System.out.print("->"+getEntityName(ob)+".");
        System.out.println(method);
        indent++;
    }
    /**
     * A paraméterként átadott szöveget a metódusból történő visszatéréseként jeleníti meg a kijelzőn.
     * A megjelenítés formátuma:
     * <-[returnValue]
     * */
    public static void exitLine(String returnValue) {
        indent--;
        indentLine();
        System.out.print("<-");
        System.out.println(returnValue);
    }

    /**
     * A paraméterként átadott objectumot a metódusból történő visszatéréseként jeleníti meg a kijelzőn.
     * A megjelenítés formátuma:
     * <-[ob name from entityList]
     * */
    public static void exitLine(Object ob) {
        indent--;
        indentLine();
        System.out.print("<-");
        System.out.println(getEntityName(ob));
    }

    /**
     * A paraméterként átadott objektum nevét kikeresi az entityListből és azzal tér vissza.
     */
    public static String getEntityName(Object ob) {
        return entityList.get(ob);
    }

    /**
     * A nameListben tárolt nevek közül kiveszi az elsőt és azzal tér vissza.
     * @return String - Egy objektumhoz tartozó név.
     */
    public static String getNewName() {
        if(nameList.size() != 0)
            return nameList.remove(0);
        return null;
    }

    /**
     * A paraméterként megkapott objectumot elhelyezi az entityListben.
     * Az objektum nevét a nameList-ből kapja.
     * @param ob - Az elnevezendő objektum.
     */
    public static void putNewEntity(Object ob) {
        entityList.put(ob, getNewName());
    }

    public static void clearLists() {
        entityList.clear();
        nameList.clear();
    }

    /**
     * A felhasználói inputot bekérő függvény.
     * @param question - A kért inputhoz tartozó utasítás.
     * @param mintValue - A minimális érték.
     * @param maxValue - A maximális érték.
     * @return - A min és max értékek közötti érték, amit a felhasználó adott meg.
     */
    public static int getInput(String question, int mintValue, int maxValue) {
        if(init) {
            return 3;
        }
        int chosen = -1;
        boolean wrongInput = false;
        do {
            if(wrongInput) {
                writeIndentedLine("Érvénytelen értéket adott meg!");
            }
            writeIndentedText("*"+question+" ("+mintValue+" - "+maxValue+"): ");
            chosen = scn.nextInt();
            wrongInput = true;
        } while(chosen < mintValue || chosen > maxValue);
        return chosen;
    }

    /**
     * Az opciókat listázó függvény.
     */
    public static void listOptions() {
        System.out.println("[0] exit");
        for(int i = 1; i <= testList.size(); i++) {
            System.out.println("["+i+"] "+testList.get(i-1));
        }
    }

    /**
     * Az elérhető tesztek neveit inicializalja.
     */
    public static void testListInit() {
        // Tesztek neve ide
        testList.add("Bug eat NeutralSpore (spore exists)");
        testList.add("Bug eat NeutralSpore (spore absent)");
        testList.add("grow Fungus on Tecton (no fungus on tecton, enough spores)");
        testList.add("grow Fungus on Tecton (not enough spores)");
        testList.add("grow Fungus on Tecton (tecton has fungus)");
        testList.add("Fungusshoots spore to neighbour");
        testList.add("Fungusshoots spore 2 tectons far");
        testList.add("FungalThread die");
        testList.add("Dissolving Tecton absorbs FungalThread");
        testList.add("Bug attempts to cut (Tecton not neighbour)");
        testList.add("Bug attempts to cut (no relevant connection)");
        testList.add("Bug attempts to cut (FungalThread present)");
        testList.add("Bug attempts to cut (FungalThread absent)");
        testList.add("Bug moves to neighbour(FungalThread present)");
        testList.add("Bug Attempts To Move (Fungalthread absent)");
        testList.add("Fungal Thread Can Grow FungalThread");
        testList.add("Fungal Thread Can't Grow FungalThread");
        testList.add("Bug eat SpeedSpore");
        testList.add("Bug eat SlowSpore");
        testList.add("Bug eat ParalayzeSpore");
        testList.add("Bug eat CuttingInhibitorSpore");
        testList.add("Tecton break (bug present)");
        testList.add("Tecton break (bug absent)");
        testList.add("Fungus grow FungalThread (thread present)");
        testList.add("Fungus grow FungalThread (thread absent, with spore)");

    }

    public static void main(String[] cmd) {
        testListInit();
        int numChosen = -1;
        do {
            listOptions();
            numChosen = getInput("Válassz a menüpontok közül", 0, testList.size());

            if(numChosen > 0 && numChosen <= testList.size()) {
                writeIndentedLine("-----------------------------------------");
                writeIndentedText(testList.get(numChosen-1));
                writeIndentedLine(" init");
                switch (numChosen) {
                    case 1:
                        test1();
                        break;
                    case 2:
                        test2();
                        break;
                    case 3:
                        test3();
                        break;
                    case 4:
                        test4();
                        break;
                    case 5:
                        test5();
                        break;
                    case 6:
                        test6();
                        break;
                    case 7:
                        test7();
                        break;
                    case 8:
                        test8();
                        break;
                    case 9:
                        test9();
                        break;
                    case 10:
                        test10();
                        break;
                    case 11:
                        test11();
                        break;
                    case 12:
                        test12();
                        break;
                    case 13:
                        test13();
                        break;
                    case 14:
                        test14();
                        break;
                    case 15:
                        test15();
                        break;
                    case 16:
                        test16();
                        break;
                    case 17:
                        test17();
                        break;
                    case 18:
                        test18();
                        break;
                    case 19:
                        test19();
                        break;
                    case 20:
                        test20();
                        break;
                    case 21:
                        test21();
                        break;
                    case 22:
                        test22();
                        break;
                    case 23:
                        test23();
                        break;
                    case 24:
                        test24();
                        break;
                    case 25:
                        test25();
                        break;
                }
            }
        } while (numChosen != 0);
        writeIndentedLine("Kilépés.");
        scn.close();
    }

    /**
     * Use-case: Bug eat NeutralSpore (spore present)
     *
     * A rovar megkapja a spóra elfogyasztásának utasítását, és
     * elfogyasztja a tektonon található NeutralSpore-t, ami növeli a
     * rovar pontszámát.
     */
    public static void test1() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        NeutralSpore spore = new NeutralSpore();
        entityList.put(spore, "ns");

        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.addBug(b);
        t.addSpore(spore);
        b.setTecton(t);

        init = false;
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug eat NeutralSpore (spore present)");
        b.eatSpore();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug eat NeutralSpore (spore absent)
     *
     * A rovar megkapja a spóra elfogyasztásának utasítását, de
     * mivel nincs jelen spóra a tektonon így nem képes
     * végrahajtani azt.
     */
    public static void test2() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.addBug(b);
        b.setTecton(t);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug eat NeutralSpore (spore absent)");
        b.eatSpore();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: grow Fungus on Tecton (no fungus on tecton, enough spores)
     *
     * A felhasználó kiadja a gombatest növesztését a
     * gombafonállal rendelkező tektonra, ezért, ha a tektonra lehet
     * gombát növeszteni, a gombafonál kérésére a tekton 2 spórát
     * elhasznál gombatest növesztéshez, majd a gombafonál
     * elhelyez a tektonon egy gombatestet, a tekton pedig beállítja
     * a gombatest lokációját önmagára.
     */
    public static void test3() {
        init = true;

        Tecton f_location = new Tecton();
        entityList.put(f_location, "f_location");

        NeutralSpore s1 = new NeutralSpore();
        entityList.put(s1, "s1");
        NeutralSpore s2 = new NeutralSpore();
        entityList.put(s2, "s2");
        NeutralSpore s3 = new NeutralSpore();
        entityList.put(s3, "s3");

        f_location.addSpore(s1);
        f_location.addSpore(s2);
        f_location.addSpore(s3);

        FungalThread f = new FungalThread();
        entityList.put(f, "f");

        f_location.addFungalThread(f);

        init = false;

        nameList.add("g");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: grow Fungus on Tecton (no fungus on tecton, enough spores)");
        f.growFungus();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: grow Fungus on Tecton (not enough spores)
     *
     * A felhasználó kiadja a gombatest növesztését a
     * gombafonállal rendelkező tektonra, viszont a tektonon
     * nincs a gobatest növesztéshez elegendő spóra,
     * így sikertelen lesz a művelet.
     */
    public static void test4() {
        init = true;

        Tecton f_location = new Tecton();
        entityList.put(f_location, "f_location");

        FungalThread f = new FungalThread();
        entityList.put(f, "f");

        f_location.addFungalThread(f);

        init = false;

        nameList.add("g");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: grow Fungus on Tecton (not enough spores)");
        f.growFungus();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: grow Fungus on Tecton (tecton has fungus)
     *
     * A felhasználó kiadja a gombatest növesztését a
     * gombafonállal rendelkező tektonra, viszont a tektonon
     * már található gombatest,
     * így sikertelen lesz a művelet.
     */
    public static void test5() {
        init = true;

        Tecton f_location = new Tecton();
        entityList.put(f_location, "f_location");

        Fungus fg = new Fungus();
        entityList.put(fg, "fg");

        f_location.setFungus(fg);
        fg.setTecton(f_location);

        FungalThread f = new FungalThread();
        entityList.put(f, "f");

        f_location.addFungalThread(f);

        init = false;

        nameList.add("g");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: grow Fungus on Tecton (tecton has fungus)");
        f.growFungus();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Fungus shoots spore to neighbour
     *
     * A gombatest megkapja a spóra lövésének utasítását, és, ha a
     * sporeTank és a sporeRemainingShots nem nulla, a gombatest
     * kilő spórát t1 szomszédos tektonra. Ha ezután a spóratár
     * kiürül (sporeTank==0), akkor a gombatest meghal.
     */
    public static void test6() {
        init = true;

        Tecton f_location = new Tecton();
        entityList.put(f_location, "f_location");

        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");

        t1.addNeighbour(f_location);
        f_location.addNeighbour(t1);

        Fungus f = new Fungus();
        entityList.put(f, "f");

        f_location.setFungus(f);
        f.setTecton(f_location);

        init = false;

        nameList.add("s");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Fungus shoots spore to neighbour");
        f.releaseSpore(t1);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Fungusshoots spore 2 tectons far
     *
     * A gombatest megkapja a spóra lövésének utasítását, és, ha a
     * sporeTank és a sporeRemainingShots nem nulla és a
     * gombatest fejlett, akkor a gombatest kilő spórát egy
     * szomszédos tekton szomszédjára. Ha ezután a spóratár kiürül
     * (sporeTank==0), akkor a gombatest meghal.
     */
    public static void test7() {
        init = true;

        Tecton f_location = new Tecton();
        entityList.put(f_location, "f_location");

        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");

        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");

        t1.addNeighbour(t2);
        t2.addNeighbour(t1);

        t2.addNeighbour(f_location);
        f_location.addNeighbour(t2);

        Fungus f = new Fungus();
        entityList.put(f, "f");

        f_location.setFungus(f);
        f.setTecton(f_location);

        init = false;

        nameList.add("s");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Fungusshoots spore 2 tectons far");
        f.releaseSpore(t1);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: FungalThread die
     *
     * A fonál megkapja a meghalás utasítást, ennek hatására
     * megszakítja a fonál kapcsolatot a fonállal és a tektonnal. Ha
     * gombatesttel is kapcsolatban volt, annak kapcsolatát is
     * érvényteleníti.
     */
    public static void test8() {
        init = true;

        FungalThread fth1 = new FungalThread();
        entityList.put(fth1, "fth1");
        FungalThread fth2 = new FungalThread();
        entityList.put(fth2, "fth2");
        Fungus f = new Fungus();
        entityList.put(f, "f");
        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.setFungus(f);
        f.setTecton(t);

        t.addFungalThread(fth1);
        fth1.addConnection(fth2);
        fth2.addConnection(fth1);


        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: FungalThread die");
        fth1.die();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Dissolving Tecton absorbs FungalThread
     *
     * Ha a fonál felszívódás ideje nem járt le, sikertelen a fonál
     * halála. Ha letelt az idő, akkor megszakítja a kapcsolatot a
     * tektonnal, a gombatesttel és a kapcsolódó fonallal.
     */
    public static void test9() {
        init = true;

        FungalThread fth1 = new FungalThread();
        entityList.put(fth1, "fth1");
        FungalThread fth2 = new FungalThread();
        entityList.put(fth2, "fth2");
        Fungus f = new Fungus();
        entityList.put(f, "f");
        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.setFungus(f);
        f.setTecton(t);

        t.addFungalThread(fth1);
        fth1.addConnection(fth2);
        fth2.addConnection(fth1);


        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Dissolving Tecton absorbs FungalThread");
        fth1.dissolve();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug attempts to cut (Tecton not neighbour)
     *
     * A rovar megkapja a fonal vágásának utasítását, de a saját
     * tektonja és a kijelölt tekton nem szomszédosak, így nincs
     * köztük rés ahol a vágást tudná végezni. Sikertelen vágás lesz az eredmény.
     */
    public static void test10() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");
        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");
        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");

        t1.addBug(b);
        b.setTecton(t1);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug attempts to cut (Tecton not neighbour)");
        b.cutThreadAtGap(t2);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug attempts to cut (no relevant thread)
     *
     * A rovar megkapja a fonal vágásának utasítását, de a tektonján
     * található fonalnak nem a kijelölt tekton lévő fonallal van
     * kapcsolata. Ezért sikertelen lesz a vágás.
     */
    public static void test11() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");
        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");
        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");
        Tecton t3 = new Tecton();
        entityList.put(t3, "t3");
        FungalThread fth2 = new FungalThread();
        entityList.put(fth2, "fth2");
        FungalThread fth1 = new FungalThread();
        entityList.put(fth1, "fth1");

        t1.addBug(b);
        b.setTecton(t1);
        fth1.addConnection(fth2);
        fth2.addConnection(fth1);
        t1.addFungalThread(fth1);
        t3.addFungalThread(fth2);
        t1.addNeighbour(t2);
        t3.addNeighbour(t1);
        t1.addNeighbour(t3);
        t2.addNeighbour(t1);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug attempts to cut (no relevant connection)");
        b.cutThreadAtGap(t2);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug attempts to cut (FungalThread present)
     * 
     * A rovar megkapja a fonal vágásának utasítását. Ha a rovar nem bénított vagy
     * vágást gátló állapotban van, vagy ha a fonal részek nem növekvő állapotban vannak,
     * akkor elvágja a saját tektonja és a kijelölt tekton között húzódó fonal kapcsolatot.
     */
    public static void test12() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");
        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");
        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");
        FungalThread fth2 = new FungalThread();
        entityList.put(fth2, "fth2");
        FungalThread fth1 = new FungalThread();
        entityList.put(fth1, "fth1");

        t1.addBug(b);
        b.setTecton(t1);
        fth1.addConnection(fth2);
        fth2.addConnection(fth1);
        t1.addFungalThread(fth1);
        t2.addFungalThread(fth2);
        t1.addNeighbour(t2);
        t2.addNeighbour(t1);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug attempts to cut (FungalThread present)");
        b.cutThreadAtGap(t2);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug attempts to cut (FungalThread absent)
     * 
     * A rovar megkapja a fonal vágásának utasítását, és mivel nincs
     * a tektonon fonalrész ami kapcsolatban lenne más fonallal így
     * sikertelen jelzéssel tér vissza a fonal vágásból.
     */
    public static void test13() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");
        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");
        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");

        t1.addBug(b);
        b.setTecton(t1);
        t1.addNeighbour(t2);
        t2.addNeighbour(t1);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug attempts to cut (FungalThread absent)");
        b.cutThreadAtGap(t2);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug moves to neighbour (FungalThread present)
     * 
     * A t1 és a t2 tektonok szomszédosak egymással. A t1 tektonon a fth1 fonál,
     * míg a t2 tektonon a fth2 fonál található. A két fonál kapcsolatban van egymással.
     * A rovar a t1 tektonról indulva a fth1 és fth2 fonalakat követve átmegy a t2 tektonra.
     * A mozgás sikeressége függ a rovar és a fonalak belső állapotától.
     */
    public static void test14() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");

        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");

        FungalThread fth2 = new FungalThread();
        entityList.put(fth2, "fth2");

        FungalThread fth1 = new FungalThread();
        entityList.put(fth1, "fth1");

        t1.addBug(b);
        b.setTecton(t1);
        fth1.addConnection(fth2);
        fth2.addConnection(fth1);
        t1.addFungalThread(fth1);
        t2.addFungalThread(fth2);
        t1.addNeighbour(t2);
        t2.addNeighbour(t1);

        init = false;

        nameList.add("s");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug moves to neighbour(FungalThread present)");
        b.moveTo(t2);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug attempts to move (FungalThread absent)
     * 
     * A t1, t2 és t3 tektonok egymással szomszédosak.
     * Egyik tektonon se található fonal.
     * A rovar a t1 tektonról indulva próbál a t2 tektonra jutni.
     */
    public static void test15() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");

        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");

        t1.addBug(b);
        b.setTecton(t1);
        t1.addNeighbour(t2);
        t2.addNeighbour(t1);

        Tecton t3 = new Tecton();
        entityList.put(t3, "t3");

        t3.addNeighbour(t1);
        t3.addNeighbour(t2);
        t2.addNeighbour(t3);
        t1.addNeighbour(t3);

        init = false;

        nameList.add("s");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug Attempts To Move (Fungalthread absent)");
        b.moveTo(t2);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: FungalThread can grow FungalThread
     * 
     * A felhasználó megpróbál egy új gombafonalat növeszteni egy meglévő gombafonalból
     * egy szomszédos Tektonra. A rendszer ellenőrzi, hogy a cél Tekton szomszédos-e,
     * majd megpróbálja hozzáadni az új gombafonalat. Ha a Tektonon spóra található,
     * akkor a növekedési idő csökken. Ha a Tektonon már van gomba, akkor az új gombafonal
     * hozzárendelődik hozzá. Végül a gombafonal sikeresen létrejön, és a rendszer rögzíti az új kapcsolatot.
     */
    public static void test16() {

        init = true;

        FungalThread ft = new FungalThread();
        entityList.put(ft, "ft");

        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");

        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");

        NeutralSpore ns = new NeutralSpore();
        entityList.put(ns, "ns");

        Fungus f = new Fungus();
        entityList.put(f, "f");

        t1.addNeighbour(t2);
        t2.addNeighbour(t1);

        t1.addFungalThread(ft);

        t2.addSpore(ns);
        t2.setFungus(f);
        f.setTecton(t2);

        init = false;

        nameList.add("ft2");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: FungalThread Can Grow FungalThread");
        ft.growFungalThread(t2);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: FungalThread can’t grow FungalThread
     * 
     * A felhasználó megpróbál egy új gombafonalat növeszteni egy meglévő gombafonalból egy szomszédos Tektonra.
     * A rendszer ellenőrzi, hogy a cél Tekton szomszédos-e, majd megpróbálja hozzáadni az új gombafonalat.
     * Azonban a művelet sikertelen, mert a Tektonon már három különböző gombafonal található, és ugyanattól a
     * gombafajtól nem lehet egynél több fonál.
     */
    public static void test17() {

        init = true;

        FungalThread ft = new FungalThread();
        entityList.put(ft, "ft");

        Tecton t1 = new Tecton();
        entityList.put(t1, "t1");

        Tecton t2 = new Tecton();
        entityList.put(t2, "t2");

        FungalThread ft2 = new FungalThread();
        entityList.put(ft2, "ft2");

        FungalThread ft3 = new FungalThread();
        entityList.put(ft3, "ft3");

        FungalThread ft4 = new FungalThread();
        entityList.put(ft4, "ft4");

        t1.addFungalThread(ft);

        t1.addNeighbour(t2);
        t2.addNeighbour(t1);

        t2.addFungalThread(ft2);
        t2.addFungalThread(ft3);
        t2.addFungalThread(ft4);

        init = false;
        nameList.add("ft2");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: FungalThread Can't Grow FungalThread");
        ft.growFungalThread(t2);
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug eat SpeedSpore
     * 
     * A rovar megkapja a spóra elfogyasztásának utasítását, és elfogyasztja a tektonon található SpeedSpore-t,
     * ami a pontszámnövelésen felül gyorsító hatást fejt ki a rovarra.
     */
    public static void test18() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        SpeedSpore ss = new SpeedSpore();
        entityList.put(ss, "ss");

        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.addBug(b);
        t.addSpore(ss);
        b.setTecton(t);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug eat SpeedSpore");
        b.eatSpore();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug eat SlowSpore
     * 
     * A rovar megkapja a spóra elfogyasztásának utasítását, és elfogyasztja a tektonon található SlowSpore-t,
     * ami lassító hatást fejt ki a rovarra.
     */
    public static void test19() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        SlowSpore ss = new SlowSpore();
        entityList.put(ss, "ss");

        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.addBug(b);
        t.addSpore(ss);
        b.setTecton(t);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug eat SlowSpore");
        b.eatSpore();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug eat ParalyzeSpore
     * 
     * A rovar megkapja a spóra elfogyasztásának utasítását, és elfogyasztja a tektonon található ParalyzeSpore-t,
     * ami bénító hatást fejt ki a rovarra.
     */
    public static void test20() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        ParalyzeSpore ps = new ParalyzeSpore();
        entityList.put(ps, "ps");

        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.addBug(b);
        t.addSpore(ps);
        b.setTecton(t);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug eat ParalyzeSpore");
        b.eatSpore();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Bug eat CuttingInhibitorSpore
     * 
     * A rovar megkapja a spóra elfogyasztásának utasítását, és elfogyasztja a tektonon található CuttingInhibitorSpore-t,
     * ami bénító hatást fejt ki a rovarra.
     */
    public static void test21() {
        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        CuttingInhibitorSpore cis = new CuttingInhibitorSpore();
        entityList.put(cis, "cis");

        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.addBug(b);
        t.addSpore(cis);
        b.setTecton(t);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Bug eat CuttingInhibitorSpore");
        b.eatSpore();
        writeIndentedLine("-----------------------------------------");
        clearLists();
    }

    /**
     * Use-case: Tecton break (bug present)
     * 
     * A tektonnak elkövetkezik a kettétörési ideje, de mivel van rajta rovar, emiatt ez nem következik be.
     */
    public static void test22() {

        init = true;

        Bug b = new Bug();
        entityList.put(b, "b");

        Tecton t = new Tecton();
        entityList.put(t, "t");

        t.addBug(b);
        b.setTecton(t);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Tecton break (bug present)");
        t.update();
        writeIndentedLine("-----------------------------------------");
    }

    /**
     * Use-case: Tecton break (bug absent)
     * 
     * A tektonnak ha elkövetkezik a kettétörés ideje, akkor a tekton ketté töri magát két
     * kisebb tektonra és elpusztítja azt ami rajta van.
     */
    public static void test23() {
        init = true;

        FungalThread ft1 = new FungalThread();
        entityList.put(ft1, "ft1");

        FungalThread ft2 = new FungalThread();
        entityList.put(ft2, "ft2");

        Tecton t = new Tecton();
        entityList.put(t, "t");

        Tecton t_neighbour2 = new Tecton();
        entityList.put(t_neighbour2, "t_neighbour2");

        Tecton t_neighbour1 = new Tecton();
        entityList.put(t_neighbour1, "t_neighbour1");

        Fungus f = new Fungus();
        entityList.put(f, "f");

        t.addNeighbour(t_neighbour1);
        t.addNeighbour(t_neighbour2);
        t_neighbour2.addNeighbour(t);
        t_neighbour1.addNeighbour(t);
        t.setFungus(f);
        f.setTecton(t);
        t.addFungalThread(ft1);
        t_neighbour2.addFungalThread(ft2);
        ft1.addConnection(ft2);
        ft2.addConnection(ft1);

        init = false;

        nameList.add("t1");
        nameList.add("t2");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Tecton break (bug absent)");
        t.update();
        writeIndentedLine("-----------------------------------------");
    }

    /**
     * Use-case: Fungus grow FungalThread (thread present)
     * 
     * A gombatest megkapja a gombafonal növesztés utasítást, és a gombatest nem tud növeszteni
     * a saját tektonjára gombafonalat, mert van már rajta (saját) fonal.
     */
    public static void test24() {

        init = true;

        Fungus f = new Fungus();
        entityList.put(f, "f");

        Tecton f_location = new Tecton();
        entityList.put(f_location, "f_location");

        FungalThread ft = new FungalThread();
        entityList.put(ft, "ft");

        f_location.setFungus(f);
        f.setTecton(f_location);
        f_location.addFungalThread(ft);

        init = false;

        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Fungus grow FungalThread (thread present)");
        f.createFungalThread();
        writeIndentedLine("-----------------------------------------");
    }

    /**
     * Use-case: Fungus grow FungalThread (thread absent, with spore)
     * 
     * A gombatest megkapja a növessz gombafonalat utasítást, és a gombatest kinöveszt egy gombafonalat
     * a saját tektonjára. A tektonon van spóra, emiatt a gombafonal gyorsabban nő.
     */
    public static void test25() {

        init = true;

        Tecton f_location = new Tecton();
        entityList.put(f_location, "f_location");

        Fungus f = new Fungus();
        entityList.put(f, "f");

        NeutralSpore s = new NeutralSpore();
        entityList.put(s, "s");

        f_location.addSpore(s);
        f_location.setFungus(f);
        f.setTecton(f_location);

        init = false;

        nameList.add("ft");
        writeIndentedLine("-----------------------------------------");
        writeIndentedLine("Test: Fungus grow FungalThread (thread absent, with spore)");
        f.createFungalThread();
        writeIndentedLine("-----------------------------------------");
    }
}