import java.io.Serializable;
import java.util.*;


/**
 * A rovar (Bug) osztály, amely egy Tecton helyszínen tartózkodik,
 * és képes mozogni, spórát enni, illetve fonalakat elvágni.
 */
public class Bug implements Serializable {
    private Tecton location;
    private int speed;
    private int paralyzedTime;
    private int speedIncTime;
    private int speedDecTime;
    private int cutInhibitTime;
    private int teamID;

    /**
     * A rovar létrehozásakor meghívódó konstruktor.
     */
    public Bug() {
        //location = new Tecton();

        speed = 1;
        paralyzedTime = 0;
        speedIncTime = 0;
        speedDecTime = 0;
        cutInhibitTime = 0;

        teamID = -1;
    }

     /**
     * A rovar megpróbál megenni egy spórát.
     * @return true, ha sikerült megenni egy spórát, különben false.
     */
    public boolean eatSpore() {

        if(paralyzedTime > 0) {
            GameLogic.addInnerError("-bug is paralyzed");
            return false;
        }
        List<NeutralSpore> sporeList = null;
        if(location != null) {
            sporeList = location.getSporeList();
        } //Majd lehet kelleni fog egy exception arra ha a rovarnak nincs tektonja


        if(sporeList.isEmpty()) {
            GameLogic.addInnerError("-no spore to eat");
            return false;
        }

        NeutralSpore spore = sporeList.remove(0);
        location.removeSpore(spore);
        spore.getAte(this);

        return true;
    }

    /**
     * Növeli a rovar által gyűjtött pontokat.
     * @param point A növelendő pontok száma.
     */
    public void increasePoints(int point) {
        GameLogic.addPoints(teamID, point);
    }

    /**
     * A rovar megpróbál átmenni egy másik Tecton-ra egy fonálon át.
     * @param tecton A célállomás.
     * @return true, ha a mozgás sikeres volt, különben false.
     */
    public boolean moveTo(Tecton tecton) {

        if(speed == 0) {
            GameLogic.addInnerError("-bug is slow");
            return false;
        } else if(paralyzedTime > 0) {
            GameLogic.addInnerError("-bug is paralyzed");
            return false;
        } else if(location != null && location == tecton) {
            //TODO erre nincs kifejezetten hibaüzenet
            GameLogic.addInnerError("-bug location error");
            return false;
        }

        if(location.isThreadTo(tecton, speed)) {
            location.removeBug(this);
            tecton.addBug(this);
            location = tecton;

            return true;
        }

        return false;
    }

    /**
     * Megpróbálja elvágni a fonalat a két Tecton között.
     * @param dest A célállomás, amelyhez a fonalat elvágja.
     * @return true, ha a vágás sikeres, különben false.
     */
    boolean cutThreadAtGap(Tecton dest) {
        if(paralyzedTime > 0) {
            GameLogic.addInnerError("-bug is paralyzed");
            return false;
        }
        if(cutInhibitTime > 0) {
            GameLogic.addInnerError("-bug is cut inhibited");
            return false;
        }

        boolean cutSuccess = false;
        if(location != null && location.isNeighbour(dest)) {
            ArrayList<FungalThread> threads = location.getThreadList();


            Iterator<FungalThread> iterator = threads.iterator();
            while(iterator.hasNext()) {
                FungalThread thread = iterator.next();
                if(thread.cutConnectionTo(dest))
                    cutSuccess = true;
            }
            if(!cutSuccess) {
                GameLogic.addInnerError("-cannot find thread");
            }
        } else {
            GameLogic.addInnerError("-tecton is not neighbour");
        }
        return cutSuccess;
    }

    /**
     * Beállítja a rovar aktuális Tectonját.
     * @param t Az új Tecton, amelyen a rovar tartózkodik.
     */
    public void setTecton(Tecton t) {
        location = t;
    }

    /**
     * Lekéri a rovar aktuális Tectonját.
     * @return A Tecton, ahol a rovar jelenleg van.
     */
    public Tecton getTecton() {
        return location;
    }

    public int getTeamID(){
        return teamID;
    }

    public void setTeamID(int teamID){
        this.teamID = teamID;
    }

    /**
     * A rovar bénító hatást okoz.
     */
    public void causesParalyzed() {
        paralyzedTime=2;
    }

    /**
     * Megakadályozza a fonalak elvágását.
     */
    public void preventsCutting() {
        cutInhibitTime=2;
    }

    /**
     * Csökkenti a rovar sebességét.
     */
    public void decreaseSpeed() {
        if(speedDecTime == 0)
            speed--;
        speedDecTime = 2;
    }

    /**
     * Növeli a rovar sebességét.
     */
    public void increaseSpeed() {
        if(speedIncTime == 0)
            speed++;
        speedIncTime = 2;
    }

    /**
     * Felszívja a rovart a tektonról, hogyha az bénított állapotban van.
     */
    public boolean dissolve() {
        if(paralyzedTime > 0){
            if(this.location != null) {
                location.removeBug(this);
                GameLogic.removeBug(this);
                return true;
            }
        }
        return false;
    }

    /**
     * Az idő múlását jelzi és a rovar belső működését vezérli.
     */
    public void update(){
        if(paralyzedTime > 0){
            paralyzedTime--;
        }

        if(speedIncTime > 0){
            speedIncTime--;
            if(speedIncTime == 0)
                speed--;
        }

        if(speedDecTime > 0){
            speedDecTime--;
            if (speedDecTime == 0)
                speed++;
        }

        if(cutInhibitTime > 0){
            cutInhibitTime--;
        }
    }

    /**
     *  Létrehoz egy másik rovart, amelynek beállítja a tektonját és rovarászát a sajátjaira.
     */
    public void cloneBug(){
        Bug bug = new Bug();
        GameLogic.addBug(bug);
        bug.setTecton(location);
        bug.setTeamID(teamID);
    }

    /**
     * Visszaadja a rovar aktuális sebességét.
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * Beállítja a rovar aktuális sebességét.
     */
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    /**
     * Visszaadja, hogy a rovar még mennyi ideig van megbénulva.
     */
    public int getParalyzedTime() {
        return paralyzedTime;
    }

    /**
     * Beállítja, hogy a rovar mennyi ideig legyen mozgásképtelen.
     */
    public void setParalyzedTime(int paralyzedTime) {
        this.paralyzedTime = paralyzedTime;
    }

    /**
     * Visszaadja, hogy a rovar megnövelt sebessége meddig érvényes.
     */
    public int getSpeedIncTime() {
        return speedIncTime;
    }

    /**
     * Beállítja, hogy a rovar megnövelt sebessége meddig tartson.
     */
    public void setSpeedIncTime(int speedIncTime) {
        this.speedIncTime = speedIncTime;
    }

    /**
     * Visszaadja, hogy a rovar csökkentett sebessége meddig érvényes.
     */
    public int getSpeedDecTime() {
        return speedDecTime;
    }

    /**
     * Beállítja, hogy a rovar csökkentett sebessége meddig tartson.
     */
    public void setSpeedDecTime(int speedDecTime) {
        this.speedDecTime = speedDecTime;
    }

    /**
     * Visszaadja, hogy a rovar meddig nem képes fonalat vágni.
     */
    public int getCutInhibitTime() {
        return cutInhibitTime;
    }

    /**
     * Beállítja, hogy a rovar mennyi ideig nem tud fonalat vágni.
     */
    public void setCutInhibitTime(int cutInhibitTime) {
        this.cutInhibitTime = cutInhibitTime;
    }
}