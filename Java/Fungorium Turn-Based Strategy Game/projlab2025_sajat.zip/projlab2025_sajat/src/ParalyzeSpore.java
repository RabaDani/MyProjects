/**
 * A bénító spórákat reprezentáló osztály, amely a semleges spórák egy speciális típusa.
 * A rovarok elfogyasztva pontot kapnak, de bénulást is szenvednek.
 */
public class ParalyzeSpore extends NeutralSpore{

    /**
     * A ParalyzeSpore osztály konstruktora.
     */
    public ParalyzeSpore(){
    }

    /**
     * Meghívásakor a megadott rovar elfogyasztja a spórát, és pontot kap a tápérték alapján.
     * Ezen kívül bénulást okoz a rovarnak.
     * A spóra ezt követően eltávolításra kerül a játéktérből.
     *
     * @param rovar A rovar, amely elfogyasztja a spórát.
     */
    @Override
    public void getAte(Bug rovar) {
        rovar.increasePoints(nutrient);
        rovar.causesParalyzed();
        GameLogic.removeNeutralSpore(this);
    }
}
