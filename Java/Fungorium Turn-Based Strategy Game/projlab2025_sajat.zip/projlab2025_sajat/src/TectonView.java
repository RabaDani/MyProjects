import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A Tecton objektumok megjelenítéséért felelős osztály.
 * Kezeli a tektonok, gombák, gombafonalak, spórák és rovarok vizuális megjelenítését,
 * valamint a köztük lévő kapcsolatok ábrázolását.
 */
public class TectonView {

    private Tecton tecton;
    private static boolean showTecton = true;
    private static boolean showNames = true;
    private static boolean showThread = true;

    private static double shift_x = 0;
    private static double shift_y = 0;

    private DoublePoint coord;

    /**
     * Eltolást ad hozzá a megjelenítési koordinátákhoz.
     *
     * @param x Vízszintes eltolás mértéke
     * @param y Függőleges eltolás mértéke
     */
    public static void addShift(double x, double y) {
        shift_x = x;
        shift_y = y;
    }

    /**
     * Az objektumok neveinek megjelenítését kapcsolja be/ki.
     */
    public static void toggleShowNames() {
        showNames = !showNames;
    }

    /**
     * A tektonok közötti kapcsolatok megjelenítését kapcsolja be/ki.
     */
    public static void toggleShowTecton() {
        showTecton = !showTecton;
    }

    /**
     * A gombafonalak közötti kapcsolatok megjelenítését kapcsolja be/ki.
     */
    public static void toggleShowThread() {
        showThread = !showThread;
    }

    /**
     * TectonView objektum létrehozása.
     *
     * @param tecton A megjelenítendő Tecton objektum
     * @param coord A megjelenítés kezdeti koordinátái
     */
    public TectonView(Tecton tecton, DoublePoint coord) {
        this.tecton = tecton;
        this.coord = coord;
    }

    /**
     * @return A megjelenített Tecton objektum
     */
    public Tecton getTecton() {
        return tecton;
    }

    /**
     * @return A TectonView pozíciója
     */
    public DoublePoint getPosition() {
        return coord;
    }

    /**
     * Beállítja a TectonView pozícióját.
     * @param position Az új pozíció
     */
    public void setPosition(DoublePoint position) {
        coord = position;
    }

    /**
     * Hozzáad egy relatív pozíciót a jelenlegi pozícióhoz.
     * @param position A hozzáadandó pozíció
     */
    public void addPosition(DoublePoint position) {
        coord.addX(position.getX());
        coord.addY(position.getY());
    }

    /**
     * Beállítja a vízszintes pozíciót.
     * @param x Az új x koordináta
     */
    public void setX(double x) {
        coord.setX(x);
    }

    /**
     * Beállítja a függőleges pozíciót.
     * @param y Az új y koordináta
     */
    public void setY(double y) {
        coord.setY(y);
    }

    /**
     * A tekton teljes megjelenítését végző metódus.
     * Megjeleníti a tektont és az összes rajta lévő objektumot (gombák, fonalak, spórák, rovarok).
     *
     * @param graphics A rajzoláshoz használt Graphics2D objektum
     * @param doneThread A már megrajzolt gombafonalak listája a duplikált rajzolás elkerüléséhez
     * @param tvist Az összes TectonView objektum listája a kapcsolatok rajzolásához
     */
    public void drawTecton(Graphics2D graphics, List<FungalThread> doneThread, ArrayList<TectonView> tvist) {
        // Initialize drawing parameters and positions
        int nameIndex = 1;
        DoublePoint point = coord;

        // Calculate position with current shift
        int x = point.x + (int)shift_x;
        int y = point.y + (int)shift_y;

        // Draw the main tecton image
        graphics.drawImage(GamePanel.images.get(tecton.toString()), x, y, null);

        // Draw tecton name if enabled
        if(showNames) {
            graphics.drawString(GameLogic.getObjectName(tecton), x+105, y+15*nameIndex);
            nameIndex++;
        }

        // Draw tecton neighbor connections
        if(showTecton) {
            drawTectonNeighbors(graphics, tvist, x, y);
        }

        // Draw fungal threads
        HashMap<Tecton, Integer> threadToTecton = new HashMap<>();
        nameIndex = drawFungalThreads(graphics, doneThread, tvist, x, y, nameIndex, threadToTecton);

        // Draw spores
        nameIndex = drawSpores(graphics, x, y, nameIndex);

        // Draw bugs
        drawBugs(graphics, x, y, nameIndex);

        // Draw fungus if present
        drawFungus(graphics, x, y);
    }

    /**
     * A tektonok közötti szomszédsági kapcsolatok megjelenítése.
     */
    private void drawTectonNeighbors(Graphics2D graphics, ArrayList<TectonView> tvist, int x, int y) {
        // Set line style for neighbor connections
        BasicStroke nb_stroke = new BasicStroke(1f);
        graphics.setStroke(nb_stroke);
        graphics.setColor(Color.black);

        List<Tecton> nb = tecton.getNeighbourList();
        for(Tecton n : nb) {
            for(TectonView tv : tvist) {
                if(tv.getTecton() == n) {
                    Point nPoint = tv.getPosition();
                    graphics.drawLine(x+50, y+50,
                                    nPoint.x+50+(int)shift_x,
                                    nPoint.y+50+(int)shift_y);
                }
            }
        }
    }

    /**
     * A gombafonalak és kapcsolataik megjelenítése.
     *
     * @return Az utolsó megjelenített név y-koordinátája
     */
    private int drawFungalThreads(Graphics2D graphics, List<FungalThread> doneThread, ArrayList<TectonView> tvist, int x, int y, int nameIndex, HashMap<Tecton, Integer> threadToTecton) {
        List<FungalThread> threadList = tecton.getThreadList();
        int fth_x = x + 5;
        int fth_y = y + 16;

        // Set line style for thread connections
        BasicStroke conn_stroke = new BasicStroke(4f);

        for(FungalThread fth : threadList) {
            BufferedImage threadDraw = null;
            doneThread.add(fth);

            // Set image and color based on team ID
            if(fth.getTeamID() == 1) {
                threadDraw = GamePanel.images.get("thread1");
                graphics.setColor(Color.BLUE);
            } else if(fth.getTeamID() == 2) {
                threadDraw = GamePanel.images.get("thread2");
                graphics.setColor(Color.YELLOW);
            } else {
                threadDraw = GamePanel.images.get("thread3");
                graphics.setColor(Color.RED);
            }

            // Draw thread connections if enabled
            if(showThread) {
                drawThreadConnections(graphics, doneThread, tvist, x, y, fth, conn_stroke, threadToTecton);
            }

            // Draw thread name if enabled
            if(showNames) {
                if(fth.getGrowTime() > 0)
                    graphics.drawString(GameLogic.getObjectName(fth) + " (gr)", x+105, y+nameIndex*15);
                else
                    graphics.drawString(GameLogic.getObjectName(fth), x+105, y+nameIndex*15);
                nameIndex++;
            }

            // Draw the thread based on fungus connection
            if(fth.getFungus() != null) {
                graphics.drawImage(threadDraw, x + 18, y + 10, null);
            } else {
                graphics.drawImage(threadDraw, fth_x, fth_y, null);
                fth_x += 10;
            }
        }
        graphics.setColor(Color.black);
        return nameIndex;
    }

    /**
     * A gombafonalak közötti kapcsolatok megjelenítése.
     * A kapcsolatok irányától függően különböző módon rajzolja meg a vonalakat.
     */
    private void drawThreadConnections(Graphics2D graphics, List<FungalThread> doneThread, ArrayList<TectonView> tvist, int x, int y, FungalThread fth, BasicStroke stroke, HashMap<Tecton, Integer> threadToTecton) {
        List<FungalThread> threads = fth.getConnections().stream().toList();
        graphics.setStroke(stroke);

        for(FungalThread f : threads) {
            if(!doneThread.contains(f)) {
                Tecton f_tecton = f.getTecton();
                Point otherPoint = new Point(0,0);

                // Find the position of the connected tecton
                for(TectonView tv : tvist) {
                    if(tv.getTecton() == f_tecton) {
                        otherPoint = tv.getPosition();
                        break;
                    }
                }

                int conNum = threadToTecton.get(f_tecton) == null ? 0 : threadToTecton.get(f_tecton);
                threadToTecton.put(f_tecton, conNum + 1);

                // Calculate direction parameters
                int dx = otherPoint.x+(int)shift_x - x;
                int dy = otherPoint.y+(int)shift_y - y;
                double dd = 0;
                if(dx != 0)
                    dd = dy/(double) dx;

                // Draw connection line based on direction
                if(dx > 0 && dd < 1 && dd > -1) {
                    graphics.drawLine(x+100, y+40+conNum*10, otherPoint.x+(int)shift_x, otherPoint.y+40+conNum*10+(int)shift_y);
                } else if(dy > 1 && (dd >= 1 || dd <= -1 || dx == 0)) {
                    graphics.drawLine(x+40+conNum*10, y+100, otherPoint.x+(int)shift_x+40+conNum*10, otherPoint.y+(int)shift_y);
                } else if(dx < 0 && dd < 1 && dd > -1) {
                    graphics.drawLine(x, y+40+conNum*10, otherPoint.x+100+(int)shift_x, otherPoint.y+40+conNum*10+(int)shift_y);
                } else {
                    graphics.drawLine(x+40+conNum*10, y, otherPoint.x+40+conNum*10+(int)shift_x, otherPoint.y+100+(int)shift_y);
                }
            }
        }
    }

    /**
     * A spórák megjelenítése.
     *
     * @return Az utolsó megjelenített név y-koordinátája
     */
    private int drawSpores(Graphics2D graphics, int x, int y, int nameIndex) {
        List<NeutralSpore> sporeList = tecton.getSporeList();
        int spore_x = x + 10;
        int spore_y = y + 70;

        for(NeutralSpore s : sporeList) {
            graphics.drawImage(GamePanel.sporeDraw, spore_x, spore_y, null);

            spore_x += 100/sporeList.size();
        }

        return nameIndex;
    }

    /**
     * A rovarok megjelenítése.
     * A rovarokat csoportokban rendezi el, és megjeleníti a nevüket, ha engedélyezve van.
     */
    private void drawBugs(Graphics2D graphics, int x, int y, int nameIndex) {
        List<Bug> bugList = tecton.getBugList();
        int bug_x = x + 13;
        int bug_y = y + 35;

        for(Bug bugy : bugList) {
            BufferedImage bDraw = null;
            if(bugy.getTeamID() == 4)
                bDraw = GamePanel.images.get("bug1");
            else if(bugy.getTeamID() == 5)
                bDraw = GamePanel.images.get("bug2");
            else
                bDraw = GamePanel.images.get("bug3");

            graphics.drawImage(bDraw, bug_x, bug_y, null);

            if(showNames)
                graphics.drawString(GameLogic.getObjectName(bugy), bug_x, bug_y);

            if(bug_x < x + 100 - 55) {
                bug_x += 30;
            } else {
                bug_x = x;
                bug_y += 30;
            }
        }
    }

    /**
     * A gomba megjelenítése, ha van a tektonon.
     * A gomba színe a csapat azonosítója alapján kerül meghatározásra.
     */
    private void drawFungus(Graphics2D graphics, int x, int y) {
        if(tecton.getFungus() != null) {
            Fungus f = tecton.getFungus();
            BufferedImage fungusDraw = null;

            if(f.getTeamID() == 1)
                fungusDraw = GamePanel.images.get("fungus1");
            else if(f.getTeamID() == 2)
                fungusDraw = GamePanel.images.get("fungus2");
            else
                fungusDraw = GamePanel.images.get("fungus3");

            graphics.drawImage(fungusDraw, x + 35, y + 20, null);

            if(showNames)
                graphics.drawString(GameLogic.getObjectName(f), x + 35, y + 20);
        }
    }
}
