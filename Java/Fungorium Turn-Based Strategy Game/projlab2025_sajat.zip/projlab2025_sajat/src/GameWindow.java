
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * A játék ablakának osztálya
 */
public class GameWindow {

    public final int WIDTH = 1600;
    public final int HEIGTH = 900;
    public JFrame window;
    public GameMenu menu;
    public GamePanel gamePanel;
    public ScorePanel scorePanel;

    /**
     * Konstrukor ami meghívja az inícializáló függvényt.
     */
    public  GameWindow() {
        initWindow();
    }

    /**
     * Létrehozza az ablakot és beállítja a kezdeti paramétereit.
     * Az ablak létrehozása után beolvassa a játék progilokat és ranglistát,
     * majd meghívja a menüt létrehozó függvényt.
     */
    public void initWindow() {
        window = new JFrame();
        window.setTitle("Fungorium");
        window.setResizable(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addMenu();
    }

    /**
     * A Menü paneljét létrehozó függvény.
     * Ha volt játékpanel létrehozva, akkor megszűnteti azt.
     * Beállítja a menüpanelhez az ablak paramétereit.
     */
    public void addMenu() {
        if(scorePanel != null) {
            window.remove(scorePanel);
            scorePanel = null;
        }
        if(gamePanel != null) {
            window.remove(gamePanel);
            gamePanel = null;
        }
        menu = new GameMenu(this);
        window.setSize(400, 500);
        window.setLocationRelativeTo(null);
        window.getContentPane().setPreferredSize(menu.getMenuDimension());
        window.add(menu, BorderLayout.CENTER);
        window.pack();
        window.setVisible(true);
    }

    /**
     * A játék paneljét létrehozó függvény.
     * Ha volt menüpanel létrehozva, akkor megszűnteti azt.
     * Beállítja a jatékpanelhez az ablak paramétereit.
     */
    public void addGamePanel() {
        if(menu != null) {
            window.remove(menu);
            menu = null;
        }
        gamePanel = new GamePanel(this);
        window.add(gamePanel, BorderLayout.CENTER);
        window.setSize(WIDTH, HEIGTH);
        window.setLocationRelativeTo(null);
        window.getContentPane().setPreferredSize(gamePanel.getScreenDimension());
        window.pack();
        window.setVisible(true);

        gamePanel.setFocusable(true);
        gamePanel.requestFocusInWindow();

    }

    public void addScorePanel() {
        if(gamePanel != null) {
            window.remove(gamePanel);
            gamePanel = null;
        }
        scorePanel = new ScorePanel(this);
        window.add(scorePanel, BorderLayout.CENTER);
        window.setSize(WIDTH, HEIGTH);
        window.setLocationRelativeTo(null);
        window.pack();
        window.setVisible(true);
    }
}
