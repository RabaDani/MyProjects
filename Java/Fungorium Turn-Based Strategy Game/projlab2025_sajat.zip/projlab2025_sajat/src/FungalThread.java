import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;


/**
 * A FungalThread osztály a gombafonalakat reprezentálja, amelyek a Tectonok között
 * nőnek és terjednek. A gombafonalak kapcsolatokat létesíthetnek más fonalakkal
 */
public class FungalThread implements Serializable {

    private Tecton tecton;
    private LinkedHashSet<FungalThread> connections;
    private Fungus fungus;
    private int teamID;
    private int tectonDissolvingTime;
    private int growTime;
    private int fungusFreeTime;

    /**
     * Létrehoz egy új FungalThread példányt, és inicializálja az üres kapcsolatokat.
     */
    public FungalThread() {
        //tecton = new Tecton();
        connections = new LinkedHashSet<FungalThread>();
        //fungus = new Fungus();

        tectonDissolvingTime = 3;
        growTime = 3;
        fungusFreeTime = 3;
        teamID = -1;
    }

    /**
     * Hozzáad egy másik gombafonalat a kapcsolatokhoz.
     *
     * @param other A másik FungalThread példány, amelyhez kapcsolatot hozunk létre.
     */
    public void addConnection(FungalThread other) {
        connections.add(other);
    }

    /**
     * Eltávolít egy meglévő kapcsolatot egy másik gombafonallal.
     *
     * @param other A másik FungalThread példány, amelyet törölni szeretnénk a kapcsolatokból.
     */
    public void removeConnection(FungalThread other) {
        connections.remove(other);
    }

    /**
     * Ellenőrzi, hogy a jelenlegi gombafonal egy másikhoz kapcsolódva elérhet-e egy gombát.
     *
     * @param visited A már meglátogatott FungalThread-ek listája a ciklusok elkerülése érdekében.
     * @return Igaz, ha a fonal eléri egy gomba példányát, egyébként hamis.
     */
    public boolean canReachMushroom(Set<FungalThread> visited) {

        if(visited == null) {
            visited = new HashSet<>();
        }

        if(visited.contains(this)) {
            return false;
        }

        visited.add(this);

        if(growTime > 0) {
            return false;
        }

        if(fungus != null) {
            return true;
        }

        for(FungalThread other : connections) {
            if(other.canReachMushroom(visited)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Megpróbál egy új gombát növeszteni, ha a feltételek adottak.
     *
     * @return Igaz, ha sikerült a gomba növesztése, egyébként hamis.
     */
    public boolean growFungus() {
        //TODO hiányzott innen egy growTime ellenőrzés
        if(growTime > 0) {
            GameLogic.addInnerError("-thread is still growing");
            return false;
        }
        if(tecton != null) {
            boolean res = tecton.removeSporesToGrowFungus();
            if(res) {
                Fungus g = new Fungus();
                tecton.setFungus(g);
                g.setTecton(tecton);
                g.setFungalThread(this);
                g.setTeamID(teamID);
                fungus = g;

                //TODO ez nem volt itt eredetileg
                GameLogic.addFungus(g);
                GameLogic.addPoints(teamID, 1);
                return true;
            }
        }
        return false;
    }

    /**
     * Ha a feloldódási idő (dissolving time) 0, akkor meghívja a die() metódust.
     */
    public void dissolve() {
        tectonDissolvingTime--;
        if(tectonDissolvingTime == 0) {
            die();
        }
    }

    /**
     * Megkeresi és visszaadja a cél Tecton-hoz tartozó FungalThread kapcsolatot.
     * Ha a fonal növekedési ideje (growTime) nagyobb mint 0, vagy ha a kapcsolat növekszik, akkor null-t ad vissza.
     *
     * @param dest A célként megadott Tecton
     * @return A kapcsolatot jelölő FungalThread vagy null, ha nincs kapcsolat
     */
    public FungalThread getConnectionTo(Tecton dest) {
        if(growTime > 0) {
            return null;
        }

        for(FungalThread other : connections) {
            if(other.getTecton() == dest) {
                if(other.isGrowing()) {
                    return null;
                } else {
                    return other;
                }
            }
        }
        return null;
    }

    /**
     * Elvágja a kapcsolatot egy adott Tecton irányába.
     * Ha létezik ilyen kapcsolat, akkor eltávolítja azt.
     *
     * @param dest A célként megadott Tecton
     * @return Igaz, ha a kapcsolat sikeresen megszűnt, egyébként hamis
     */
    public boolean cutConnectionTo(Tecton dest) {
        FungalThread other = getConnectionTo(dest);
        if(other != null) {
            other.removeConnection(this);
            connections.remove(other);
            return true;
        }
        return false;
    }

    /**
     * Megpróbál létrehozni egy új fonal kapcsolatot egy cél Tecton felé.
     * Csak akkor sikeres, ha a fonal növekedési ideje 0, és a cél Tecton szomszédos.
     *
     * @param dest A célként megadott Tecton
     * @return Igaz, ha a kapcsolat sikeresen létrejött, egyébként hamis
     */
    public boolean growFungalThread(Tecton dest) {
        if(growTime > 0) {
            GameLogic.addInnerError("-thread is still growing");
            return false;
        } else if(tecton == null || dest == null || !tecton.isNeighbour(dest)) {
            GameLogic.addInnerError("-tecton is not neighbour");
            return false;
        }
        
        FungalThread growingThread = new FungalThread();
        growingThread.teamID = this.teamID;

        FungalThread resultThread = dest.addFungalThread(growingThread);
        
        if(resultThread != null) {
            if(resultThread == growingThread) {
                growingThread.addConnection(this);
                connections.add(growingThread);
                GameLogic.addFungalThread(growingThread);
                return true;
            } else if(!connections.contains(resultThread)) {
                resultThread.addConnection(this);
                connections.add(resultThread);
                return true;
            } else {
                GameLogic.addInnerError("-thread already present");
                return false;
            }
        }

        return false;
    }

    /**
     * Csökkenti a fonal növekedési idejét.
     */
    public void reduceGrowTime() {
        if (growTime > 0) {
            growTime -= 1;
        }
    }

    /**
     * Elpusztítja a jelenlegi fonalat, eltávolítja az összes kapcsolatot,
     * valamint törli a hozzátartozó Tecton és Fungus referenciákat.
     */
    public void die() {

        LinkedHashSet<FungalThread> connectionList = new LinkedHashSet<>(connections);
        for(FungalThread other : connectionList) {
            other.removeConnection(this);
        }
        connections.clear();

        if(tecton != null) {
            tecton.removeFungalThread(this);
            tecton = null;
        }

        if(fungus != null) {
            fungus.setFungalThread(null);
            fungus = null;
        }
        GameLogic.removeFungalThread(this);
    }

    /**
     * Megeszi a tektonján lévő bénított rovarokat és megprobál gombát növeszteni,
     * ha legalább egy rovart megevett.
     * @return Igazzal tér vissza, ha legalább egy rovart megevett, különben hamis
     */
    public boolean eatBugs() {
        
        if (tecton == null) {
            return false;
        }

        if (growTime > 0) {
            GameLogic.addInnerError("-thread is still growing");
            return false;
        }

        boolean res = tecton.removeBugsToGrowFungus();

        if (res && tecton.getFungus() == null && tecton.getMaxFungus() > 0) {
            Fungus f = new Fungus();
            f.setTecton(tecton);
            tecton.setFungus(f);

            f.setFungalThread(this);
            this.setFungus(f);

            GameLogic.addFungus(f);

            if (this.teamID != -1) {
                f.setTeamID(this.teamID);
            }
        }

        return res;
    }

    /**
     * Frissíti az objektum állapotát.
     * Ha a növekedési idő (growTime) 0 és nincs hozzátartozó gomba,
     * ellenőrzi, hogy elérhető-e egy másik gomba.
     * Ha nem, és a fungusFreeTime is 0, akkor meghívja a die() metódust.
     */
    public void update() {
        if(growTime > 0)
             growTime--;
        if(growTime == 0 && fungus == null) {
            Set<FungalThread> visited = new LinkedHashSet<>();
            visited.add(this);
            for (FungalThread other : connections) {
                if(other.canReachMushroom(visited)) {
                    return;
                }
            }
            fungusFreeTime--;
            if (fungusFreeTime == 0)
                die();
        }
    }

    /**
     * Megvizsgálja, hogy a fonal éppen növekedésben van-e.
     * Ha a növekedési idő (growTime) nagyobb mint 0, akkor igazat ad vissza.
     *
     * @return Igaz, ha a fonal növekedés alatt áll, egyébként hamis
     */
    public boolean isGrowing() {
        if(growTime > 0) {
            return true;
        }
        return false;
    }

    /**
     * Növeli a fungusFreeTime értékét, így gyógyítja a fonalat,
     * ha nincs kapcsolatban gombával a fonál.
     */
    public void heal() {
        if(fungusFreeTime < 3)
        fungusFreeTime = 3;
    }

    /**
     * Visszaadja a gombafonalhoz kapcsolódó Tectont.
     *
     * @return A kapcsolódó Tecton példány.
     */
    public Tecton getTecton() {
        return tecton;
    }

    /**
     * Beállítja azt a Tectont, amelyhez a gombafonal kapcsolódik.
     *
     * @param tecton A Tecton példány, amelyhez a gombafonal kapcsolódik.
     */
    public void setTecton(Tecton tecton) {
        this.tecton = tecton;
    }


    /**
    * Visszaadja a gombafonal kapcsolatainak listáját.
    */
    public LinkedHashSet<FungalThread> getConnections() {
        return connections;
    }

    /**
    * Beállítja a gombafonal kapcsolatainak listáját.
    */
    public void setConnections(LinkedHashSet<FungalThread> connections) {
        this.connections = connections;
    }

    /**
     * Visszaadja a gombát, amelyhez ez a gombafonal tartozik.
     */
    public Fungus getFungus() {
        return fungus;
    }

    /**
     * Beállítja azt a gombát, amelyhez ez a gombafonal tartozik.
     *
     */
    public void setFungus(Fungus fungus) {
        this.fungus = fungus;
    }

    /**
    * Visszaadja a gombafonal csapatának azonosítóját.
    */
    public int getTeamID() {
        return teamID;
    }

    /**
    * Beállítja a gombafonal csapatának azonosítóját.
    */
    public void setTeamID(int id) {
        teamID = id;
    
    }

    /**
    * Visszaadja a tekton feloldásának hátralévő idejét.
    */
    public int getTectonDissolvingTime() {
        return tectonDissolvingTime;
    }

    /**
    * Beállítja a tekton feloldásának hátralévő idejét.
    */
    public void setTectonDissolvingTime(int tectonDissolvingTime) {
        this.tectonDissolvingTime = tectonDissolvingTime;
    }

    /**
    * Visszaadja a gombafonal növekedéséhez szükséges hátralévő időt.
    */
    public int getGrowTime() {
        return growTime;
    }

    /**
    * Beállítja a gombafonal növekedéséhez szükséges hátralévő időt.
    */
    public void setGrowTime(int growTime) {
        this.growTime = growTime;
    }

    /**
    * Visszaadja a fonál gombatest kapcsolat nélküli maximális életidejét.
    */
    public int getFungusFreeTime() {
        return fungusFreeTime;
    }

    /**
    * Beállítja a fonál gombatest kapcsolat nélküli maximális életidejét.
    */
    public void setFungusFreeTime(int fungusFreeTime) {
        this.fungusFreeTime = fungusFreeTime;
    }

}
