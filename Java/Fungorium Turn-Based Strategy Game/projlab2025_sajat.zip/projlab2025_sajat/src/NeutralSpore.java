import java.io.Serializable;
import java.util.Random;

/**
 * A semleges spórákat reprezentáló osztály.
 * A semleges spórákat a rovarok elfogyaszthatják, amivel pontokat szereznek.
 * A spórák tápértéke (nutrient) véletlenszerűen generálható vagy rögzített lehet,
 * */
public class NeutralSpore implements Serializable {
    /** A spóra tápértéke, amely meghatározza, hány pontot kap a rovar, ha elfogyasztja.*/
    int nutrient;
    /**
     * A NeutralSpore osztály konstruktora.
     * A tápértéket vagy véletlenszerűen 1 és 5 közötti értékre állítja, vagy 1-re.
     */
    public NeutralSpore() {
        if(GameLogic.getRandom())
            nutrient = new Random().nextInt(5) + 1;
        else
            nutrient = 1;
    }

    /**
     * Meghívásakor a megadott rovar elfogyasztja a spórát, és pontot kap a tápérték alapján.
     * A spóra ezt követően eltávolításra kerül a játéktérből.
     *
     * @param rovar A rovar, amely elfogyasztja a spórát.
     */
    public void getAte(Bug rovar) {
        rovar.increasePoints(nutrient);
        GameLogic.removeNeutralSpore(this);
    }

    /**
     * Visszaadja a spóra aktuális tápértékét.
     *
     * @return A spóra tápértéke.
     */
    public  int getNutrient() {return nutrient;}

    /**
     * Beállítja a spóra tápértékét a megadott értékre.
     *
     * @param n Az új tápérték.
     */
    public void setNutrient(int n) {nutrient = n;}

}
