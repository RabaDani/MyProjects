import org.w3c.dom.css.RGBColor;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;


/**
 * A játék panelének osztálya.
 */
public class GamePanel extends JPanel{
    private int WIDTH = 1600;
    private int HEIGTH = 900;
    private GameKeyListener gameKL;
    public GameMouseListener gameML;
    public GameWindow gameWindow;
    private static double shift_x = 0;
    private static double shift_y = 0;
    public double scale = 1;
    public int actualPlayer = -1;
    public int maxPlayer = -1;
    public List<Bug> teamBugs;
    public List<FungalThread> teamThreads;
    public List<Fungus> teamFunguses;
    private boolean dragged = false;
    public Tecton selectedTecton;

    public ArrayList<TectonView> tvList = new ArrayList<>();

    private static List<BufferedImage> fungusPlayerImages = new ArrayList<>();
    private static List<BufferedImage> bugPlayerImages = new ArrayList<>();


    public static HashMap<String, BufferedImage> images = new HashMap<>();
    public static BufferedImage sporeDraw;

    private int theme;

    public void changeTheme()
    {
        theme++;
        if(theme == 4)
            theme = 0;
        refreshScreen();
    }

    private void getTheme(Graphics2D graphics)
    {
        if(theme == 0)
        {
            setBackground(new Color(0x87CEEB));
            graphics.setColor(Color.BLACK);
            sporeDraw = images.get("spore4");
        } else if(theme == 1)
        {
            setBackground(new Color(0xFFFFFF));
            graphics.setColor(Color.BLACK);
            sporeDraw = images.get("spore3");
        } else if(theme == 2)
        {
            setBackground(new Color(0x191970));
            graphics.setColor(Color.WHITE);
            sporeDraw = images.get("spore2");
        } else if(theme == 3)
        {
            setBackground(new Color(0x580505));
            graphics.setColor(Color.WHITE);
            sporeDraw = images.get("spore1");
        }
    }
    /**
     * Betölti az objektumokhoz szükséges képeket
     */
    static {
        String[] imageNames = {
            "tecton", "dissolvingtecton", "savingtecton", "bug1", "bug2", "bug3",
            "thread1", "thread2", "thread3", 
            "fungus1", "fungus2", "fungus3", 
            "spore1", "spore2", "spore3", "spore4", 
            "shootspore", "growfungus", "growthread_fungus", "growthread_thread", 
            "dissolve", "skip", "move", "eat", "cut", 
            "load", "save", "exit"
        };

        try {
            for (String name : imageNames) {
                File file = new File("./assets/png/" + name + ".png");
                BufferedImage image = ImageIO.read(ImageIO.createImageInputStream(file));
                images.put(name, image);
            }

            sporeDraw = images.get("spore3");

            fungusPlayerImages.add(images.get("skip"));
            fungusPlayerImages.add(images.get("growfungus"));
            fungusPlayerImages.add(images.get("shootspore"));
            fungusPlayerImages.add(images.get("growthread_fungus"));
            fungusPlayerImages.add(images.get("growthread_thread"));
            fungusPlayerImages.add(images.get("dissolve"));

            bugPlayerImages.add(images.get("skip"));
            bugPlayerImages.add(images.get("cut"));
            bugPlayerImages.add(images.get("eat"));
            bugPlayerImages.add(images.get("move"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private DoublePoint nextPoint = new DoublePoint(0, 0);
    private int max_x = 0;
    private int max_y = 0;

    /**
     * Kiosztja a következő újonnan hozzáadott tektonnak a következő koordinátát és kiszámolja a következő kiosztandó koordinátát.
     * @param tecton
     */
    public void addTecton(Tecton tecton) {
        tvList.add(new TectonView(tecton,nextPoint));
        if(nextPoint.x > max_x) {
            max_x = nextPoint.x;
        }
        if(nextPoint.y > max_y) {
            max_y = nextPoint.y;
        }

        if(max_x == nextPoint.x && max_y == nextPoint.y && max_x <= max_y) {
            nextPoint = new DoublePoint(max_x + 200, 0);
        } else if(nextPoint.x == max_x && max_y > nextPoint.y) {
            nextPoint = new DoublePoint(nextPoint.x, nextPoint.y + 200);
        } else if(max_x == nextPoint.x && max_y == nextPoint.y && max_x > max_y) {
            nextPoint = new DoublePoint(0, max_y + 200);
        } else {
            nextPoint = new DoublePoint(nextPoint.x+200, nextPoint.y);
        }

    }

    /**
     * Eltávolítja az adott tektont a panelről
     * @param tecton
     */
    public void removeTecton(Tecton tecton) {
        List<TectonView> tvs = new ArrayList<>(tvList);
        for(TectonView tv : tvs) {
            if(tv.getTecton() == tecton) {
                tvList.remove(tv);
            }
        }

    }

    /**
     * A GamePanel konstuktora.
     * Menti a tulajdonos ablakot. Beállítja a panel méretét, focusát, és hozzáadja a billentyűzet és egér figyelőket.
     * Meghívja a play függvényt, ami a játék futtatását kezdi.
     * @param gameWindow A játékablak, amin a panel található.
     */
    public GamePanel(GameWindow gameWindow) {

//        setSize(WIDTH, HEIGTH);
        setDoubleBuffered(true);
        setVisible(true);

        gameKL = new GameKeyListener(this);
        gameML = new GameMouseListener(this);
        addKeyListener(gameKL);
        addMouseListener(gameML);
        addMouseMotionListener(gameML);
        addMouseWheelListener(gameML);
        this.gameWindow = gameWindow;
        GameLogic.setGamePanel(this);
        setBackground(new Color(0x87CEEB));
    }

    /**
     * Frissíti az ablakot.
     */
    public void refreshScreen() {
        WIDTH = gameWindow.window.getContentPane().getWidth();
        HEIGTH = gameWindow.window.getContentPane().getHeight();
        this.repaint();
    }

    /**
     * A menübe visszatérés függvénye, ami meghívja a főablak menü függvényét.
     */
    public void returnToMenu() {
        gameWindow.addMenu();
    }

    /**
     * A gameWindow-hoz hozzáadja a Score Panel. Játék végéhez szükséges metódus
     */
    public void endGame() {
        gameWindow.addScorePanel();
    }

    /**
     * !!! A JPanel beépített függvénye !!!
     * A komponensek megjelenítéséért felelős függvény.
     * @param g the <code>Graphics</code> object to protect
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D graphics = (Graphics2D) g;

        draw(graphics);

        graphics.dispose();
    }

    /**
     * A játék grafikus felületének kirajzolását végző metódus.
     *
     * A metódus a következő elemeket rajzolja ki:
     * - Tektonok és a hozzájuk kapcsolódó gombafonalak
     * - Játékállás információk (kör száma, hátralévő akciók)
     * - Játékos információk (aktív játékos, játékos típusa)
     * - Vezérlő gombok (mentés, betöltés, kilépés)
     * - Kiválasztott elemek állapota
     * - Félig átlátszó információs panel háttér
     *
     * A rajzolás csak akkor történik meg, ha a tekton nézetek listája (tvList) nem null.
     * A metódus kezeli a nagyítás/kicsinyítés (scale) és eltolás (shift) műveleteket is.
     *
     * @param graphics A Graphics2D objektum, amelyre a rajzolás történik
     */
    public void draw(Graphics2D graphics) {
        getTheme(graphics);
        if(tvList != null) {
            graphics.scale(scale, scale);
            TectonView.addShift(shift_x, shift_y);

            // Segéslista a már kirajzol fonalkapcsolatok tárolására
            List<FungalThread> doneThread = new ArrayList<FungalThread>();

            // Bejárjuk a tektonok listáját és azoknak megfelelően rajzolunk ki
            for(TectonView tv : tvList) {
                tv.drawTecton(graphics, doneThread, tvList);
            }

            graphics.scale(1/scale, 1/scale);

            actualPlayer = GameLogic.getActualPlayer();
            maxPlayer = GameLogic.getPlayerNumber();
            int round = GameLogic.getActualRound();
            graphics.setFont(new Font("Arial", Font.PLAIN, 18));

            graphics.drawString("Round: "+round+" Actions left: "+GameLogic.getActionCounter(), 0, 15);

            graphics.drawImage(images.get("save"),0, HEIGTH-50, null);
            graphics.drawImage(images.get("load"), 200, HEIGTH-50, null); //SAVE LOAD
            graphics.drawImage(images.get("exit"), 400, HEIGTH-50, null);

            if(actualPlayer > 0 && actualPlayer <= maxPlayer)
            {
                graphics.drawString("Player: FungusPlayer"+actualPlayer, 0, 40);
                for(int i = 0; i < fungusPlayerImages.size();i++) {
                    graphics.drawImage(fungusPlayerImages.get(i), WIDTH-200, i*50, null);
                    graphics.drawLine(WIDTH-200, i*50, WIDTH, i*50);
                }
            } else if(actualPlayer > maxPlayer && actualPlayer <= maxPlayer*2) {
                graphics.drawString("Player: BugPlayer"+actualPlayer, 0, 40);
                for(int i = 0; i < bugPlayerImages.size();i++) {
                    graphics.drawImage(bugPlayerImages.get(i), WIDTH-200, i*50, null);
                    graphics.drawLine(WIDTH-200, i*50, WIDTH, i*50);
                }
            }
            if(GameLogic.isFungusTurn()) {
                graphics.drawString("Fungus action: "+GameLogic.fAct, 0, 65);
                graphics.drawString("selected thread: "+GameLogic.getObjectName(GameLogic.selectedThread), 0, 90);

                graphics.drawString("selected fungus: "+GameLogic.getObjectName(GameLogic.selectedFungus), 0, 115);
                graphics.drawString("selected tecton: "+GameLogic.getObjectName(GameLogic.selectedTecton), 0, 140);
            } else {
                graphics.drawString("Bug action: "+GameLogic.bAct, 0, 65);
                graphics.drawString("selected bug: "+GameLogic.getObjectName(GameLogic.selectedBug), 0, 90);
                graphics.drawString("selected tecton: "+GameLogic.getObjectName(GameLogic.selectedTecton), 0, 115);
            }

            // Átlátszó szürke: RGB (128,128,128), alfa 128 (0–255 skála)
            graphics.setColor(new Color(128, 128, 128, 128)); // 50% átlátszóság
            graphics.fillRect(0, 0, 350, 150);
        }
    }

    /**
     * A panel méretét visszaadó függvény.
     * @return Az ablak dimenzióját adja vissza.
     */
    public Dimension getScreenDimension() {
        return new Dimension(this.WIDTH,this.HEIGTH);
    }

    /**
     * A tektonok megjelenítését kapcsolja be/ki.
     * A metódus meghívása után a képernyő frissítésre kerül,
     * hogy a változások azonnal láthatóak legyenek.
     */
    public  void toggleTecton() {

        TectonView.toggleShowTecton();

        refreshScreen();
    }

    /**
     * A gombafonalak megjelenítését kapcsolja be/ki.
     * A metódus meghívása után a képernyő frissítésre kerül,
     * hogy a változások azonnal láthatóak legyenek.
     */
    public  void toggleThread() {
        TectonView.toggleShowThread();
        refreshScreen();
    }

    /**
     * Az elemek neveinek megjelenítését kapcsolja be/ki.
     * A metódus meghívása után a képernyő frissítésre kerül,
     * hogy a változások azonnal láthatóak legyenek.
     */
    public void toggleName() {
        TectonView.toggleShowNames();
        refreshScreen();
    }


    /**
     * A játéktér vagy a kiválasztott tekton eltolását végző metódus.
     * Ha nincs kiválasztott tekton, akkor az egész játékteret tolja el,
     * egyébként csak a kiválasztott tektont mozgatja.
     *
     * @param x Vízszintes eltolás mértéke pixelben
     * @param y Függőleges eltolás mértéke pixelben
     */
    public void shift(int x, int y) {
        dragged = true;
        double dx = x / scale;
        double dy = y / scale;
        if(selectedTecton == null) {
            shift_x += dx;
            shift_y += dy;
        } else {
            for(TectonView tv : tvList) {
                if(tv.getTecton() == selectedTecton) {
                    DoublePoint p = tv.getPosition();
                    //TODO rovarok poz módosítása
                    p.setX(p.d_x += dx);
                    p.setY(p.d_y += dy);
                    break;
                }
            }
        }
        refreshScreen();
    }

    /**
     * Kiválaszt egy tektont az adott koordinátán történő kattintás alapján.
     *
     * @param x A kattintás vízszintes koordinátája
     * @param y A kattintás függőleges koordinátája
     */
    public void clickTecton(int x, int y) {
        selectedTecton = selectTecton(x, y);
    }

    /**
     * A játékban történő kattintásokat kezelő metódus.
     * Kezeli a különböző játékelemek kiválasztását, akciókat és menügombokat.
     * A metódus szinkronizált a többszálú működés biztonságos kezelése érdekében.
     *
     * Lehetséges műveletek:
     * - Játékos akciók kiválasztása
     * - Játékelemek (rovar, tekton, gombafonal, gomba) kiválasztása
     * - Játék mentése/betöltése
     * - Menü megnyitása
     *
     * @param x A kattintás vízszintes koordinátája
     * @param y A kattintás függőleges koordinátája
     */
    synchronized public void clickOption(int x, int y) {
        if (dragged) {
            return;
        }
        if(x >= WIDTH-200 && x <= WIDTH && y >= 0 && y <= bugPlayerImages.size()*50 && actualPlayer > maxPlayer && actualPlayer <= maxPlayer*2) {
            actionSelect(x, y);
            deselect();
            refreshScreen();

        } else if(x >= WIDTH-200 && x <= WIDTH && y >= 0 && y <= fungusPlayerImages.size()*50 && actualPlayer > 0 && actualPlayer <= maxPlayer) {
            actionSelect(x, y);
            deselect();
            refreshScreen();
        } else if(GameLogic.dataNeeded == DataNeeded.BUG) {
            selectBug(x, y);
            refreshScreen();
        } else if(GameLogic.dataNeeded == DataNeeded.TECTON) {
            Tecton tecton = selectTecton(x, y);
            if(tecton != null) {
                GameLogic.selectTecton(tecton);
                refreshScreen();
            }
        } else if(GameLogic.dataNeeded == DataNeeded.THREAD) {
            selectThread(x, y);
            refreshScreen();
        } else if(GameLogic.dataNeeded == DataNeeded.FUNGUS) {
            selectFungus(x, y);
            refreshScreen();
        } else if(x > 0 && x <= 200 && y >= HEIGTH-50 && y <= HEIGTH) {
           GameLogic.saveGame();
           refreshScreen();
        }  else if(x > 200 && x <= 400 && y >= HEIGTH-50 && y <= HEIGTH) {
            GameLogic.loadGame();
            refreshScreen();
        }
        else if(x > 400 && x <= 600 && y >= HEIGTH-50 && y <= HEIGTH) {
            gameWindow.addMenu();
            refreshScreen();
        }
    }

    /**
     * Kiválaszt egy tektont az adott koordináták alapján.
     * A koordináták a játéktér nagyítását és eltolását is figyelembe veszik.
     *
     * @param x A kiválasztás vízszintes koordinátája
     * @param y A kiválasztás függőleges koordinátája
     * @return A kiválasztott Tecton objektum, vagy null ha nincs tekton a megadott pozíción
     */
    public Tecton selectTecton(int x, int y) {
        double dx = x / scale;
        double dy = y / scale;

        dx = dx - shift_x;
        dy = dy - shift_y;

        for(TectonView tv : tvList) {
            DoublePoint p = tv.getPosition();

            if(p.d_x <= dx && p.d_y <= dy && p.d_x+100 >= dx && p.d_y+100 >= dy) {
                return tv.getTecton();
            }
        }
        return null;
    }

    /**
     * A játékosok által választható akciók kezelését végző metódus.
     * A metódus szinkronizált a többszálú működés biztonságos kezelése érdekében.
     *
     * Gombász játékos akciói:
     * - Kihagyás (Skip)
     * - Gomba növesztése
     * - Spóra kilövése
     * - Gombafonal növesztése gombából
     * - Gombafonal növesztése fonalból
     * - Rovar feloldása
     *
     * Rovarász játékos akciói:
     * - Kihagyás (Skip)
     * - Vágás
     * - Evés
     * - Mozgás
     *
     * @param x A kiválasztás vízszintes koordinátája
     * @param y A kiválasztás függőleges koordinátája
     */
    synchronized public void actionSelect(int x, int y) {
        if(y >= 0 && y <= 50) {
            System.out.println("SKIP");
            selectedAction = 0;
            action = "Skip";
            GameLogic.selectAction(0);
        }
        if(actualPlayer > 0 && actualPlayer <= maxPlayer) {
            if(y > 50 && y <= 100) {
                System.out.println("grow fungus");
                selectedAction = 1;
                action = "grow fungus";
                GameLogic.selectAction(1);
            } else if(y > 100 && y <= 150) {
                System.out.println("shoot spore");
                selectedAction = 2;
                action = "shoot spore";
                GameLogic.selectAction(2);
            } else if(y > 150 && y <= 200) {
                System.out.println("grow thread from fungus");
                selectedAction = 3;
                action = "grow thread from fungus";
                GameLogic.selectAction(3);
            } else if(y > 200 && y <= 250) {
                System.out.println("grow thread from thread");
                selectedAction = 4;
                action = "grow thread from thread";
                GameLogic.selectAction(4);
            } else if(y > 250 && y <= 300) {
                System.out.println("Dissolve bug");
                selectedAction = 5;
                action = "Dissolve bug";
                GameLogic.selectAction(5);
            }
        } else if(actualPlayer > maxPlayer && actualPlayer <= maxPlayer*2) {
            if(y > 50 && y <= 100) {
                System.out.println("CUT");
                selectedAction = 1;
                action = "cut";
                GameLogic.selectAction(6);

            } else if(y > 100 && y <= 150) {
                System.out.println("EAT");
                selectedAction = 2;
                action = "eat";
                GameLogic.selectAction(7);

            } else if(y > 150 && y <= 200) {
                System.out.println("MOVE");
                selectedAction = 3;
                action = "move";
                GameLogic.selectAction(8);

            }
        }

    }

    private int selectedAction = -1;
    private String action;

    private Bug selectedBug = null;
    private Tecton actionDest = null;
    private FungalThread selectedThread = null;
    private Fungus selectedFungus = null;

    /**
     * Kiválaszt egy rovar objektumot az adott koordinátákon.
     * Csak az aktuális játékoshoz tartozó rovarokat lehet kiválasztani.
     * A metódus szinkronizált a többszálú működés biztonságos kezelése érdekében.
     *
     * @param x A kiválasztás vízszintes koordinátája
     * @param y A kiválasztás függőleges koordinátája
     */

    synchronized public void selectBug(int x, int y) {
        Tecton tecton = selectTecton(x, y);
        if(tecton != null) {

            double tectonX = 0;
            double tectonY = 0;

            //kivalasztott tekton pozicioja
            for(TectonView tv : tvList) {
                if (tv.getTecton() == tecton) {
                    DoublePoint p = tv.getPosition();
                    tectonX = p.d_x + shift_x;
                    tectonY = p.d_y + shift_y;
                    break;
                }
            }

            //relativ kattintas
            double relativeX = x / scale - tectonX;
            double relativeY = y / scale - tectonY;


            //osszes rovar
            List<Bug> tectonBugs = tecton.getBugList();

            //jatekos rovarjai
            List<Bug> playerBugs = new ArrayList<>();
            for(Bug b : tectonBugs) {
                if (b.getTeamID() == actualPlayer) {
                    playerBugs.add(b);
                }
            }

            if(playerBugs.isEmpty()) {
                return;
            }

            //TectonView-bol athozva
            int bug_x = 13;
            int bug_y = 35;


            for(Bug bug : playerBugs){

                //klikk terulet
                int bugWidth = 25;
                int bugHeight = 25;

                if(relativeX >= bug_x && relativeX <= bug_x + bugWidth && relativeY >= bug_y && relativeY <= bug_y + bugHeight) {
                    selectedBug = bug;
                    GameLogic.selectBug(bug);
                    return;
                }

                //TectonView-bol athozva
                if(bug_x < 100 - 55) {
                    bug_x += 30;
                } else {
                    bug_x = 0;
                    bug_y += 30;
                }
            }
        }
    }

    /**
     * Kiválaszt egy gombafonalat az adott koordinátákon.
     * Csak az aktuális játékoshoz tartozó gombafonalakat lehet kiválasztani.
     * A metódus szinkronizált a többszálú működés biztonságos kezelése érdekében.
     *
     * @param x A kiválasztás vízszintes koordinátája
     * @param y A kiválasztás függőleges koordinátája
     */
    synchronized public void selectThread(int x, int y) {
        Tecton tecton = selectTecton(x, y);
        if(tecton != null) {
            List<FungalThread> threads = tecton.getThreadList();
            for(FungalThread t : threads) {
                if(t.getTeamID() == actualPlayer) {
                    selectedThread = t;
                    GameLogic.selectThread(t);
                    return;
                }
            }
        }
    }

    /**
     * Kiválaszt egy gombát az adott koordinátákon.
     * Csak az aktuális játékoshoz tartozó gombákat lehet kiválasztani.
     * A metódus szinkronizált a többszálú működés biztonságos kezelése érdekében.
     *
     * @param x A kiválasztás vízszintes koordinátája
     * @param y A kiválasztás függőleges koordinátája
     */
    synchronized public void selectFungus(int x, int y) {
        Tecton tecton = selectTecton(x, y);
        if(tecton != null) {
            Fungus f = tecton.getFungus();
            if(f.getTeamID() == actualPlayer) {
                selectedFungus = f;
                GameLogic.selectFungus(f);
                return;
            }
        }
    }

    /**
     * Törli az összes kiválasztást (tekton, gomba, gombafonal, rovar)
     * és visszaállítja a húzás állapotát.
     */
    public void deselect() {
        selectedTecton = null;
        selectedFungus = null;
        selectedThread = null;
        selectedBug = null;
        dragged = false;
    }

    /**
     * A billentyűzet állapotát figyelő objektumok adja vissza.
     * @return A panel GameKeyListenere.
     */
    public GameKeyListener getGameKeyListener() {
        return gameKL;
    }

    /**
     * A játéktér nagyítását/kicsinyítését végző metódus.
     *
     * @param enlarga true esetén kicsinyít (0.9x), false esetén nagyít (1.1x)
     */
    public void scale(boolean enlarga) {
        if(enlarga)
            scale *= 0.9;
        else
            scale *= 1.1;

        refreshScreen();
    }

    /**
     * Visszaállítja a játékteret alaphelyzetbe:
     * - Nagyítás visszaállítása 1.0-ra
     * - Eltolás nullázása
     * - Tektonok újrarendezése
     * - Képernyő frissítése
     */
    public void reset() {
        scale = 1.0;
        shift_x = 0;
        shift_y = 0;
        organize();
        refreshScreen();
    }

    /**
     * Betölti és megjeleníti a megadott tekton listát.
     * A betöltés során törli a korábbi tektonokat és újrakezdi a pozicionálást.
     *
     * @param tectonList A betöltendő tektonok listája
     */
    public void loadMap(List<Tecton> tectonList) {
        tvList.clear();
        max_x = 0;
        max_y = 0;
        nextPoint = new DoublePoint(0, 0);
        for(Tecton t : tectonList) {
            addTecton(t);
        }
    }

    /**
     * A tektonok elrendezését optimalizáló metódus.
     * Force-directed graph drawing algoritmust használ a tektonok elrendezésére:
     * - Taszító erő a tektonok között
     * - Vonzó erő a kapcsolódó tektonok között
     * - Középpont felé húzó erő
     * Az algoritmus 300 iterációt futtat a megfelelő elrendezés érdekében.
     */
    public void organize() {
        int iterations = 300;
        double width = WIDTH, height = HEIGTH;
        double k = Math.sqrt((width * height) / tvList.size());
        double damping = 0.85;

        for (int i = 0; i < iterations; i++) {
            // taszítás
            for (TectonView tectonview1 : tvList) {
                DoublePoint point1 = tectonview1.getPosition();
                point1.d_x = point1.d_y = 0;

                for (TectonView tectonview2 : tvList) {
                    if (tectonview1 == tectonview2) continue;
                    DoublePoint point2 = tectonview2.getPosition();

                    double ddx = point1.x - point2.x;
                    double ddy = point1.y - point2.y;
                    double dist = Math.max(1, Math.hypot(ddx, ddy));
                    double repulsiveForce = k * k / dist;
                    point1.d_x += ddx / dist * repulsiveForce;
                    point1.d_y += ddy / dist * repulsiveForce;
                }
            }

            List<Edge> edges = new ArrayList<>();
            for(TectonView tectonview : tvList) {
                for(Tecton tecton2 : tectonview.getTecton().getNeighbourList()) {
                    DoublePoint point1 = tectonview.getPosition();
                    DoublePoint point2 = new DoublePoint(0,0);
                    for(TectonView tectonview2 : tvList) {
                        if(tectonview2.getTecton() == tecton2) {
                            point2 = tectonview2.getPosition();
                            break;
                        }
                    }
                    Edge edge = new Edge(point1, point2);
                    boolean newEdge = true;
                    for(Edge e : edges) {
                        if(e.equals(edge)) {
                            newEdge = false;
                            break;
                        }
                    }
                    if(newEdge) {
                        edges.add(edge);
                    }
                }
            }

            // vonzás
            for (Edge e : edges) {
                double dx = e.a.x - e.b.x;
                double dy = e.a.y - e.b.y;
                double dist = Math.max(1, Math.hypot(dx, dy));
                double attractiveForce = 10 * dist * dist / k;
                double fx = dx / dist * attractiveForce;
                double fy = dy / dist * attractiveForce;
                e.a.d_x -= fx;
                e.a.d_y -= fy;
                e.b.d_x += fx;
                e.b.d_y += fy;
            }

            for (TectonView tectonview : tvList) {
                DoublePoint point1 = tectonview.getPosition();
                double dx = WIDTH/2 - point1.x;
                double dy = HEIGTH/2 - point1.y;
                point1.d_x += dx * 0.01;
                point1.d_y += dy * 0.01;
            }

            // pozíció frissítése
            for (TectonView tectonview : tvList) {
                DoublePoint point1 = tectonview.getPosition();
                point1.d_x *= damping;
                point1.d_y *= damping;
                point1.x += Math.max(-5, Math.min(5, point1.d_x));
                point1.y += Math.max(-5, Math.min(5, point1.d_y));

                point1.d_x = point1.x;
                point1.d_y = point1.y;
            }
        }

        refreshScreen();
    }

}

/**
 * Dupla pontosságú koordinátákat tároló segédosztály.
 * A Point osztály kiterjesztése lebegőpontos koordináták kezelésével.
 */
class DoublePoint extends Point {
    public double d_x;
    public double d_y;
    public DoublePoint(int x, int y) {
        super(x, y);
        d_x = x;
        d_y = y;
    }
    public DoublePoint(double x, double y) {
        super((int)x, (int)y);
        d_x = x;
        d_y = y;
    }

    public void setX(double d_x) {
        this.d_x = d_x;
        x = (int) d_x;
    }

    public void setX(int new_x) {
        this.d_x = new_x;
        x = new_x;
    }

    public void setY(double d_y) {
        this.d_y = d_y;
        y = (int) d_y;
    }

    public void setY(int new_y) {
        this.d_y = new_y;
        y = new_y;
    }

    public void addX(double x) {
        this.x += x;
    }
    public void addY(double y) {
        this.y += y;
    }
}

/**
 * Két pont közötti kapcsolatot reprezentáló segédosztály.
 * A force-directed graph drawing algoritmushoz használt él reprezentáció.
 */
class Edge {
    public DoublePoint a;
    public DoublePoint b;
    public Edge(DoublePoint a, DoublePoint b) {
        this.a = a;
        this.b = b;
    }

    public Edge() {}

    public boolean equals(Edge edge) {
        if((a.equals(edge.a) && b.equals(edge.b)) || a.equals(edge.b) && b.equals(edge.a)) {
            return true;
        }
        return false;
    }
}


