import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * A billentyűzet változásit figyelő osztály.
 */
public class GameKeyListener implements KeyListener {

    private GamePanel gp;
    public GameKeyListener(GamePanel gamePanel) {
        gp = gamePanel;
    }

    public boolean up, left, down, right, space, enter, pause;

    @Override
    public void keyTyped(KeyEvent e) {}
    /**
     * A játékban használt gombok megnyomása esetén True-ra állítja a hozzá tartozó változót.
     * @param e the event to be processed
     */
    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        switch(keyCode) {
//            case KeyEvent.VK_UP:
//                up = true;
//                gp.shift();
//                break;
//
//            case KeyEvent.VK_DOWN:
//                down = true;
//                gp.shift();
//                break;
//
//            case KeyEvent.VK_LEFT:
//                left = true;
//                gp.shift();
//                break;
//
//            case KeyEvent.VK_RIGHT:
//                right = true;
//                gp.shift();
//                break;
//
//            case KeyEvent.VK_SPACE:
//                space = true;
//                gp.shift();
//                break;

            case KeyEvent.VK_P:
                if(pause)
                    pause = false;
                else
                    pause = true;
                break;

            case KeyEvent.VK_ENTER:
                enter = true;
                break;
            case KeyEvent.VK_T:
                gp.toggleTecton();
                break;
            case KeyEvent.VK_F:
                gp.toggleThread();
                break;
            case KeyEvent.VK_N:
                gp.toggleName();
                break;
            case KeyEvent.VK_C:
                gp.changeTheme();
                break;
            case KeyEvent.VK_R:
                gp.reset();
                break;
            case KeyEvent.VK_O:
                gp.organize();
                break;
        }
    }

    /**
     * A játékban használt gombok esetén False-ra állítja a megfelelőnek az értékét a gomb elengedésekor.
     * @param e the event to be processed
     */

    @Override
    public void keyReleased(KeyEvent e) {
        int keyCode = e.getKeyCode();

        switch(keyCode) {
            case KeyEvent.VK_UP:
                up = false;
                break;

            case KeyEvent.VK_DOWN:
                down = false;
                break;

            case KeyEvent.VK_LEFT:
                left = false;
                break;

            case KeyEvent.VK_RIGHT:
                right = false;
                break;

            case KeyEvent.VK_SPACE:
                space = false;
                break;

            case KeyEvent.VK_ENTER:
                enter = false;
                break;
        }
    }
}
