import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.SpinnerNumberModel;

/**
 * A játék főmenüjét megjelenítő panel osztálya.
 * Tartalmazza a főmenü, beállítások, és háttér kezelést.
 */
public class GameMenu extends JPanel {
    /** Menü ablak szélessége. */
    private static final int WIDTH = 844;
    /** Menü ablak magassága. */
    private static final int HEIGHT = 563;

    /** Cím stílusának beállítása. */
    private static final Font TITLE_FONT = new Font("Arial", Font.BOLD, 80);
    /** Alcím stílusának beállítása. */
    private static final Font FOOTER_FONT = new Font("Arial", Font.PLAIN, 16);
    /** Beállítások menü szöveg stílusának beállítása. */
    private static final Font LABEL_FONT = new Font("Arial", Font.BOLD, 18);
    /** Gombokok szöveg stílusának beállítása. */
    private static final Font BUTTON_FONT = new Font("Arial", Font.BOLD, 18);
    /** Gombok színe. */
    private static final Color BUTTON_COLOR = new Color(0x6dece0);
    /** Szövveg színe. */
    private static final Color TEXT_COLOR = Color.WHITE;

    private final GameWindow gameWindow;
    private CardLayout cardLayout;
    private JPanel cards;

    /** Játékosok száma. */
    private Integer playerNum = 2;
    /** Körök száma. */
    private int gameRounds = 20;

    /**
     * Konstruktor, ami inicializálja a játék menüjét az ablakhoz.
     *
     * @param gameWindow A játék főablakának példánya.
     */
    public GameMenu(GameWindow gameWindow) {
        this.gameWindow = gameWindow;
        initializeMenu();
    }

    /**
     * Inicializálja a menü elemeit és a háttérpanelt.
     */
    private void initializeMenu() {
        setLayout(null);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));

        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(null);
        backgroundPanel.setBounds(0, 0, WIDTH, HEIGHT);
        add(backgroundPanel);

        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);
        cards.setOpaque(false);
        cards.setBounds(0, 0, WIDTH, HEIGHT);

        JPanel mainMenuPanel = createMainMenuPanel(backgroundPanel);
        JPanel setupPanel = createSetupPanel();

        cards.add(mainMenuPanel, "mainMenu");
        cards.add(setupPanel, "setup");

        backgroundPanel.add(cards);
    }

    /**
     * Létrehozza a főmenü panelt és hozzáadja az alap komponenseket.
     *
     * @param backgroundPanel A háttérpanel, amelyhez hozzáadódnak az elemek.
     * @return A főmenü panel.
     */
    private JPanel createMainMenuPanel(JPanel backgroundPanel) {
        JPanel panel = new JPanel(null);
        panel.setOpaque(false);

        addTitle(backgroundPanel);
        addFooter(backgroundPanel);
        addMenuButtons(backgroundPanel);

        return panel;
    }

    /**
     * Hozzáadja a címet a megadott panelhez.
     *
     * @param panel A panel, amelyhez a cím hozzáadódik.
     */
    private void addTitle(JPanel panel) {
        JLabel titleLabel = createLabel("Fungorium", TITLE_FONT, TEXT_COLOR, 375, 7, 450, 120);
        panel.add(titleLabel);
    }

    /**
     * Hozzáadja az alcím szöveget a megadott panelhez.
     *
     * @param panel A panel, amelyhez a lábléc hozzáadódik.
     */
    private void addFooter(JPanel panel) {
        JLabel footerLabel = createLabel("BMEN Team", FOOTER_FONT, TEXT_COLOR, 520, 105, 450, 50);
        panel.add(footerLabel);
    }

    /**
     * Létrehozza és hozzáadja a menü gombokat a megadott panelhez.
     *
     * @param panel A panel, amelyhez a gombok hozzáadódnak.
     */
    private void addMenuButtons(JPanel panel) {
        String[] labels = {"New Game", "Load Game", "Exit"};
        int[][] positions = {
                {440, 170},
                {440, 240},
                {160, 420}
        };

        ArrayList<JButton> buttons = new ArrayList<>();

        for (int i = 0; i < labels.length; i++) {
            JButton button = createMenuButton(labels[i]);
            button.setBounds(positions[i][0], positions[i][1], 250, 50);
            buttons.add(button);

            switch (labels[i]) {
                case "Exit" -> button.addActionListener(e -> SwingUtilities.getWindowAncestor(this).dispose());
                case "New Game" -> button.addActionListener(e -> {
                    toggleButtonsVisibility(buttons, false);
                    showSetupPanel();
                });
                case "Load Game" -> button.addActionListener(e -> {
                    gameWindow.addGamePanel();
                    GameLogic.loadGame();
                });
            }

            panel.add(button);
        }
    }

    /**
     * Létrehoz egy egységes stílusú menü gombot.
     *
     * @param text A gomb szövege.
     * @return A létrehozott JButton példány.
     */
    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(300, 80));
        button.setMaximumSize(new Dimension(300, 80));
        button.setFont(BUTTON_FONT);
        button.setBackground(BUTTON_COLOR);
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        return button;
    }

    /**
     * Létrehoz egy JLabel-t a megadott paraméterekkel.
     *
     * @param text A szövege.
     * @param font A használt betűtípus.
     * @param color A betű színe.
     * @param x X koordináta.
     * @param y Y koordináta.
     * @param width Szélesség.
     * @param height Magasság.
     * @return A létrehozott JLabel.
     */
    private JLabel createLabel(String text, Font font, Color color, int x, int y, int width, int height) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(color);
        label.setBounds(x, y, width, height);
        return label;
    }

    /**
     * Létrehozza a játékbeállítások panelt, ahol a játékosok száma és körök száma állítható.
     *
     * @return A beállító panel.
     */
    private JPanel createSetupPanel() {
        JPanel panel = new JPanel(null);
        panel.setOpaque(false);

        JLabel playersLabel = createLabel("Number of Players:", LABEL_FONT, TEXT_COLOR, 420, 185, 180, 25);
        panel.add(playersLabel);

        String[] options = {"2v2", "3v3"};
        JSpinner playerSpinner = createSpinner(new SpinnerListModel(options), 630, 180);
        panel.add(playerSpinner);

        JLabel roundsLabel = createLabel("Number of Rounds:", LABEL_FONT, TEXT_COLOR, 420, 236, 180, 25);
        panel.add(roundsLabel);

        JSpinner roundSpinner = createSpinner(new SpinnerNumberModel(gameRounds, 5, 50, 1), 630, 230);
        panel.add(roundSpinner);

        JButton startButton = createMenuButton("Start Game");
        startButton.setBounds(440, 290, 250, 50);
        startButton.addActionListener(e -> {
            String selected = (String) playerSpinner.getValue();
            playerNum = selected.equals("2v2") ? 2 : 3;
            gameRounds = (Integer) roundSpinner.getValue();
            gameWindow.addGamePanel();
            GameLogic.startGame(playerNum, gameRounds);
        });
        panel.add(startButton);

        return panel;
    }

    /**
     * Létrehoz egy JSpinner-t adott modell alapján, stílusos megjelenéssel.
     *
     * @param model A spinner modellje.
     * @param x X koordináta.
     * @param y Y koordináta.
     * @return A létrehozott JSpinner.
     */
    private JSpinner createSpinner(SpinnerModel model, int x, int y) {
        JSpinner spinner = new JSpinner(model);
        spinner.setBounds(x, y, 70, 40);
        JComponent editor = spinner.getEditor();
        JTextField textField = ((JSpinner.DefaultEditor) editor).getTextField();
        textField.setFont(new Font("Arial", Font.BOLD, 16));
        return spinner;
    }

    /**
     * Beállítja a gombok láthatóságát egy listában.
     *
     * @param buttons A gombok listája.
     * @param visible Az új láthatóság állapot.
     */
    private void toggleButtonsVisibility(ArrayList<JButton> buttons, boolean visible) {
        buttons.forEach(button -> button.setVisible(visible));
    }

    /**
     * Megjeleníti a beállítások panelt.
     */
    private void showSetupPanel() {
        cardLayout.show(cards, "setup");
        cards.revalidate();
        cards.repaint();
    }

    /**
     * Visszaadja az ablak méretét dimenzióként.
     *
     * @return A panel mérete.
     */
    public Dimension getMenuDimension() {
        return new Dimension(WIDTH, HEIGHT);
    }

    /**
     * Belső osztály a háttér kép megjelenítésére.
     */
    static class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        /**
         * Háttérpanel konstruktor: betölti a háttérképet.
         */
        public BackgroundPanel() {
            try {
                backgroundImage = new ImageIcon("assets/background/background.jpg").getImage();
            } catch (Exception e) {
                System.out.println("Nem sikerült betölteni a háttérképet.");
            }
        }

        /**
         * Kirajzolja a háttérképet a panelre.
         *
         * @param g A Graphics objektum.
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}