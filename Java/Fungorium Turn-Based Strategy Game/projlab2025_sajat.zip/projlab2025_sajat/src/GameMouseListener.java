
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;

/**
 * Az egér állapotát figyelő osztály.
 */
public class GameMouseListener extends MouseAdapter {

    public int xPos, yPos;
    public boolean clicked, entered;
    private GamePanel gamePanel;

    public GameMouseListener(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
    }
    /**
     * Az egér belépésekor az ablakba az entered értéket True-ra állítja.
     * @param e the event to be processed
     */
    public void mouseEntered(MouseEvent e) {
        entered = true;
    }

    /**
     * Ha az egér a kijelzőben van és a bal gombjának megnyomása történik, akkor a clicked True értéket kap.
     * @param e the event to be processed
     */
    public void mousePressed(MouseEvent e) {
        if(entered && e.getButton() == MouseEvent.BUTTON1) {
            clicked = true;
            xPos = e.getX();
            yPos = e.getY();
            gamePanel.clickTecton(xPos, yPos);
        }
    }


    /**
     * Ha az egér kimegy a kijelzőből, akkor az entered és a clicked False értéket kap.
     * @param e the event to be processed
     */
    public void mouseExited(MouseEvent e) {
        clicked = false;
        entered = false;
        gamePanel.deselect();
    }

    /**
     * Ha az egér az ablakban van, akkor frissíti az egér mozgásával a mutató x és y pozícióját.
     * A clicked értéket meg False-ra állítja.
     * @param e the event to be processed
     */
    public void mouseMoved(MouseEvent e) {

    }

    /**
     * Az egér bármelyik gombjának elengedése a clicked értéket False-ra állítja.
     * @param e the event to be processed
     */
    public void mouseReleased(MouseEvent e) {
        if(entered && e.getButton() == MouseEvent.BUTTON1) {
            clicked = false;
            xPos = e.getX();
            yPos = e.getY();
            gamePanel.clickOption(xPos, yPos);
        }
        gamePanel.deselect();
    }

    public void mouseDragged(MouseEvent e) {
        if(clicked && entered) {
            int dx = xPos - e.getX();
            int dy = yPos - e.getY();
            yPos = e.getY();
            xPos = e.getX();
            gamePanel.shift(-dx, -dy);
        }
    }

    public void mouseWheelMoved(MouseWheelEvent e) {
        if(e.getWheelRotation() > 0) {
            gamePanel.scale(true);
        } else {
            gamePanel.scale(false);
        }
    }

}
