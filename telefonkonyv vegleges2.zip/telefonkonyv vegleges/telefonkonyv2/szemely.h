#ifndef SZEMELY_H
#define SZEMELY_H


typedef struct szemely {
    char nev[50], telefonszam[20], cim[50], egyeb[50];
    struct szemely *kov;
} szemely;

#endif
