#ifndef TELEFONKONYV_H
#define TELEFONKONYV_H
#include <stdbool.h>
#include "szemely.h"


bool szerepelnev(szemely* telefonkonyv, char nev[50]);

bool szerepeltelefonszam(szemely* telefonkonyv, char telefonszam[50]);

bool szerepelnevtelefonszam(szemely* telefonkonyv, char nev[50], char telefonszam[50]);

void felszabadit(szemely* telefonkonyv);

int telefonkonyvkiirasa(szemely* telefonkonyv);





#endif





