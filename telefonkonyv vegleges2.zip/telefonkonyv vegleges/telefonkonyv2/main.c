#include "telefonkonyv.h"
#include "debugmalloc.h"
#ifdef _WIN32
    #include <windows.h>
#endif


int main()
{
    #ifdef _WIN32
        SetConsoleCP(1250);
        SetConsoleOutputCP(1250);
    #endif
    szemely *telefonkonyv = NULL;

    telefonkonyv = fajlolvas();

    menu(&telefonkonyv);

    felszabadit(telefonkonyv);


    return 0;
}
