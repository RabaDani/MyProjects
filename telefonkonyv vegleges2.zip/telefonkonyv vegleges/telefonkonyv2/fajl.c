#include "fajl.h"
#include "seged.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "debugmalloc.h"

//!
 /*! adatok.vcf fájlba írását valósítja meg, ahol megvizsgálja, hogy a fájl megnyítható-e írásra, ha igen, akkor soronként feltölti a fájlt a személyek adataival pontosvesszővel elválasztva, ha nem, akkor hibaüzenet után visszatér a függvény.
 * @param szemely* telefonkonyv: a telefonkonyv.
 */
void fajliras(szemely* telefonkonyv) {
    FILE* file = fopen("adatok.vcf", "w");

    if (file == NULL) {
        perror("\nNem sikerült megnyitni a fájlt.\n");
        return;
    }

    szemely* jelenlegi = telefonkonyv;
    while (jelenlegi != NULL) {
        fprintf(file, "%s;%s;%s;%s\n", jelenlegi->nev, jelenlegi->telefonszam, jelenlegi->cim, jelenlegi->egyeb);
        jelenlegi = jelenlegi->kov;
    }

    fclose(file);
    printf("\nAdatok elmentve a fajlba.\n");
}

//!
/*!
 * adatok.vcf fájl olvasását valósítja meg, ahol megvizsgálja, hogy a fájl megnyítható-e olvasására, ha igen, akkor soronként kiolvassa a fájlban lévő személyek adatait, amelyeket pontosvesszőnként szétdarabol és eltárolja a telefonkönyvben szereplő adott személy adataiként. Ha nem tudja megnyitni olvasásra a fájlt, akkor hibaüzenet után visszatér a függvény.
 * @return a feltötött telefonkönyvet adja vissza;
 */
szemely* fajlolvas() {
    szemely* telefonkonyv = NULL;
    FILE* file = fopen("adatok.vcf", "r");
     if (file == NULL) {
        perror("\nNem sikerült megnyitni a fájlt.\n");
        return;
    }

    char sor[200];
    while (fgets(sor, sizeof(sor), file) && sor != EOF) {
        sor[strlen(sor) - 1] = '\0';
        szemely *uj;
        uj = (szemely*) malloc(sizeof(szemely));
        kinulaz(uj);
        uj->kov = NULL;
        char* token = strtok(sor, ";");
            if (token) {
                strncpy(uj->nev, token, sizeof(uj->nev));
                token = strtok(NULL, ";");
                if (token) {
                    strncpy(uj->telefonszam, token, sizeof(uj->telefonszam));
                    token = strtok(NULL, ";");
                    if (token) {
                        strncpy(uj->cim, token, sizeof(uj->cim));
                        token = strtok(NULL, ";");
                        if (token) {
                            strncpy(uj->egyeb, token, sizeof(uj->egyeb));
                        }
                    }
                }
            }

        if (telefonkonyv == NULL) {
               /* üres listánál ez lesz az elsõ elem */
            telefonkonyv = uj;
        } else {
            /* ha nem üres a lista, az utolsó után fûzzük */
            szemely *mozgo = telefonkonyv;
            while (mozgo->kov != NULL)
                mozgo = mozgo->kov;
            mozgo->kov = uj;
        }

    }
    fclose(file);
    return telefonkonyv;
}
