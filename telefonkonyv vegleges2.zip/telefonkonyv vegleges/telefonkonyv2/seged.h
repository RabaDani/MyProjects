#ifndef SEGED_H
#define SEGED_H
#include "szemely.h"

int szemelyekkiirasa(szemely* telefonkonyv);

void kinulaz(szemely* jelenlegi);

#endif
