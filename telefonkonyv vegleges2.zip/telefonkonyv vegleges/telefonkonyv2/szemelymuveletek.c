#include "telefonkonyv.h"
#include "debugmalloc.h"
#include "szemelymuveletek.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

//!
/*!
 * Kitörli a telefonkönyvből, a paraméterként kapott helyen lévő személyt és felszabadítja az általa foglalt memória területet.
 * @param szemely* telefonkonyv: a telefonkonyv.
 * @param int torlendo_idx: a torlendo szemely helyenek indexe a telefonkonyvben.
 * @return A telefonkönyv a személy kitörlése után.;
 */
szemely* szemelytorlese(szemely* telefonkonyv,int torlendo_idx)
{
    szemely *lemarado = NULL;
    szemely *mozgo = telefonkonyv;
    for(int i= 0;i<torlendo_idx && mozgo != NULL;i++)
    {
        lemarado = mozgo;
        mozgo = mozgo->kov;
    }

    int torles = 0;
    /* megtalált elem törlése */
    if (mozgo == NULL) {           /* nincs ilyen elem */
        printf("\nNincs ilyen szemely!\n");
    }
    else
    {
        printf("----------------------------------------\nBiztosan szeretned torolni a szemely adatait a telefonkonyvbol?\n\b\t1. Igen\n\b\t2. Nem\n----------------------------------------\n");
        scanf("%d", &torles);
        if(torles == 2)
            printf("\nA szemely nem lett kitorolve a telefonkonyvbol.\n");
        else if(torles == 1)
        {
            if (lemarado == NULL)
            {
                szemely *ujeleje = mozgo->kov; /* az első elemet kell törölni */
                free(mozgo);
                telefonkonyv = ujeleje;
            }
            else
            {
                lemarado->kov = mozgo->kov;  /* a közepéről/végéről törlünk */
                free(mozgo);
            }
            printf("\nSzemely kitorolve a telefonkonyvbol.\n");

        }
        else
            printf("\nHibas bemenet.\n");
    }
    return telefonkonyv;
}


//!
/*!
 * Megkeresi a paraméteren kapott helyen lévő személyt, majd megkérdezi, hogy az adott személynek melyik adatát akarja módósítani, ezután azt módosítja., majd újra felajánlja a módosítást, ameddig az Exit-et nem válassza a felhasználó, vagy hibás bemenetet ad. Név és telefonszám módosításnál, csak akkor engedi a módosítást, ha az új adat nem szerepel a telefonkönyvben.
 * @param szemely* telefonkonyv: a telefonkonyv.
 * @param int modositando_idx: a módosítandó személy helyének indexe.
 * @return a telefonkönyv a módosítások elvégzése után;
 */
szemely* szemelymodositasa(szemely* telefonkonyv,int modositando_idx)
{
    szemely *modositando = telefonkonyv;
    for(int i= 0;i<modositando_idx && modositando != NULL;i++)
        modositando = modositando->kov;
        // nem lehet NULL pointer, mert a menuben, hiba uzenetet adunk vissza, ha nem megfelelo a bemenet.
        int mit = 0;
        while(mit<5)
        {
            printf("----------------------------------------\n\b\t1. Nev modositasa\n\b\t2. Telefonszam modositasa\n\b\t3. Cim modositasa\n\b\t4. Egyeb informacio modositasa\n\b\t5. Exit\n----------------------------------------\n");
            printf(">> ");
            scanf("%d",&mit);
            getchar();
            if(mit==1)
            {
                char ujnev[50];
                printf("Nev: ");
                fgets(ujnev,sizeof(ujnev),stdin);
                ujnev[strlen(ujnev) - 1] = '\0';
                if(strcmp(ujnev,"") == 0)
                    printf("\nAz uj nev megadasa kotelezo!\n");
                else if(szerepelnev(telefonkonyv,ujnev))
                {
                     printf("\nEz a nev mar szerepel a telefonkonyvben!\n");
                }

                else
                    strcpy(modositando->nev,ujnev);
            }
            else if(mit==2)
            {
                char ujtelefonszam[50];
                printf("Telefonszam: ");
                fgets(ujtelefonszam,sizeof(ujtelefonszam),stdin);
                ujtelefonszam[strlen(ujtelefonszam) - 1] = '\0';
                if(strcmp(ujtelefonszam,"") == 0)
                    printf("\nAz uj telefonszam megadasa kotelezo!\n");
                if(szerepeltelefonszam(telefonkonyv,ujtelefonszam))
                {
                     printf("\nEz a telefonszam mar szerepel a telefonkonyvben!\n");
                }

                else
                    strcpy(modositando->telefonszam,ujtelefonszam);
            }
            else if(mit==3)
            {
                printf("Cim: ");
                fgets(modositando->cim,sizeof(modositando->cim),stdin);
                modositando->cim[strlen(modositando->cim) - 1] = '\0';
            }
            else if(mit==4)
            {
                printf("Egyeb informacio: ");
                fgets(modositando->egyeb,sizeof(modositando->egyeb),stdin);
                modositando->egyeb[strlen(modositando->egyeb) - 1] = '\0';
            }
            else if(mit == 5)
                printf("\nKileptel, a modositasok elmentve.\n");
            else
                printf("\nHibas bemenet\n");
        }
        return telefonkonyv;
}

//!
 /*! A függvény által új személyt tudunk eltárolni a telefonkönyvben. Kötelező megadni a személy nevét és telefonszámát, illetve opcionálisan meglehet adni címet és egyéb információt. Ezután megvizsgálja, hogy az adott név vagy telefonszám szerepel-e már a telefonkönyvben, ha igen akkor hiba üzenet ad vissza és nem menti el az új személyt. Ha nem szerepel, akkor elmenti a telefonkönyv utolsó elemeként..
 * @param szemely* telefonkonyv: a telefonkonyv.
 * @return a telefonkönyv, ami tartalmazza az új személyt.;
 */
szemely* szemelymegadasa(szemely* telefonkonyv)
{

    char ujnev[50];
    char ujtelefonszam[50];
    printf("Nev: ");
    fgets(ujnev,sizeof(ujnev),stdin);
    ujnev[strlen(ujnev) - 1] = '\0';
    printf("Telefonszam: ");
    fgets(ujtelefonszam,sizeof(ujtelefonszam),stdin);
    ujtelefonszam[strlen(ujtelefonszam) - 1] = '\0';
    if(strcmp(ujnev,"") == 0 || strcmp(ujtelefonszam,"") == 0)
    {
         printf("\nA nev es telefonszam megadasa kotelezo!\n");
    }
    else if(szerepelnevtelefonszam(telefonkonyv,ujnev,ujtelefonszam))
    {
         printf("\nEz a nev vagy telefonszam mar szerepel a telefonkonyvben!\n");
    }
    else
    {
        szemely *uj = NULL;
        uj = (szemely*) malloc(sizeof(szemely));
        kinulaz(uj);
        uj->kov = NULL;

        strcpy(uj->nev,ujnev);
        strcpy(uj->telefonszam,ujtelefonszam);

        int j=0;
        while(j<3)
        {
            printf("----------------------------------------\nTovabbi adatok megadasa: \n");
            printf("\b\t1. Cim megadasa\n\b\t2. Egyeb adat megadasa\n\b\t3. Exit\n----------------------------------------\n");
            printf(">> ");
            scanf("%d", &j);
            getchar();
            if(j==1)
            {
                printf("Cim: ");
                fgets(uj->cim,sizeof(uj->cim),stdin);
                if(uj->cim[strlen(uj->cim)-1]== '\n')
                    uj->cim[strlen(uj->cim) - 1] = '\0';
            }
            else if(j==2)
            {
                printf("Egyeb informacio: ");
                fgets(uj->egyeb,sizeof(uj->egyeb),stdin);
                if(uj->egyeb[strlen(uj->egyeb)-1]== '\n')
                    uj->egyeb[strlen(uj->egyeb) - 1] = '\0';
            }
            else if(j==3)
            {
                printf("\nKileptel. A szemely elmentve a telefonkonyvbe.\n");
            }
            else
                printf("\nHibas bemenet! A szemely nem lett elmentve a telefonkonyvbe.\n");
        }
        if (telefonkonyv == NULL) {
           /* üres listánál ez lesz az elsõ elem */
           telefonkonyv = uj;
        }
        else {
           /* ha nem üres a lista, az utolsó után fûzzük */
           szemely *mozgo = telefonkonyv;
           while (mozgo->kov != NULL)
              mozgo = mozgo->kov;
           mozgo->kov = uj;
        }
    }
    return telefonkonyv;
}

//! A függvény a paraméterként kapott int érték alapján dönti el, hogy mi alapján keressen. Ezután bekéri a felhasznlótól a keresőszót. A telefonszámos keresésnél csak a pontos egyező telefonszámokkal rendelkező személyeket listázza ki. A név alapján lévő keresés név elejére illeszkedő keresés, amely megenged egy vagy több tetszőleges karaktert, amit nem akarunk definiálni, ekkor használhatjuk a * -helyetesítő karakter. A cím szerinti keresés szintén szöveg elejére illeszkedő keresés, a cím kereséshez elegendő a cím első szavának vagy az első szó kezdőrészének megadása is.
 /*!
    \param szemely* telefonkonyv: a telefonkonyv, illetve
    \param int alapjan: ez alapján dönti el a program, hogy melyik keresési funkciót valósítja meg.
 */
void szemelykereses(szemely* telefonkonyv,int alapjan)
{
    bool talalt = false;
    if(alapjan == 1)
    {
        printf("Nev: ");
        char keresoszo[50];
        fgets(keresoszo,sizeof(keresoszo),stdin);
        keresoszo[strlen(keresoszo) - 1] = '\0';
        szemely* mozgo;
        for(mozgo = telefonkonyv;mozgo!=NULL;mozgo = mozgo->kov) {
            int egyezik = 1;
            if(strlen(keresoszo) > strlen(mozgo->nev)) {
                continue;
            }

            for(int j = 0; j < strlen(keresoszo);j++) {
                if(keresoszo[j] == '*') {
                continue;
                }
                else if(keresoszo[j] != mozgo->nev[j]) {
                egyezik = 0;
                break;
                }
            }
            if(!egyezik) {
                continue;
            }
            talalt = true;
            printf("\b\t*----------------*\n\b\tNev: %s\n\b\tTelefonszam: %s\n\b\tCim: %s\n\b\tEgyeb: %s\n\b\t*----------------*\n",mozgo->nev,mozgo->telefonszam,mozgo->cim,mozgo->egyeb);
        }
        if(!talalt)
            printf("\nNincs ilyen nev a telefonkonyvben.\n");
    }
    else if(alapjan == 2)
    {
        char keresett[20];
        printf("Telefonszam: ");
        fgets(keresett,sizeof(keresett),stdin);
        keresett[strlen(keresett) - 1] = '\0';
        szemely* mozgo;
        for(mozgo = telefonkonyv;mozgo!=NULL;mozgo = mozgo->kov)
        {
            if(strcmp(mozgo->telefonszam,keresett) == 0)
            {
                printf("\nA keresett szemely adatai: \n");
                printf("\b\tNev: %s\n\b\tTelefonszam: %s\n\b\tCim: %s\n\b\tEgyeb: %s\n",mozgo->nev,mozgo->telefonszam,mozgo->cim,mozgo->egyeb);
                talalt = true;
            }
        }
        if(!talalt)
            printf("\nNincs ilyen telefonszam a telefonkonyvben.\n");

    }
    else if(alapjan == 3)
    {
        char keresett[50];
        printf("Cim: ");
        fgets(keresett,sizeof(keresett),stdin);
        keresett[strlen(keresett) - 1] = '\0';
        szemely* mozgo;
        for(mozgo = telefonkonyv;mozgo!=NULL;mozgo = mozgo->kov) {
            int egyezik = 1;
            if(strlen(keresett) > strlen(mozgo->cim)) {
                continue;
            }
            for(int j = 0; j < strlen(keresett);j++) {
                if(keresett[j] != mozgo->cim[j]) {
                    egyezik = 0;
                    break;
                }
            }
            if(!egyezik) {
                continue;
            }
            talalt = true;
            printf("\b\t*----------------*\n\b\tNev: %s\n\b\tTelefonszam: %s\n\b\tCim: %s\n\b\tEgyeb: %s\n\b\t*----------------*\n",mozgo->nev,mozgo->telefonszam,mozgo->cim,mozgo->egyeb);
        }
        if(!talalt)
            printf("\nNincs ilyen cim a telefonkonyvben.\n");

    }
    else if(alapjan == 4)
        printf("\nKileptel.\n");
    else
        printf("\nHibas bemenet, visszakerultel a menube.\n");

}
