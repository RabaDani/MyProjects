#include "menu.h"
#include "seged.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "debugmalloc.h"

//!
  /*! A telefonk�nyv fomenuje, ahol kulonbozo lehetosegek kozul valaszthatunk �s kulonbozo muveleteket hajthatunk vegre a telefonkonyvon, gyakran mas fuggvenyek meghivasaval.
    \param szemely** telefonkonyv: a telefonkonyvre mutato pointer.
    */
void menu(szemely** telefonkonyv)
{
    int n =0;
    printf("Kedves Felhasznalo!\n");
    while(n!=7)
    {
        printf("----------------------------------------------------------\nValasszon alabbi menupontok kozul a sorszam megadasaval:\n");
        printf("\b\t1. Uj szemely megadasa\n\b\t2. Szemely adatainak modositasa\n\b\t3. Szemely torlese\n\b\t4. Kereses a szemelyek kozott\n\b\t5. Szemelyek adatainak exportalasa vCard fajlba\n\b\t6. Telefonkonyv adatainak kiirasa\n\b\t7. Exit\n----------------------------------------------------------\n");
        printf(">> ");
        scanf("%d",&n);
        getchar();

        if(n==1)
        {
            printf("----------------------------------------\nUj szemely megadasa:\n");
            *telefonkonyv = szemelymegadasa(*telefonkonyv);
        }
        else if(n==2)
        {
            int modositando;
            int exit;
            printf("----------------------------------------\nMelyik szemely adatait akarod modositani?\n");
            exit = szemelyekkiirasa(*telefonkonyv);
            printf("----------------------------------------\n");
            printf(">> ");
            scanf("%d",&modositando);
            getchar();
            if(modositando<=(exit-1) && modositando>0)
            {
                 modositando--;
                *telefonkonyv = szemelymodositasa(*telefonkonyv,modositando);
            }
            else if(modositando==exit)
                printf("\nKileptel.\n");
            else
                printf("\nHibas bemenet.\n");

        }
        else if(n==3)
        {
            int max;
            int torlendo;
            printf("----------------------------------------\nKinek az adatait akarod torolni?\n");
            max = szemelyekkiirasa(*telefonkonyv);
            printf("----------------------------------------\n");
            printf(">> ");
            scanf("%d",&torlendo);
            getchar();
            if(torlendo<=(max-1) && torlendo>0)
            {
                 torlendo--;
                *telefonkonyv = szemelytorlese(*telefonkonyv,torlendo);
            }
            else if(torlendo==max)
                printf("\nKileptel.\n");
            else
                printf("\nHibas bemenet.\n");

        }
        else if(n==4)
        {
            int alapjan = 0;
            printf("----------------------------------------\nMi alapjan szeretnel keresni?\n\b\t1. Nev ( * karakter segitsegevel)\n \b\t2. Telefonszam\n \b\t3. Cim\n\b\t4. Exit\n----------------------------------------\n");
            printf(">> ");
            scanf("%d",&alapjan);
            getchar();

            szemelykereses(*telefonkonyv,alapjan);



        }
        else if(n==5)
        {
            fajliras(*telefonkonyv);
        }
        else if(n==6)
        {
            int input;
            int exit = telefonkonyvkiirasa(*telefonkonyv);
            printf(">> ");
            scanf("%d",&input);
            getchar();
            if(input==exit)
                printf("\nKileptel.\n");
            else
                printf("\nHibas bemenet.\n");
        }
        else if(n==7)
        {
            printf("\nKileptel.\n----------------------------------------\n");
        }
        else
            printf("\nHibas bemenet!\n");

    }


}
