#ifndef MENU_H
#define MENU_H
#include "szemely.h"




void menu(szemely **telefonkonyv);

#endif
