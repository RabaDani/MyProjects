#ifndef FAJL_H
#define FAJL_H
#include "szemely.h"


void fajliras(szemely* telefonkonyv);

szemely* fajlolvas();

#endif
