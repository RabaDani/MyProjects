#include "seged.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "debugmalloc.h"


//!
/*!
 * Kiirja a telefonk�nyvben szerepl� szem�lyek nev�t soronk�nt, illetve megsz�molja a szem�lyek sz�m�t a telefonk�nyvben.
 * @param szemely* telefonkonyv: a telefonkonyv.
 * @return a szem�lyek sz�ma a telefonk�nyvben +1;
 */
int szemelyekkiirasa(szemely* telefonkonyv) {
    szemely* jelenlegi = telefonkonyv;
    int cnt = 1;
    while (jelenlegi != NULL) {
        printf("\b\t%d. Nev: %s\n", cnt,jelenlegi->nev);
        jelenlegi = jelenlegi->kov;
        cnt++;
    }
    printf("\b\t%d. Exit\n",cnt);
    return cnt;
}

//!
/*!
 * Az adott szem�lyhez tartoz� adatokat (n�v,c�m,telefonsz�m,egy�b) �res stringekkel t�lti fel..
 * @param szemely* jelenlegi: a telefonkonyv egyik szemelye.
 */
void kinulaz(szemely* jelenlegi)
{
        strcpy(jelenlegi->nev,"\0");
        strcpy(jelenlegi->telefonszam,"\0");
        strcpy(jelenlegi->cim,"\0");
        strcpy(jelenlegi->egyeb,"\0");
}
