#ifndef SZEMELYMUVELETEK_H
#define SZEMELYMUVELETEK_H
#include <stdbool.h>
#include "szemely.h"

szemely* szemelytorlese(szemely* telefonkonyv,int torlendo_idx);

szemely* szemelymodositasa(szemely* telefonkonyv,int modositando_idx);

szemely* szemelymegadasa(szemely* telefonkonyv);

void szemelykereses(szemely* telefonkonyv,int alapjan);

#endif
