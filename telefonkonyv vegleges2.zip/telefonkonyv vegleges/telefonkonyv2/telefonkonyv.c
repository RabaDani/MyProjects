#include "telefonkonyv.h"
#include "debugmalloc.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


//!
/*!
 * Kiirja a telefonkonyv szemelyeinek adatait, illetve megszamolja hogy hany szemely van a telefonkonyvben.
 * @param szemely* telefonkonyv: a telefonkonyv.
 * @return Szemelyek szama a telefonkonyvben+1;
 */
int telefonkonyvkiirasa(szemely* telefonkonyv)
{
    int szamlalo = 1;
    szemely* mozgo = telefonkonyv;
    printf("\n-----------------------------------\n      A TELEFONKONYV ADATAI:       \n-----------------------------------\n");
    for(mozgo = telefonkonyv;mozgo!=NULL;mozgo = mozgo->kov)
    {
        printf("%d. Nev: %s, Telefonszam: %s, Cim: %s, Egyeb: %s\n",szamlalo,mozgo->nev,mozgo->telefonszam,mozgo->cim,mozgo->egyeb);
        szamlalo++;
    }
    printf("%d. Exit\n----------------------------------------\n",szamlalo);
    return szamlalo;
}

//!
/*!
 * Megvizsgalja, hogy az adott nev szerepel-e a telefonk�nyvben.
 * @param szemely* telefonkonyv: a telefonkonyv.
 * @param char nev[50]: a nev, amit keres�nk a telefonkonyvben.
 * @return bool IGAZ, ha a nev szerepel a telefonkonyvben, kulonben HAMIS;
 */
bool szerepelnev(szemely* telefonkonyv, char nev[50])
{
    szemely* mozgo;
    for(mozgo = telefonkonyv;mozgo!=NULL;mozgo = mozgo->kov)
    {
        if(strcmp(mozgo->nev,nev) == 0)
        {
            return true;
        }
    }
    return false;

}
//!
/*!
 * Megvizsgalja, hogy az adott telefonszam szerepel-e a telefonkonyvben.
 * @param szemely* telefonkonyv: a telefonkonyv.
 * @param char telefonszam[50]: a telefonszam, amit keresunk a telefonkonyvben
 * @return bool IGAZ, ha a telefonszam  szerepel a telefonkonyvben, kulonben HAMIS;
 */
bool szerepeltelefonszam(szemely* telefonkonyv, char telefonszam[50])
{
    szemely* mozgo;
    for(mozgo = telefonkonyv;mozgo!=NULL;mozgo = mozgo->kov)
    {
        if(strcmp(mozgo->telefonszam,telefonszam) == 0)
        {
            return true;
        }
    }
    return false;

}

//!
/*!
 * Megvizsgalja, hogy az adott nev �s telefonszam szerepel-e a telefonkonyvben.
 * @param szemely* telefonkonyv: a telefonkonyv.
 * @param char nev[50]: a nev, amit keresunk a telefonkonyvben.
 * @param char telefonszam[50]: a telefonszam, amit keresunk a telefonkonyvben.
 * @return bool IGAZ, ha a nev VAGY a telefonszam szerepel a telefonkonyvben, kulonben HAMIS;
 */
bool szerepelnevtelefonszam(szemely* telefonkonyv, char nev[50], char telefonszam[50])
{
    szemely* mozgo;
    for(mozgo = telefonkonyv;mozgo!=NULL;mozgo = mozgo->kov)
    {
        if(strcmp(mozgo->nev,nev) == 0 || strcmp(mozgo->telefonszam,telefonszam) == 0)
        {
            return true;
        }
    }
    return false;

}

//!
/*!
 * Felszabaditja a telefonkonyv altal foglalt memoria ter�letet, a szemelyek egyesevel valo felszabaditasaval.
 * @param szemely* telefonkonyv: a telefonkonyv.
 */
void felszabadit(szemely* telefonkonyv)
{
    szemely* jelenlegi = telefonkonyv;

    while (jelenlegi != NULL) {
    szemely* kovetkezo = jelenlegi->kov;
    free(jelenlegi);
    jelenlegi = kovetkezo;
    }
}








